﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Xml;
using System.Xml.Linq;
using AjaxControlToolkit;
using System.Web.Services;
using Telerik.Web.UI;
using System.Collections.ObjectModel;
using System.Web.Script.Serialization;
using System.Diagnostics;
using Ionic.Zip;
using System.Xml.XPath;
using NLog;

namespace CRMDownloads
{
    public partial class ProductContentUpdate : System.Web.UI.Page
    {
        //static Logger logger = LogManager.GetCurrentClassLogger();

        static string storePath = ServerSpecificParams.getStorePath();

        public string BaseSiteUrl
        {
            get
            {
                HttpContext context = HttpContext.Current;
                string baseUrl = context.Request.Url.Scheme + "://" + context.Request.Url.Authority + context.Request.ApplicationPath.TrimEnd('/') + '/';
                return baseUrl;
            }
        }

        string sUser = null;
        string strLogonUser = null;
        string DBProductsfilesPath = storePath + "\\Database\\Products.xml";

        protected void Page_Load(object sender, EventArgs e)
        {
            //logger.Trace("HERE WE GO! This is a test.");

            HttpContext context = HttpContext.Current;
            string baseUrl = context.Request.Url.Scheme + "://" + context.Request.Url.Authority + '/';

            sUser = Request.ServerVariables["LOGON_USER"];
            strLogonUser = sUser.Substring(sUser.IndexOf("\\") + 1);
            //strLogonUser = sUser.Substring(sUser.IndexOf("\\") + 1);
            //strLogonUser = "sshinde";
            if (!IsPostBack)
            {
                getProducts();
                //hdnBaseUrl.Value = BaseSiteUrl;                
            }

            if (drpCategory.SelectedValue != "")
            {

                string selDrpProd = drpProducts.SelectedValue;

                XmlNode xProd = DBReader.getFullProduct(selDrpProd);

                string prodPathName = xProd.Attributes["Name"].Value.ToString();

                hdnBaseUrl.Value = BaseSiteUrl;


                string[] readmeDocumentPath = new string[] { "/" + prodPathName + "/ReadmeFiles" };
                //string[] readmeDocumentPath = new string[] { drpProducts.SelectedItem.Text };
                //string[] viewReadmeDocuments = new string[] { @"\\ppmcrmt3ws1\store\SmartPlant 3D\ReadmeFiles" };//storePath + "\\" + drpProducts.SelectedItem.Text + "\\ReadmeFiles" };
                //string[] uploadReadmeDocuments = new string[] { storePath + "\\" + drpProducts.SelectedItem.Text + "\\ReadmeFiles" };
                //string[] deleteReadmeDocument = new string[] { storePath + "\\" + drpProducts.SelectedItem.Text + "\\ReadmeFiles" };

                RadEditorAnnouncements.DocumentManager.ViewPaths = readmeDocumentPath;
                RadEditorAnnouncements.DocumentManager.UploadPaths = readmeDocumentPath;
                RadEditorAnnouncements.DocumentManager.DeletePaths = readmeDocumentPath;
                RadEditorAnnouncements.DocumentManager.SearchPatterns = new string[] { "*.doc", "*.txt", "*.docx", "*.xls", "*.xlsx", "*.pdf", "*.htm", "*.html", "*.mht", "*.zip" };
                RadEditorAnnouncements.DocumentManager.MaxUploadFileSize = 209715200;
                RadEditorAnnouncements.DocumentManager.ContentProviderTypeName = typeof(ExtendedFileProvider).AssemblyQualifiedName;
                getCustomLinks(RadEditorAnnouncements);

                RadEditorNoteVersionContent.DocumentManager.ViewPaths = readmeDocumentPath;
                RadEditorNoteVersionContent.DocumentManager.UploadPaths = readmeDocumentPath;
                RadEditorNoteVersionContent.DocumentManager.DeletePaths = readmeDocumentPath;
                RadEditorNoteVersionContent.DocumentManager.SearchPatterns = new string[] { "*.doc", "*.txt", "*.docx", "*.xls", "*.xlsx", "*.pdf", "*.htm", "*.html", "*.mht", "*.zip" };
                RadEditorNoteVersionContent.DocumentManager.MaxUploadFileSize = 209715200;
                RadEditorNoteVersionContent.DocumentManager.ContentProviderTypeName = typeof(ExtendedFileProvider).AssemblyQualifiedName;
                getCustomLinks(RadEditorNoteVersionContent);

                RadEditorTechNotes.DocumentManager.ViewPaths = readmeDocumentPath;
                RadEditorTechNotes.DocumentManager.UploadPaths = readmeDocumentPath;
                RadEditorTechNotes.DocumentManager.DeletePaths = readmeDocumentPath;
                RadEditorTechNotes.DocumentManager.SearchPatterns = new string[] { "*.doc", "*.txt", "*.docx", "*.xls", "*.xlsx", "*.pdf", "*.htm", "*.html", "*.mht", "*.zip" };
                RadEditorTechNotes.DocumentManager.MaxUploadFileSize = 209715200;
                RadEditorTechNotes.DocumentManager.ContentProviderTypeName = typeof(ExtendedFileProvider).AssemblyQualifiedName;
                getCustomLinks(RadEditorTechNotes);

                RadEditorContent.DocumentManager.ViewPaths = readmeDocumentPath;
                RadEditorContent.DocumentManager.UploadPaths = readmeDocumentPath;
                RadEditorContent.DocumentManager.DeletePaths = readmeDocumentPath;
                RadEditorContent.DocumentManager.SearchPatterns = new string[] { "*.doc", "*.txt", "*.docx", "*.xls", "*.xlsx", "*.pdf", "*.htm", "*.html", "*.mht", "*.zip" };
                RadEditorContent.DocumentManager.MaxUploadFileSize = 209715200;
                RadEditorContent.DocumentManager.ContentProviderTypeName = typeof(ExtendedFileProvider).AssemblyQualifiedName;
                getCustomLinks(RadEditorContent);
                pnlSearchBrowseInformation.Style["display"] = "none";

                if ((drpProducts.SelectedValue == "41") && (drpCategory.SelectedValue == "Content"))
                {
                    pnlSearchBrowseInformation.Style["display"] = "show";
                }

            }
        }

        protected void getProducts()
        {
            DataSet ds = new DataSet();

            XElement xml = XElement.Load(DBProductsfilesPath);
            DataTable dt = new DataTable("Products");
            dt.Columns.Add(new DataColumn("ID", typeof(string)));
            dt.Columns.Add(new DataColumn("DisplayName", typeof(string)));

            var products = xml.Descendants("Product")
                .Where(c => c.Descendants("Administrator")
                             .Any(r => (string)r.Attribute("Login") == strLogonUser))
                .ToList().
                Select(f => new
                {
                    DisplayName = f.Attributes().Where(x => x.Name == "DisplayName").
                        Select(x => x.Value).FirstOrDefault(),
                    ID = f.Attributes().Where(x => x.Name == "ID").
                    Select(x => x.Value).FirstOrDefault()
                }).OrderBy(s => (string)s.DisplayName);

            foreach (var element in products)
            {
                var row = dt.NewRow();
                row["DisplayName"] = element.DisplayName;
                row["ID"] = element.ID;
                dt.Rows.Add(row);
            }

            ds.Tables.Add(dt);

            drpProducts.DataSource = ds;
            drpProducts.DataTextField = "DisplayName";
            drpProducts.DataValueField = "ID";
            drpProducts.DataBind();
            drpProducts.Items.Insert(0, "--Select--");
        }

        protected void drpProducts_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (drpProducts.SelectedItem.Value != "--Select--")
            {
                getProductCategories();
                drpCategory_SelectedIndexChanged(sender, e);
            }
            else
            {
                drpCategory.Items.Clear();
                drpCategory.Items.Insert(0, "--Select--");
                drpCategory_SelectedIndexChanged(sender, e);
            }
        }

        protected void getProductCategories()
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(DBProductsfilesPath);

            XmlNodeList nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']");

            XmlNode xNodeProductName = doc.SelectSingleNode("/Products/Product[@ID='" + drpProducts.SelectedValue + "']");

            XPathDocument xPathDoc = new XPathDocument(DBProductsfilesPath);
            XPathNavigator navigator = xPathDoc.CreateNavigator();
            XPathExpression xPression = navigator.Compile("/Products/Product[@ID='" + drpProducts.SelectedValue + "']");
            XPathNodeIterator nodes = (XPathNodeIterator)navigator.Evaluate(xPression);
            XPathItem[] items = nodes.Cast<XPathItem>().ToArray();


            string productName = xNodeProductName.Attributes["Name"].Value;

            if (drpProducts.SelectedValue != "--Select--")
            {
                DataSet ds = new DataSet();
                DataTable dt = new DataTable("Category");
                dt.Columns.Add(new DataColumn("Name", typeof(string)));
                dt.Columns.Add(new DataColumn("DisplayName", typeof(string)));
                DataRow dr;


                for (int i = 0; i < nodeList[0].ChildNodes.Count; i++)
                {
                    string name = nodeList[0].ChildNodes[i].Name;
                    int categoryStatus = 1;

                    string children = nodeList[0].ChildNodes[i].ChildNodes.Count.ToString();
                    string displayName = "";

                    if (nodeList[0].ChildNodes[i].Attributes["Status"] != null)
                    {

                        if (nodeList[0].ChildNodes[i].Attributes["Status"].Value == "0")
                        {
                            categoryStatus = 0;

                        }
                    }

                    if ((name != null) && (name != "Administrators") && (name != "Training") && (categoryStatus == 1))
                    {

                        dr = dt.NewRow();
                        if (children == "0")
                        {
                            displayName = name + " (No Entries Found)";
                        }
                        else
                        {
                            displayName = name;
                        }
                        dr["Name"] = name;
                        dr["DisplayName"] = displayName;

                        dt.Rows.Add(dr);
                    }
                    else if ((name != null) && (name == "Training"))
                    {
                        dr = dt.NewRow();
                        string attr = nodeList[0].ChildNodes[i].Attributes.Count.ToString();
                        if (attr == "0")
                        {
                            displayName = name + " (No Entries Found)";
                        }
                        else
                        {
                            displayName = name;
                        }
                        dr["Name"] = name;
                        dr["DisplayName"] = displayName;

                        dt.Rows.Add(dr);

                    }
                }
                //productName = xNodeProductName.Attributes["Name"].Value;


                ds.Tables.Add(dt);
                drpCategory.DataSource = ds;
                drpCategory.DataTextField = "DisplayName";
                drpCategory.DataValueField = "Name";
                drpCategory.DataBind();
                drpCategory.Items.Insert(0, "--Select--");

            }
        }

        protected void getCustomLinks(RadEditor EditorCustomLink)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(DBProductsfilesPath);
            XmlNodeList nodeList;

            XElement xml = XElement.Load(DBProductsfilesPath);

            EditorCustomLink.Links.Clear();
            EditorCustomLink.Attributes["width"] = "240px";

            var products = xml.Descendants("Product").
                Select(f => new
                {
                    Name = f.Attributes().Where(x => x.Name == "Name").
                        Select(x => x.Value).FirstOrDefault(),
                    ID = f.Attributes().Where(x => x.Name == "ID").
                    Select(x => x.Value).FirstOrDefault()
                }).OrderBy(s => (string)s.Name);


            foreach (var element in products)
            {
                nodeList = doc.SelectNodes("/Products/Product[@ID='" + element.ID + "']");

                Telerik.Web.UI.EditorLink Products = new Telerik.Web.UI.EditorLink();

                Products.Name = Server.HtmlEncode(element.Name);
                Products.ToolTip = element.Name + " Customer Support Site";
                Products.Href = hdnBaseUrl.Value + "ProductCategories.aspx?prdid=" + element.ID;

                for (int i = 0; i < nodeList[0].ChildNodes.Count; i++)
                {
                    string name = nodeList[0].ChildNodes[i].Name;
                    string categoryStatus = "1";

                    if (nodeList[0].ChildNodes[i].Attributes["Status"] != null)
                    {
                        categoryStatus = nodeList[0].ChildNodes[i].Attributes["Status"].Value;
                    }

                    if ((name != null) && (name != "Administrators") && (name != "Training") && (categoryStatus == "1"))
                    {

                        if (name == "Announcements")
                        {
                            Telerik.Web.UI.EditorLink Announcements = new Telerik.Web.UI.EditorLink();
                            Announcements.Name = name;
                            Announcements.Href = hdnBaseUrl.Value + "ProductAnnouncements.aspx?prdId=" + element.ID;
                            Announcements.ToolTip = element.Name + " Announcements";
                            Products.ChildLinks.Add(Announcements);
                        }

                        if (name == "TechnicalNotesandWhitePapers")
                        {
                            Telerik.Web.UI.EditorLink TechnicalNotes = new Telerik.Web.UI.EditorLink();
                            TechnicalNotes.Name = "TechnicalNotes";
                            TechnicalNotes.Href = hdnBaseUrl.Value + "TechNotes.aspx?prdId=" + element.ID + "&Cat=TechnicalNotesandWhitePapers";
                            TechnicalNotes.ToolTip = element.Name + " TechnicalNotes";
                            Products.ChildLinks.Add(TechnicalNotes);
                        }

                        if (name == "ServicePacksandFixes")
                        {
                            Telerik.Web.UI.EditorLink ServicePacksandFixes = new EditorLink();
                            ServicePacksandFixes.Name = "ServicePacksandFixes";
                            ServicePacksandFixes.Href = hdnBaseUrl.Value + "ProductUpdates.aspx?prdId=" + element.ID + "&Cat=ServicePacksandFixes";
                            ServicePacksandFixes.ToolTip = element.Name + " ServicePacksandFixes";
                            Products.ChildLinks.Add(ServicePacksandFixes);
                        }

                        if (name == "FreewareToolsandUtilities")
                        {
                            Telerik.Web.UI.EditorLink FreewareToolsandUtilities = new EditorLink();
                            FreewareToolsandUtilities.Name = "FreewareToolsandUtilities";
                            FreewareToolsandUtilities.Href = hdnBaseUrl.Value + "ProductUpdates.aspx?prdId=" + element.ID + "&Cat=FreewareToolsandUtilities";
                            FreewareToolsandUtilities.ToolTip = element.Name + " FreewareToolsandUtilities";
                            Products.ChildLinks.Add(FreewareToolsandUtilities);
                        }

                        if (name == "Content")
                        {
                            Telerik.Web.UI.EditorLink Content = new EditorLink();
                            Content.Name = "Content";
                            Content.Href = hdnBaseUrl.Value + "ProductUpdates.aspx?prdId=" + element.ID + "&Cat=Content";
                            Content.ToolTip = element.Name + " Content";
                            Products.ChildLinks.Add(Content);
                        }
                    }
                }

                EditorCustomLink.Links.Add(Products);
            }
        }

        protected void getAnnouncementYears()
        {
            XmlDocument doc = new XmlDocument();

            doc.Load(DBProductsfilesPath);

            XmlNodeList nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/Announcements");

            if (nodeList.Count > 0)
            {
                DataSet ds = new DataSet();
                DataTable dt = new DataTable("Announcement");
                dt.Columns.Add(new DataColumn("Year", typeof(string)));
                DataRow dr;
                
                gridCurrentAnnouncements.RowDataBound += new GridViewRowEventHandler(gridCurrentAnnouncements_RowDataBound);
                gridYears.RowDataBound += new GridViewRowEventHandler(gridYears_RowDataBound);

                for (int i = 0; i < nodeList[0].ChildNodes.Count; i++)
                {
                    string announcementDt = nodeList[0].ChildNodes[i].Attributes["Date"].Value;

                        if (!String.IsNullOrEmpty(announcementDt))
                        {
                            List<string> sdate = announcementDt.Split('/').Select(p => p.Trim()).ToList();

                            dr = dt.NewRow();
                            dr["Year"] = sdate[2];

                            if (dr["Year"].ToString() == DateTime.Now.Year.ToString())
                            {
                                getContentbyYear(dr["Year"].ToString(), gridCurrentAnnouncements);
                            }
                            else
                            {
                                dt.Rows.Add(dr);
                            }
                        }
                    

                }
                dt = GetDistinctRecords(dt, "Year");

                ds.Tables.Add(dt);

                ds.Tables[0].DefaultView.Sort = "Year desc";
                DataTable dtord = ds.Tables[0].DefaultView.ToTable();
                ds.Tables[0].Rows.Clear();
                foreach (DataRow row in dtord.Rows)
                    ds.Tables[0].Rows.Add(row.ItemArray);

                gridYears.DataSource = ds;
                gridYears.DataBind();

                //getCustomLinks(RadEditorAnnouncements);
            }

            if (nodeList[0].ChildNodes.Count == 0)
            {
                lblAnnouncementMsg.Text = "None Available";
                lblAnnouncementMsg.Style["display"] = "show";
                gridCurrentAnnouncements.Style["display"] = "none";
            }
            else
            {
                lblAnnouncementMsg.Style["display"] = "none";
                gridCurrentAnnouncements.Style["display"] = "show";
            }
        }

        protected void getVersionUpdates()
        {
            XmlDocument doc = new XmlDocument();
            DataSet ds = new DataSet();

            doc.Load(DBProductsfilesPath);

            XmlNode node = doc.SelectSingleNode("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "");

            if ((drpCategory.SelectedValue == "ServicePacksandFixes") || (drpCategory.SelectedValue == "FreewareToolsandUtilities") || (drpCategory.SelectedValue == "Content") || (drpCategory.SelectedValue == "TechnicalNotesandWhitePapers"))
            {
                if (node.Attributes["PleaseNote"] != null)
                {
                    if (node.Attributes["PleaseNote"].Value == "")
                    {
                        divPleaseNote.InnerHtml = "None Available";
                    }
                    else
                    {
                        divPleaseNote.InnerHtml = node.Attributes["PleaseNote"].Value;
                    }
                }
                else
                {
                    divPleaseNote.InnerHtml = "None Available";
                }

                if (node.Attributes["ImportantNote"] != null)
                {
                    if (node.Attributes["ImportantNote"].Value == "")
                    {
                        divImportantNote.InnerHtml = "None Available";
                    }
                    else
                    {
                        divImportantNote.InnerHtml = node.Attributes["ImportantNote"].Value;
                    }
                }
                else
                {
                    divImportantNote.InnerHtml = "None Available";
                }

                if (node.Attributes["CurrentVersionInfo"] != null)
                {
                    if (node.Attributes["CurrentVersionInfo"].Value == "")
                    {
                        divCurrentVerInfo.InnerHtml = "None Available";
                    }
                    else
                    {
                        divCurrentVerInfo.InnerHtml = node.Attributes["CurrentVersionInfo"].Value;
                    }
                }
                else
                {
                    divCurrentVerInfo.InnerHtml = "None Available";
                }


                PopulateDropdownGroupSubGroupByVersion();

                if (node["CurrentVersionUpdates"] != null)
                {
                    if (node["CurrentVersionUpdates"].ChildNodes.Count != 0)
                    {

                        DataTable dtCurrentVersionGroupNames = new DataTable("GroupName");
                        dtCurrentVersionGroupNames.Columns.Add(new DataColumn("GroupName", typeof(string)));
                        dtCurrentVersionGroupNames.Columns.Add(new DataColumn("Priority", typeof(string)));
                        DataRow drCurrentVersionGroups;
                        DataSet dsCurrentVersionGroups = new DataSet();

                        DataSet dtGroupNames = getGroupDetailsbyNode("GroupsCurrentVersion", "GroupName");
                        DataTable dtContentGroups = getDistinctGroupNamesSelectedNode("CurrentVersionUpdates");

                        for (int j = 0; j < dtGroupNames.Tables["GroupName"].Rows.Count; j++)
                        {
                            string strgroupname = dtGroupNames.Tables["GroupName"].Rows[j]["GroupName"].ToString();

                            if (dtContentGroups.AsEnumerable().Any(row => strgroupname == row.Field<string>("GroupName")))
                            {
                                drCurrentVersionGroups = dtCurrentVersionGroupNames.NewRow();
                                drCurrentVersionGroups["GroupName"] = dtGroupNames.Tables["GroupName"].Rows[j]["GroupName"].ToString();
                                drCurrentVersionGroups["Priority"] = dtGroupNames.Tables["GroupName"].Rows[j]["Priority"].ToString();
                                dtCurrentVersionGroupNames.Rows.Add(drCurrentVersionGroups);
                            }
                        }

                        dsCurrentVersionGroups.Tables.Add(dtCurrentVersionGroupNames);

                        gridGroupNamesCurrentVersion.DataSource = dsCurrentVersionGroups;
                        gridGroupNamesCurrentVersion.DataBind();

                        gridGroupNamesCurrentVersion.Visible = true;

                    }
                    else
                    {
                        gridGroupNamesCurrentVersion.Visible = false;
                    }
                }
                else
                {
                    gridGroupNamesCurrentVersion.Visible = false;
                }

                if (node["PreviousVersionUpdates"] != null)
                {
                    if (node["PreviousVersionUpdates"].ChildNodes.Count != 0)
                    {
                        DataTable dtPreviousVersionGroupNames = new DataTable("GroupName");
                        dtPreviousVersionGroupNames.Columns.Add(new DataColumn("GroupName", typeof(string)));
                        dtPreviousVersionGroupNames.Columns.Add(new DataColumn("Priority", typeof(string)));
                        DataRow drPreviousVersionGroups;
                        DataSet dsPreviousVersionGroups = new DataSet();

                        DataSet dtGroupNames = getGroupDetailsbyNode("GroupsPreviousVersion", "GroupName");
                        DataTable dtContentGroups = getDistinctGroupNamesSelectedNode("PreviousVersionUpdates");

                        for (int j = 0; j < dtGroupNames.Tables["GroupName"].Rows.Count; j++)
                        {
                            string strgroupname = dtGroupNames.Tables["GroupName"].Rows[j]["GroupName"].ToString();

                            if (dtContentGroups.AsEnumerable().Any(row => strgroupname == row.Field<string>("GroupName")))
                            {
                                drPreviousVersionGroups = dtPreviousVersionGroupNames.NewRow();
                                drPreviousVersionGroups["GroupName"] = dtGroupNames.Tables["GroupName"].Rows[j]["GroupName"].ToString();
                                drPreviousVersionGroups["Priority"] = dtGroupNames.Tables["GroupName"].Rows[j]["Priority"].ToString();
                                dtPreviousVersionGroupNames.Rows.Add(drPreviousVersionGroups);
                            }
                        }

                        dsPreviousVersionGroups.Tables.Add(dtPreviousVersionGroupNames);

                        gridGroupNamesPreviousVersion.DataSource = dsPreviousVersionGroups;
                        gridGroupNamesPreviousVersion.DataBind();
                        gridGroupNamesPreviousVersion.Visible = true;
                    }
                    else
                    {
                        gridGroupNamesPreviousVersion.Visible = false;
                    }
                }
                else
                {
                    gridGroupNamesPreviousVersion.Visible = false;
                }
            }

            if (drpCategory.SelectedValue == "TechnicalNotesandWhitePapers")
            {
                XmlNodeList nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "");

                if (nodeList.Count > 0)
                {
                    DataSet dtGroupNamesTechNotes = getGroupDetailsbyNode("GroupsTechnicalNotes", "GroupName");
                    DataSet dtSubGroupNamesTechNotes = getGroupDetailsbyNode("SubGroupsTechnicalNotes", "SubGroupName");

                    DataTable dtTechnicalNotes = new DataTable("GroupName");
                    dtTechnicalNotes.Columns.Add(new DataColumn("GroupName", typeof(string)));
                    dtTechnicalNotes.Columns.Add(new DataColumn("Priority", typeof(int)));
                    DataRow drTechnicalNotes;
                    DataSet dsTechnicalNotes = new DataSet();

                    DataTable dtContentGroups = getDistinctGroupNamesSelectedNode("TechnicalNotes");

                    for (int j = 0; j < dtGroupNamesTechNotes.Tables["GroupName"].Rows.Count; j++)
                    {
                        string strgroupname = dtGroupNamesTechNotes.Tables["GroupName"].Rows[j]["GroupName"].ToString();

                        if (dtContentGroups.AsEnumerable().Any(row => strgroupname == row.Field<string>("GroupName")))
                        {
                            drTechnicalNotes = dtTechnicalNotes.NewRow();
                            drTechnicalNotes["GroupName"] = dtGroupNamesTechNotes.Tables["GroupName"].Rows[j]["GroupName"].ToString();
                            drTechnicalNotes["Priority"] = dtGroupNamesTechNotes.Tables["GroupName"].Rows[j]["Priority"].ToString();
                            dtTechnicalNotes.Rows.Add(drTechnicalNotes);
                        }
                    }

                    dsTechnicalNotes.Tables.Add(dtTechnicalNotes);

                    gridGroupNamesTechnicalNotes.DataSource = dsTechnicalNotes;
                    gridGroupNamesTechnicalNotes.DataBind();

                    drpTechNotesGroupNames.DataSource = dtGroupNamesTechNotes;
                    drpTechNotesGroupNames.DataTextField = "GroupName";
                    drpTechNotesGroupNames.DataValueField = "GroupName";
                    drpTechNotesGroupNames.DataBind();
                    drpTechNotesGroupNames.Items.Insert(0, "--Select--");

                    drpTechNotesSubGroupNames.DataSource = dtSubGroupNamesTechNotes;
                    drpTechNotesSubGroupNames.DataTextField = "SubGroupName";
                    drpTechNotesSubGroupNames.DataValueField = "SubGroupName";
                    drpTechNotesSubGroupNames.DataBind();
                    drpTechNotesSubGroupNames.Items.Insert(0, "--None--");
                }
            }

            if (drpCategory.SelectedValue == "Training")
            {
                if (node.Attributes["TrainingLink"] != null)
                {
                    if (node.Attributes["TrainingLink"].Value == "")
                    {
                        txtTrainingLink.Text = "";
                    }
                    else
                    {
                        txtTrainingLink.Text = node.Attributes["TrainingLink"].Value;
                    }
                }

                if (node.Attributes["Target"] != null)
                {
                    if (node.Attributes["Target"].Value != "")
                    {
                        drpTrainingTarget.SelectedValue = node.Attributes["Target"].Value;
                    }
                }
            }
        }

        protected void btnAddFile_Click(object sender, EventArgs e)
        {
            string asyFileName = null;
            string asyFileExtension = null;
            Int64 asyFileSize = 0;
            string selDrpProd = drpProducts.SelectedValue;

            XmlNode xProd = DBReader.getFullProduct(selDrpProd);

            string prodPathName = xProd.Attributes["Name"].Value.ToString();


            using (fileUploadTechNotes)
            using (fileUpload)
            {
                XElement xml = XElement.Load(DBProductsfilesPath);

                string elementcat = null;
                string elementsubcat = null;

                if ((hdnFileUploadType.Value == "CurrentVersionUpdateAdd") || (hdnFileUploadType.Value == "CurrentVersionUpdateCopy") || (hdnFileUploadType.Value == "CurrentVersionUpdateEdit"))
                {
                    elementcat = "CurrentVersionUpdates";
                    elementsubcat = "CurrentVersion";
                }
                else
                {
                    elementcat = "PreviousVersionUpdates";
                    elementsubcat = "PreviousVersion";
                }

                if ((hdnFileUploadType.Value != "PreviousVersionUpdateEdit") &&
                    (hdnFileUploadType.Value != "CurrentVersionUpdateEdit") &&
                    (rdbtnFileType.SelectedValue == "1"))
                {
                    var filenametitle = xml.Elements("Product").
                    Where(el => el.Attribute("ID").Value.Equals(drpProducts.SelectedValue)).
                    SelectMany(el => el.Elements(drpCategory.SelectedItem.Value).Elements(elementcat).Elements(elementsubcat)).
                    Select(f => new
                    {
                        FileName = f.Attributes().Where(x => x.Name == "FileName").
                            Select(x => x.Value).FirstOrDefault(),
                        FileTitle = f.Attributes().Where(x => x.Name == "FileTitle").
                            Select(x => x.Value).FirstOrDefault()
                    }
                        );
                    foreach (UploadedFile file in fileUpload.UploadedFiles)
                    {
                        asyFileName = file.GetName();
                    }

                    foreach (var element in filenametitle)
                    {
                        if (element.FileName == asyFileName)
                        {
                            this.Context.Items["Title"] = "";
                            this.Context.Items["Message"] = "This File selected already exists. Please select a different File.";
                            Server.Transfer("Response.aspx", true);
                        }
                    }
                }

                string ContentStatus = "0";

                if (chkboxDisplayContent.Checked == true)
                    ContentStatus = "1";

                XmlDocument xdocAddFileContent = new XmlDocument();

                xdocAddFileContent.Load(DBProductsfilesPath);

                XmlNode xnodeID = xdocAddFileContent.SelectSingleNode("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "");

                if ((hdnFileUploadType.Value == "CurrentVersionUpdateAdd") || (hdnFileUploadType.Value == "CurrentVersionUpdateCopy"))
                {
                    if (xnodeID["CurrentVersionUpdates"] == null)
                    {
                        XmlElement newVersionElem = xdocAddFileContent.CreateElement("CurrentVersionUpdates");
                        xnodeID.AppendChild(newVersionElem);
                    }

                    int CurrentVersionID = 0;
                    XmlNode xnodeCurrentVersion = xdocAddFileContent.SelectSingleNode("//Products/Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "/CurrentVersionUpdates/CurrentVersion/@ID[not(. <=../preceding-sibling::CurrentVersion/@iD) and not(. <=../following-sibling::CurrentVersion/@ID)]");

                    if (xnodeCurrentVersion == null)
                    {
                        CurrentVersionID = 1;
                    }
                    else
                    {
                        CurrentVersionID = Convert.ToInt32(xnodeCurrentVersion.Value) + 1;
                    }

                    XmlElement newElem = xdocAddFileContent.CreateElement("CurrentVersion");

                    XmlAttribute ID = xdocAddFileContent.CreateAttribute("ID");
                    ID.Value = CurrentVersionID.ToString();
                    newElem.Attributes.Append(ID);

                    XmlAttribute date = xdocAddFileContent.CreateAttribute("Date");
                    DateTime ddate = Convert.ToDateTime(txtFileUploadDate.Text);
                    date.Value = ddate.ToString("MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    newElem.Attributes.Append(date);

                    XmlAttribute groupName = xdocAddFileContent.CreateAttribute("GroupName");
                    groupName.Value = drpGroupName.SelectedItem.Value;
                    newElem.Attributes.Append(groupName);

                    string subgroupvalue = drpSubGroupName.SelectedValue;
                    if (subgroupvalue == "--None--")
                    {
                        subgroupvalue = "";
                    }
                    else
                    {
                        subgroupvalue = drpSubGroupName.SelectedValue;
                    }

                    XmlAttribute subgroupName = xdocAddFileContent.CreateAttribute("SubGroupName");
                    subgroupName.Value = subgroupvalue;
                    newElem.Attributes.Append(subgroupName);

                    XmlAttribute importantUpdate = xdocAddFileContent.CreateAttribute("ImportantUpdate");
                    importantUpdate.Value = FirstCharToUpper(txtImportantUpdate.Text);
                    newElem.Attributes.Append(importantUpdate);

                    if (rdbtnFileType.SelectedValue == "3")
                    {
                        XmlAttribute fileType = xdocAddFileContent.CreateAttribute("FileType");
                        fileType.Value = rdbtnFileType.SelectedValue;
                        newElem.Attributes.Append(fileType);

                        XmlAttribute fileLink = xdocAddFileContent.CreateAttribute("FileLink");
                        fileLink.Value = "";
                        newElem.Attributes.Append(fileLink);

                        XmlAttribute fileTitle = xdocAddFileContent.CreateAttribute("FileTitle");
                        fileTitle.Value = "";
                        newElem.Attributes.Append(fileTitle);

                        XmlAttribute fileName = xdocAddFileContent.CreateAttribute("FileName");
                        fileName.Value = "";
                        newElem.Attributes.Append(fileName);

                        XmlAttribute filesize = xdocAddFileContent.CreateAttribute("Filesize");
                        filesize.Value = "";
                        newElem.Attributes.Append(filesize);
                    }
                    else if (rdbtnFileType.SelectedValue == "2")
                    {
                        XmlAttribute fileType = xdocAddFileContent.CreateAttribute("FileType");
                        fileType.Value = rdbtnFileType.SelectedValue;
                        newElem.Attributes.Append(fileType);

                        XmlAttribute fileLink = xdocAddFileContent.CreateAttribute("FileLink");
                        fileLink.Value = txtFileLink.Text;
                        newElem.Attributes.Append(fileLink);

                        XmlAttribute fileTitle = xdocAddFileContent.CreateAttribute("FileTitle");
                        fileTitle.Value = FirstCharToUpper(txtFileTitle.Text);
                        newElem.Attributes.Append(fileTitle);

                        XmlAttribute fileName = xdocAddFileContent.CreateAttribute("FileName");
                        fileName.Value = "";
                        newElem.Attributes.Append(fileName);

                        XmlAttribute filesize = xdocAddFileContent.CreateAttribute("Filesize");
                        filesize.Value = "";
                        newElem.Attributes.Append(filesize);

                    }
                    else
                    {
                        XmlAttribute fileType = xdocAddFileContent.CreateAttribute("FileType");
                        fileType.Value = rdbtnFileType.SelectedValue;
                        newElem.Attributes.Append(fileType);

                        XmlAttribute fileLink = xdocAddFileContent.CreateAttribute("FileLink");
                        fileLink.Value = txtFileLink.Text;
                        newElem.Attributes.Append(fileLink);

                        XmlAttribute fileTitle = xdocAddFileContent.CreateAttribute("FileTitle");
                        fileTitle.Value = FirstCharToUpper(txtFileTitle.Text);
                        newElem.Attributes.Append(fileTitle);

                        foreach (UploadedFile file in fileUpload.UploadedFiles)
                        {
                            asyFileName = file.GetName();
                            asyFileExtension = file.GetExtension().Replace(".", string.Empty);
                            asyFileSize = file.ContentLength;

                            string spath = storePath;
                            spath = spath + "\\" + prodPathName + "\\" + drpCategory.SelectedValue + "\\" + asyFileName;

                            file.SaveAs(spath);
                        }

                        XmlAttribute fileName = xdocAddFileContent.CreateAttribute("FileName");
                        //fileName.Value = fileUpload.FileName;
                        fileName.Value = asyFileName;
                        newElem.Attributes.Append(fileName);


                        string[] sizes = { "Bytes", "KB", "MB", "GB" };
                        //double len = fileUpload.PostedFile.ContentLength;
                        double len = asyFileSize;
                        int order = 0;
                        while (len >= 1024 && order + 1 < sizes.Length)
                        {
                            order++;
                            len = len / 1024;
                        }

                        // Adjust the format string to your preferences. For example "{0:0.#}{1}" would
                        // show a single decimal place, and no space.
                        string result = String.Format("{0:0.##} {1}", len, sizes[order]);

                        XmlAttribute filesize = xdocAddFileContent.CreateAttribute("Filesize");
                        filesize.Value = result;
                        newElem.Attributes.Append(filesize);
                    }

                    XmlAttribute desc = xdocAddFileContent.CreateAttribute("Description");
                    desc.Value = FirstCharToUpper(RadEditorContent.Content.Replace(hdnBaseUrl.Value, ""));
                    newElem.Attributes.Append(desc);

                    int iContentPriority = getCPContentPriorityID(drpProducts.SelectedValue, drpCategory.SelectedItem.Value, "CurrentVersionUpdates", "CurrentVersion", drpGroupName.SelectedItem.Value, subgroupvalue);

                    XmlAttribute GSCPriority = xdocAddFileContent.CreateAttribute("GSCPriority");
                    GSCPriority.Value = iContentPriority.ToString();
                    newElem.Attributes.Append(GSCPriority);

                    XmlAttribute status = xdocAddFileContent.CreateAttribute("Status");
                    status.Value = ContentStatus;
                    newElem.Attributes.Append(status);

                    XmlNode xnodeCurrentVersionUpadte = xdocAddFileContent.SelectSingleNode("//Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/CurrentVersionUpdates");
                    xnodeCurrentVersionUpadte.AppendChild(newElem);

                }
                else if ((hdnFileUploadType.Value == "PreviousVersionUpdateAdd") || (hdnFileUploadType.Value == "PreviousVersionUpdateCopy"))
                {
                    if (xnodeID["PreviousVersionUpdates"] == null)
                    {
                        XmlElement newVersionElem = xdocAddFileContent.CreateElement("PreviousVersionUpdates");
                        xnodeID.AppendChild(newVersionElem);
                    }

                    int PreviousVersionID = 0;
                    XmlNode xnodePreviousVersion = xdocAddFileContent.SelectSingleNode("//Products/Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "/PreviousVersionUpdates/PreviousVersion/@ID[not(. <=../preceding-sibling::PreviousVersion/@iD) and not(. <=../following-sibling::PreviousVersion/@ID)]");

                    if (xnodePreviousVersion == null)
                    {
                        PreviousVersionID = 1;
                    }
                    else
                    {
                        PreviousVersionID = Convert.ToInt32(xnodePreviousVersion.Value) + 1;
                    }

                    XmlElement newElem = xdocAddFileContent.CreateElement("PreviousVersion");

                    XmlAttribute ID = xdocAddFileContent.CreateAttribute("ID");
                    ID.Value = PreviousVersionID.ToString();
                    newElem.Attributes.Append(ID);

                    XmlAttribute date = xdocAddFileContent.CreateAttribute("Date");
                    DateTime ddate = Convert.ToDateTime(txtFileUploadDate.Text);
                    date.Value = ddate.ToString("MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    newElem.Attributes.Append(date);

                    XmlAttribute groupName = xdocAddFileContent.CreateAttribute("GroupName");
                    groupName.Value = drpGroupName.SelectedItem.Value;
                    newElem.Attributes.Append(groupName);

                    string subgroupvalue = drpSubGroupName.SelectedValue;
                    if (subgroupvalue == "--None--")
                    {
                        subgroupvalue = "";
                    }
                    else
                    {
                        subgroupvalue = drpSubGroupName.SelectedValue;
                    }

                    XmlAttribute subgroupName = xdocAddFileContent.CreateAttribute("SubGroupName");
                    subgroupName.Value = subgroupvalue;
                    newElem.Attributes.Append(subgroupName);

                    XmlAttribute importantUpdate = xdocAddFileContent.CreateAttribute("ImportantUpdate");
                    importantUpdate.Value = FirstCharToUpper(txtImportantUpdate.Text);
                    newElem.Attributes.Append(importantUpdate);

                    if (rdbtnFileType.SelectedValue == "3")
                    {
                        XmlAttribute fileType = xdocAddFileContent.CreateAttribute("FileType");
                        fileType.Value = rdbtnFileType.SelectedValue;
                        newElem.Attributes.Append(fileType);

                        XmlAttribute fileLink = xdocAddFileContent.CreateAttribute("FileLink");
                        fileLink.Value = "";
                        newElem.Attributes.Append(fileLink);

                        XmlAttribute fileTitle = xdocAddFileContent.CreateAttribute("FileTitle");
                        fileTitle.Value = "";
                        newElem.Attributes.Append(fileTitle);

                        XmlAttribute fileName = xdocAddFileContent.CreateAttribute("FileName");
                        fileName.Value = "";
                        newElem.Attributes.Append(fileName);

                        XmlAttribute filesize = xdocAddFileContent.CreateAttribute("Filesize");
                        filesize.Value = "";
                        newElem.Attributes.Append(filesize);
                    }
                    else if (rdbtnFileType.SelectedValue == "2")
                    {
                        XmlAttribute fileType = xdocAddFileContent.CreateAttribute("FileType");
                        fileType.Value = rdbtnFileType.SelectedValue;
                        newElem.Attributes.Append(fileType);

                        XmlAttribute fileLink = xdocAddFileContent.CreateAttribute("FileLink");
                        fileLink.Value = txtFileLink.Text;
                        newElem.Attributes.Append(fileLink);

                        XmlAttribute fileTitle = xdocAddFileContent.CreateAttribute("FileTitle");
                        fileTitle.Value = FirstCharToUpper(txtFileTitle.Text);
                        newElem.Attributes.Append(fileTitle);

                        XmlAttribute fileName = xdocAddFileContent.CreateAttribute("FileName");
                        fileName.Value = "";
                        newElem.Attributes.Append(fileName);

                        XmlAttribute filesize = xdocAddFileContent.CreateAttribute("Filesize");
                        filesize.Value = "";
                        newElem.Attributes.Append(filesize);

                    }
                    else
                    {
                        XmlAttribute fileType = xdocAddFileContent.CreateAttribute("FileType");
                        fileType.Value = rdbtnFileType.SelectedValue;
                        newElem.Attributes.Append(fileType);

                        XmlAttribute fileLink = xdocAddFileContent.CreateAttribute("FileLink");
                        fileLink.Value = txtFileLink.Text;
                        newElem.Attributes.Append(fileLink);

                        XmlAttribute fileTitle = xdocAddFileContent.CreateAttribute("FileTitle");
                        fileTitle.Value = FirstCharToUpper(txtFileTitle.Text);
                        newElem.Attributes.Append(fileTitle);

                        foreach (UploadedFile file in fileUpload.UploadedFiles)
                        {
                            asyFileName = file.GetName();
                            asyFileExtension = file.GetExtension().Replace(".", string.Empty);
                            asyFileSize = file.ContentLength;

                            string spath = storePath;
                            spath = spath + "\\" + prodPathName + "\\" + drpCategory.SelectedValue + "\\" + asyFileName;

                            file.SaveAs(spath);
                        }

                        XmlAttribute fileName = xdocAddFileContent.CreateAttribute("FileName");
                        //fileName.Value = fileUpload.FileName;
                        fileName.Value = asyFileName;
                        newElem.Attributes.Append(fileName);

                        string[] sizes = { "Bytes", "KB", "MB", "GB" };
                        //double len = fileUpload.PostedFile.ContentLength;
                        double len = asyFileSize;
                        int order = 0;
                        while (len >= 1024 && order + 1 < sizes.Length)
                        {
                            order++;
                            len = len / 1024;
                        }

                        // Adjust the format string to your preferences. For example "{0:0.#}{1}" would
                        // show a single decimal place, and no space.
                        string result = String.Format("{0:0.##} {1}", len, sizes[order]);

                        XmlAttribute filesize = xdocAddFileContent.CreateAttribute("Filesize");
                        filesize.Value = result;
                        newElem.Attributes.Append(filesize);
                    }

                    XmlAttribute desc = xdocAddFileContent.CreateAttribute("Description");
                    desc.Value = FirstCharToUpper(RadEditorContent.Content.Replace(hdnBaseUrl.Value, ""));
                    newElem.Attributes.Append(desc);

                    int iContentPriority = getCPContentPriorityID(drpProducts.SelectedValue, drpCategory.SelectedItem.Value, "PreviousVersionUpdates", "PreviousVersion", drpGroupName.SelectedItem.Value, subgroupvalue);

                    XmlAttribute GSCPriority = xdocAddFileContent.CreateAttribute("GSCPriority");
                    GSCPriority.Value = iContentPriority.ToString();
                    newElem.Attributes.Append(GSCPriority);

                    XmlAttribute status = xdocAddFileContent.CreateAttribute("Status");
                    status.Value = ContentStatus;
                    newElem.Attributes.Append(status);

                    XmlNode xnodePreviousVersionUpadte = xdocAddFileContent.SelectSingleNode("//Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/PreviousVersionUpdates");
                    xnodePreviousVersionUpadte.AppendChild(newElem);

                }
                else
                {
                    string recordID = hdnFileUploadRecordID.Value;

                    XmlNode xnodeVersionEdit = null;

                    if (hdnFileUploadType.Value == "CurrentVersionUpdateEdit")
                    {
                        xnodeVersionEdit = xdocAddFileContent.SelectSingleNode("//Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "/CurrentVersionUpdates/CurrentVersion[@ID=" + recordID + "]");
                    }
                    else if (hdnFileUploadType.Value == "PreviousVersionUpdateEdit")
                    {
                        xnodeVersionEdit = xdocAddFileContent.SelectSingleNode("//Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "/PreviousVersionUpdates/PreviousVersion[@ID=" + recordID + "]");
                    }

                    if (xnodeVersionEdit != null)
                    {
                        if (rdbtnFileType.SelectedValue == "3")
                        {
                            txtFileTitle.Text = "";
                            txtFileLink.Text = "";

                        }
                        else if (rdbtnFileType.SelectedValue == "2")
                        {
                            xnodeVersionEdit.Attributes["FileName"].Value = "";
                            xnodeVersionEdit.Attributes["Filesize"].Value = "";
                        }
                        else if (rdbtnFileType.SelectedValue == "1")
                        {
                            txtFileLink.Text = "";
                        }

                        DateTime ddate = Convert.ToDateTime(txtFileUploadDate.Text);
                        xnodeVersionEdit.Attributes["Date"].Value = ddate.ToString("MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture); ;
                        xnodeVersionEdit.Attributes["Description"].Value = FirstCharToUpper(RadEditorContent.Content.Replace(hdnBaseUrl.Value, ""));
                        xnodeVersionEdit.Attributes["FileTitle"].Value = FirstCharToUpper(txtFileTitle.Text);
                        xnodeVersionEdit.Attributes["GroupName"].Value = drpGroupName.SelectedValue;

                        string subgroupvalue = drpSubGroupName.SelectedValue;
                        if (subgroupvalue == "--None--")
                        {
                            subgroupvalue = "";
                        }
                        else
                        {
                            subgroupvalue = drpSubGroupName.SelectedValue;
                        }

                        if (xnodeVersionEdit.Attributes["SubGroupName"] == null)
                        {
                            XmlAttribute subgroupName = xdocAddFileContent.CreateAttribute("SubGroupName");
                            subgroupName.Value = subgroupvalue;
                            xnodeVersionEdit.Attributes.Append(subgroupName);
                        }
                        else
                        {
                            xnodeVersionEdit.Attributes["SubGroupName"].Value = subgroupvalue;
                        }

                        if (xnodeVersionEdit.Attributes["ImportantUpdate"] == null)
                        {
                            XmlAttribute importantUpdate = xdocAddFileContent.CreateAttribute("ImportantUpdate");
                            importantUpdate.Value = FirstCharToUpper(txtImportantUpdate.Text);
                            xnodeVersionEdit.Attributes.Append(importantUpdate);
                        }
                        else
                        {
                            xnodeVersionEdit.Attributes["ImportantUpdate"].Value = FirstCharToUpper(txtImportantUpdate.Text);
                        }

                        if (xnodeVersionEdit.Attributes["FileType"] == null)
                        {
                            XmlAttribute fileType = xdocAddFileContent.CreateAttribute("FileType");
                            fileType.Value = rdbtnFileType.SelectedValue;
                            xnodeVersionEdit.Attributes.Append(fileType);
                        }
                        else
                        {
                            xnodeVersionEdit.Attributes["FileType"].Value = rdbtnFileType.SelectedValue;
                        }

                        if (xnodeVersionEdit.Attributes["FileLink"] == null)
                        {
                            XmlAttribute fileLink = xdocAddFileContent.CreateAttribute("FileLink");
                            fileLink.Value = txtFileLink.Text;
                            xnodeVersionEdit.Attributes.Append(fileLink);
                        }
                        else
                        {
                            xnodeVersionEdit.Attributes["FileLink"].Value = FirstCharToUpper(txtFileLink.Text);
                        }

                        if (xnodeVersionEdit.Attributes["Status"] == null)
                        {
                            XmlAttribute status = xdocAddFileContent.CreateAttribute("Status");
                            status.Value = ContentStatus;
                            xnodeVersionEdit.Attributes.Append(status);
                        }
                        else
                        {
                            xnodeVersionEdit.Attributes["Status"].Value = ContentStatus;
                        }
                        foreach (UploadedFile file in fileUpload.UploadedFiles)
                        {
                            asyFileName = file.GetName();
                            asyFileExtension = file.GetExtension().Replace(".", string.Empty);
                            asyFileSize = file.ContentLength;

                            xnodeVersionEdit.Attributes["FileName"].Value = asyFileName;

                            string[] sizes = { "Bytes", "KB", "MB", "GB" };
                            double len = asyFileSize;
                            int order = 0;
                            while (len >= 1024 && order + 1 < sizes.Length)
                            {
                                order++;
                                len = len / 1024;
                            }

                            string result = String.Format("{0:0.##} {1}", len, sizes[order]);

                            xnodeVersionEdit.Attributes["Filesize"].Value = result;

                            string spath = storePath;
                            spath = spath + "\\" + prodPathName + "\\" + drpCategory.SelectedValue + "\\" + asyFileName;

                            file.SaveAs(spath);
                        }


                    }
                }

                xdocAddFileContent.Save(DBProductsfilesPath);
                drpCategory_SelectedIndexChanged(sender, e);
            }
        }

        protected void btnTechNotesAddFile_Click(object sender, EventArgs e)
        {
            string asyFileNameTechNotes = null;
            string asyFileExtensionTechNotes = null;

            string selDrpProd = drpProducts.SelectedValue;

            XmlNode xProd = DBReader.getFullProduct(selDrpProd);

            string prodPathName = xProd.Attributes["Name"].Value.ToString();

            Int64 asyFileSizeTechNotes = 0;

            using (fileUploadTechNotes)
            using (fileUpload)
            {
                XElement xml = XElement.Load(DBProductsfilesPath);

                if ((hdnTechNotesUploadType.Value != "TechNotesUpdateEdit") && (rdbtnFileTypeTechNotes.SelectedValue == "1"))
                {
                    var filenametitle = xml.Elements("Product").
                    Where(el => el.Attribute("ID").Value.Equals(drpProducts.SelectedValue)).
                    SelectMany(el => el.Elements(drpCategory.SelectedItem.Value).Elements("TechnicalNotes")).
                    Select(f => new
                    {
                        FileName = f.Attributes().Where(x => x.Name == "FileName").
                            Select(x => x.Value).FirstOrDefault(),
                        FileTitle = f.Attributes().Where(x => x.Name == "FileTitle").
                            Select(x => x.Value).FirstOrDefault()
                    }
                        );

                    foreach (var element in filenametitle)
                    {
                        //if (element.FileName == fileUploadTechNotes.FileName)
                        if (element.FileName == asyFileNameTechNotes)
                        {
                            this.Context.Items["Title"] = "";
                            this.Context.Items["Message"] = "This File selected already exists. Please select a different File.";
                            Server.Transfer("Response.aspx", true);
                        }
                    }
                }

                string ContentStatus = "0";

                if (chkboxDisplayTechNotesContent.Checked == true)
                    ContentStatus = "1";

                XmlDocument xdocAddFileContent = new XmlDocument();

                xdocAddFileContent.Load(DBProductsfilesPath);

                XmlNode xnodeID = xdocAddFileContent.SelectSingleNode("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "");

                if ((hdnTechNotesUploadType.Value == "TechNotesContentAdd") || (hdnTechNotesUploadType.Value == "TechNotesUpdateCopy"))
                {

                    int TechnicalNotesID = 0;
                    XmlNode xnodeTechnicalNotes = xdocAddFileContent.SelectSingleNode("//Products/Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "/TechnicalNotes/@ID[not(. <=../preceding-sibling::TechnicalNotes/@iD) and not(. <=../following-sibling::TechnicalNotes/@ID)]");

                    if (xnodeTechnicalNotes == null)
                    {
                        TechnicalNotesID = 1;
                    }
                    else
                    {
                        TechnicalNotesID = Convert.ToInt32(xnodeTechnicalNotes.Value) + 1;
                    }

                    XmlElement newElem = xdocAddFileContent.CreateElement("TechnicalNotes");

                    XmlAttribute ID = xdocAddFileContent.CreateAttribute("ID");
                    ID.Value = TechnicalNotesID.ToString();
                    newElem.Attributes.Append(ID);

                    XmlAttribute date = xdocAddFileContent.CreateAttribute("Date");
                    DateTime ddate = Convert.ToDateTime(txtTechNotesDate.Text);
                    date.Value = ddate.ToString("MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    newElem.Attributes.Append(date);

                    XmlAttribute groupName = xdocAddFileContent.CreateAttribute("GroupName");
                    groupName.Value = drpTechNotesGroupNames.SelectedItem.Value;
                    newElem.Attributes.Append(groupName);

                    string subgroupvalue = drpTechNotesSubGroupNames.SelectedValue;
                    if (subgroupvalue == "--None--")
                    {
                        subgroupvalue = "";
                    }
                    else
                    {
                        subgroupvalue = drpTechNotesSubGroupNames.SelectedValue;
                    }

                    XmlAttribute subGroupName = xdocAddFileContent.CreateAttribute("SubGroupName");
                    subGroupName.Value = subgroupvalue;
                    newElem.Attributes.Append(subGroupName);

                    if (rdbtnFileTypeTechNotes.SelectedValue == "3")
                    {
                        XmlAttribute fileType = xdocAddFileContent.CreateAttribute("FileType");
                        fileType.Value = rdbtnFileTypeTechNotes.SelectedValue;
                        newElem.Attributes.Append(fileType);

                        XmlAttribute fileLink = xdocAddFileContent.CreateAttribute("FileLink");
                        fileLink.Value = "";
                        newElem.Attributes.Append(fileLink);

                        XmlAttribute fileTitle = xdocAddFileContent.CreateAttribute("FileTitle");
                        fileTitle.Value = "";
                        newElem.Attributes.Append(fileTitle);

                        XmlAttribute fileName = xdocAddFileContent.CreateAttribute("FileName");
                        fileName.Value = "";
                        newElem.Attributes.Append(fileName);

                        XmlAttribute filesize = xdocAddFileContent.CreateAttribute("Filesize");
                        filesize.Value = "";
                        newElem.Attributes.Append(filesize);
                    }
                    else if (rdbtnFileTypeTechNotes.SelectedValue == "2")
                    {
                        XmlAttribute fileType = xdocAddFileContent.CreateAttribute("FileType");
                        fileType.Value = rdbtnFileTypeTechNotes.SelectedValue;
                        newElem.Attributes.Append(fileType);

                        XmlAttribute fileLink = xdocAddFileContent.CreateAttribute("FileLink");
                        fileLink.Value = txtTechNotesFileLink.Text;
                        newElem.Attributes.Append(fileLink);

                        XmlAttribute fileTitle = xdocAddFileContent.CreateAttribute("FileTitle");
                        fileTitle.Value = FirstCharToUpper(txtTechNotesFileTitle.Text);
                        newElem.Attributes.Append(fileTitle);

                        XmlAttribute fileName = xdocAddFileContent.CreateAttribute("FileName");
                        fileName.Value = "";
                        newElem.Attributes.Append(fileName);

                        XmlAttribute filesize = xdocAddFileContent.CreateAttribute("Filesize");
                        filesize.Value = "";
                        newElem.Attributes.Append(filesize);

                    }
                    else
                    {
                        XmlAttribute fileType = xdocAddFileContent.CreateAttribute("FileType");
                        fileType.Value = rdbtnFileTypeTechNotes.SelectedValue;
                        newElem.Attributes.Append(fileType);

                        XmlAttribute fileLink = xdocAddFileContent.CreateAttribute("FileLink");
                        fileLink.Value = txtTechNotesFileLink.Text;
                        newElem.Attributes.Append(fileLink);

                        //XmlAttribute fileTitle = xdocAddFileContent.CreateAttribute("FileTitle");
                        //fileTitle.Value = FirstCharToUpper(txtTechNotesFileTitle.Text);
                        //newElem.Attributes.Append(fileTitle);

                        XmlAttribute fileTitle = xdocAddFileContent.CreateAttribute("FileTitle");
                        fileTitle.Value = FirstCharToUpper(txtTechNotesFileTitle.Text);
                        newElem.Attributes.Append(fileTitle);

                        foreach (UploadedFile file in fileUploadTechNotes.UploadedFiles)
                        {
                            asyFileNameTechNotes = file.GetName();
                            asyFileExtensionTechNotes = file.GetExtension().Replace(".", string.Empty);
                            asyFileSizeTechNotes = file.ContentLength;

                            string spath = storePath;
                            spath = spath + "\\" + prodPathName + "\\" + drpCategory.SelectedValue + "\\" + asyFileNameTechNotes;

                            file.SaveAs(spath);
                        }
                        XmlAttribute fileName = xdocAddFileContent.CreateAttribute("FileName");
                        //fileName.Value = fileUploadTechNotes.FileName;
                        fileName.Value = asyFileNameTechNotes;
                        newElem.Attributes.Append(fileName);

                        string[] sizes = { "Bytes", "KB", "MB", "GB" };
                        //double len = fileUploadTechNotes.PostedFile.ContentLength;
                        double len = asyFileSizeTechNotes;
                        int order = 0;
                        while (len >= 1024 && order + 1 < sizes.Length)
                        {
                            order++;
                            len = len / 1024;
                        }

                        // Adjust the format string to your preferences. For example "{0:0.#}{1}" would
                        // show a single decimal place, and no space.
                        string result = String.Format("{0:0.##} {1}", len, sizes[order]);

                        XmlAttribute filesize = xdocAddFileContent.CreateAttribute("Filesize");
                        filesize.Value = result;
                        newElem.Attributes.Append(filesize);

                    }

                    XmlAttribute desc = xdocAddFileContent.CreateAttribute("Description");
                    desc.Value = FirstCharToUpper(RadEditorTechNotes.Content.Replace(hdnBaseUrl.Value, ""));
                    newElem.Attributes.Append(desc);

                    int iContentPriority = getTNContentPriorityID(drpProducts.SelectedValue, drpCategory.SelectedItem.Value, "TechnicalNotes", drpTechNotesGroupNames.SelectedItem.Value, subgroupvalue);

                    XmlAttribute GSCPriority = xdocAddFileContent.CreateAttribute("GSCPriority");
                    GSCPriority.Value = iContentPriority.ToString();
                    newElem.Attributes.Append(GSCPriority);

                    XmlAttribute status = xdocAddFileContent.CreateAttribute("Status");
                    status.Value = ContentStatus;
                    newElem.Attributes.Append(status);

                    XmlNode xnodeTechnicalNotesUpadte = xdocAddFileContent.SelectSingleNode("//Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "");
                    xnodeTechnicalNotesUpadte.AppendChild(newElem);

                }
                else
                {
                    string recordID = hdnTechNotesUploadRecordID.Value;

                    XmlNode xnodeTechNotesEdit = null;

                    xnodeTechNotesEdit = xdocAddFileContent.SelectSingleNode("//Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "/TechnicalNotes[@ID=" + recordID + "]");

                    if (xnodeTechNotesEdit != null)
                    {
                        if (rdbtnFileTypeTechNotes.SelectedValue == "3")
                        {
                            txtTechNotesFileTitle.Text = "";
                            txtTechNotesFileLink.Text = "";
                        }
                        else if (rdbtnFileTypeTechNotes.SelectedValue == "2")
                        {
                            xnodeTechNotesEdit.Attributes["Filesize"].Value = "";
                            xnodeTechNotesEdit.Attributes["FileName"].Value = "";
                        }
                        else if (rdbtnFileTypeTechNotes.SelectedValue == "1")
                        {
                            txtTechNotesFileLink.Text = "";
                        }

                        DateTime ddate = Convert.ToDateTime(txtTechNotesDate.Text);
                        xnodeTechNotesEdit.Attributes["Date"].Value = ddate.ToString("MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture); ;
                        xnodeTechNotesEdit.Attributes["Description"].Value = FirstCharToUpper(RadEditorTechNotes.Content.Replace(hdnBaseUrl.Value, ""));
                        xnodeTechNotesEdit.Attributes["FileTitle"].Value = FirstCharToUpper(txtTechNotesFileTitle.Text);
                        xnodeTechNotesEdit.Attributes["GroupName"].Value = drpTechNotesGroupNames.SelectedValue;

                        string subgroupvalue = drpTechNotesSubGroupNames.SelectedValue;
                        if (subgroupvalue == "--None--")
                        {
                            subgroupvalue = "";
                        }
                        else
                        {
                            subgroupvalue = drpTechNotesSubGroupNames.SelectedValue;
                        }

                        if (xnodeTechNotesEdit.Attributes["SubGroupName"] == null)
                        {
                            XmlAttribute subGroupName = xdocAddFileContent.CreateAttribute("SubGroupName");
                            subGroupName.Value = subgroupvalue;
                            xnodeTechNotesEdit.Attributes.Append(subGroupName);
                        }
                        else
                        {
                            xnodeTechNotesEdit.Attributes["SubGroupName"].Value = subgroupvalue;
                        }

                        if (xnodeTechNotesEdit.Attributes["FileType"] == null)
                        {
                            XmlAttribute fileType = xdocAddFileContent.CreateAttribute("FileType");
                            fileType.Value = rdbtnFileTypeTechNotes.SelectedValue;
                            xnodeTechNotesEdit.Attributes.Append(fileType);
                        }
                        else
                        {
                            xnodeTechNotesEdit.Attributes["FileType"].Value = rdbtnFileTypeTechNotes.SelectedValue;
                        }

                        if (xnodeTechNotesEdit.Attributes["FileLink"] == null)
                        {
                            XmlAttribute fileLink = xdocAddFileContent.CreateAttribute("FileLink");
                            fileLink.Value = txtTechNotesFileLink.Text;
                            xnodeTechNotesEdit.Attributes.Append(fileLink);
                        }
                        else
                        {
                            xnodeTechNotesEdit.Attributes["FileLink"].Value = FirstCharToUpper(txtTechNotesFileLink.Text);
                        }

                        if (xnodeTechNotesEdit.Attributes["Status"] == null)
                        {
                            XmlAttribute status = xdocAddFileContent.CreateAttribute("Status");
                            status.Value = ContentStatus;
                            xnodeTechNotesEdit.Attributes.Append(status);
                        }
                        else
                        {
                            xnodeTechNotesEdit.Attributes["Status"].Value = ContentStatus;
                        }
                        foreach (UploadedFile file in fileUploadTechNotes.UploadedFiles)
                        {
                            asyFileNameTechNotes = file.GetName();
                            asyFileExtensionTechNotes = file.GetExtension().Replace(".", string.Empty);
                            asyFileSizeTechNotes = file.ContentLength;

                            xnodeTechNotesEdit.Attributes["FileName"].Value = asyFileNameTechNotes;

                            string[] sizes = { "Bytes", "KB", "MB", "GB" };
                            //double len = asyFileSize.PostedFile.ContentLength;
                            double len = asyFileSizeTechNotes;
                            int order = 0;
                            while (len >= 1024 && order + 1 < sizes.Length)
                            {
                                order++;
                                len = len / 1024;
                            }

                            string result = String.Format("{0:0.##} {1}", len, sizes[order]);

                            xnodeTechNotesEdit.Attributes["Filesize"].Value = result;

                            string spath = storePath;
                            spath = spath + "\\" + prodPathName + "\\" + drpCategory.SelectedValue + "\\" + asyFileNameTechNotes;

                            file.SaveAs(spath);
                        }

                    }
                }

                xdocAddFileContent.Save(DBProductsfilesPath);
                drpCategory_SelectedIndexChanged(sender, e);
            }
        }

        protected void btnUpdNoteVersionContent_Click(object sender, EventArgs e)
        {
            XmlDocument xdocNoteVerInfo = new XmlDocument();

            xdocNoteVerInfo.Load(DBProductsfilesPath);

            XmlNode xnodeID = xdocNoteVerInfo.SelectSingleNode("//Products/Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "");

            if (hdnNoteVersionId.Value == "VersionInfo")
            {
                if (xnodeID.Attributes["CurrentVersionInfo"] == null)
                {
                    XmlAttribute CurrentVersionInfo = xdocNoteVerInfo.CreateAttribute("CurrentVersionInfo");
                    CurrentVersionInfo.Value = FirstCharToUpper(RadEditorNoteVersionContent.Content.Replace(hdnBaseUrl.Value, ""));
                    xnodeID.Attributes.Append(CurrentVersionInfo);
                }
                else
                {
                    xnodeID.Attributes["CurrentVersionInfo"].Value = FirstCharToUpper(RadEditorNoteVersionContent.Content.Replace(hdnBaseUrl.Value, ""));
                }
            }
            else if (hdnNoteVersionId.Value == "ImportantNote")
            {
                if (xnodeID.Attributes["ImportantNote"] == null)
                {
                    XmlAttribute ImportantNote = xdocNoteVerInfo.CreateAttribute("ImportantNote");
                    ImportantNote.Value = FirstCharToUpper(RadEditorNoteVersionContent.Content.Replace(hdnBaseUrl.Value, ""));
                    xnodeID.Attributes.Append(ImportantNote);
                }
                else
                {
                    xnodeID.Attributes["ImportantNote"].Value = FirstCharToUpper(RadEditorNoteVersionContent.Content.Replace(hdnBaseUrl.Value, ""));
                }
            }
            else
            {
                if (xnodeID.Attributes["PleaseNote"] == null)
                {
                    XmlAttribute PleaseNote = xdocNoteVerInfo.CreateAttribute("PleaseNote");
                    PleaseNote.Value = FirstCharToUpper(RadEditorNoteVersionContent.Content.Replace(hdnBaseUrl.Value, ""));
                    xnodeID.Attributes.Append(PleaseNote);
                }
                else
                {
                    xnodeID.Attributes["PleaseNote"].Value = FirstCharToUpper(RadEditorNoteVersionContent.Content.Replace(hdnBaseUrl.Value, ""));
                }
            }

            xdocNoteVerInfo.Save(DBProductsfilesPath);
            drpCategory_SelectedIndexChanged(sender, e);
        }

        private DataTable GetDistinctRecords(DataTable dt, string Columns)
        {
            DataTable dtUniqRecords = new DataTable();
            dtUniqRecords = dt.DefaultView.ToTable(true, Columns);
            return dtUniqRecords;
        }

        protected void gridYears_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                GridView gv = (GridView)e.Row.FindControl("gridPreviousAnnouncements");
                gv.RowDataBound += new GridViewRowEventHandler(gridPreviousAnnouncements_RowDataBound);

                string year = gridYears.DataKeys[e.Row.RowIndex].Value.ToString();
                getContentbyYear(year, gv);
            }
        }

        protected void getContentbyYear(string Year, GridView GridViewContent)
        {
            XElement xml = XElement.Load(DBProductsfilesPath);

            var result = xml.Elements("Product").
        Where(el => el.Attribute("ID").Value.Equals(drpProducts.SelectedValue)).
        SelectMany(el => el.Elements("Announcements").Elements("Announcement")).
        Where(el => el.Attribute("Date").Value.Contains(Year)).
        Select(f => new
        {
            Date = f.Attributes().Where(x => x.Name == "Date").
                Select(x => (x.Value)).FirstOrDefault(),
            Description = f.Attributes().Where(x => x.Name == "Description").
                Select(x => (x.Value)).FirstOrDefault(),
            WhatsNew = f.Attributes().Where(x => x.Name == "WhatsNew").
                            Select(x => (x.Value)).FirstOrDefault(),
            WhatsExpire = f.Attributes().Where(x => x.Name == "WhatsNewExpiration").
                            Select(x => (x.Value)).FirstOrDefault(),

            ID = f.Attributes().Where(x => x.Name == "ID").
            Select(x => (x.Value)).FirstOrDefault()
        }
            ).OrderByDescending(s => Convert.ToDateTime((string)s.Date, System.Globalization.CultureInfo.InvariantCulture));

            DataSet ds = new DataSet();
            DataTable dt = new DataTable("Announcement");
            dt.Columns.Add(new DataColumn("Date", typeof(string)));
            dt.Columns.Add(new DataColumn("Description", typeof(string)));
            dt.Columns.Add(new DataColumn("WhatsNew", typeof(string)));
            dt.Columns.Add(new DataColumn("WhatsNewExpiration", typeof(string)));
            dt.Columns.Add(new DataColumn("ID", typeof(string)));

            foreach (var element in result)
            {
                DateTime ddate = Convert.ToDateTime(element.Date, System.Globalization.CultureInfo.InvariantCulture);
                var row = dt.NewRow();
                row["Date"] = ddate.ToString("dd MMMM yyyy");
                row["Description"] = element.Description;
                row["WhatsNew"] = element.WhatsNew;
                row["WhatsNewExpiration"] = element.WhatsExpire;
                row["ID"] = element.ID;
                dt.Rows.Add(row);
            }

            ds.Tables.Add(dt);

            GridViewContent.DataSource = ds;
            GridViewContent.DataBind();
        }

        protected void btnUpdPrdAnnContent_Click(object sender, EventArgs e)
        {
            XmlDocument xdocPrdAnnouncement = new XmlDocument();

            xdocPrdAnnouncement.Load(DBProductsfilesPath);

            string recordID = "0";

            if (hiddenEditType.Value == "0")
            {
                recordID = "0";
            }
            else
            {
                recordID = hiddenEditType.Value;
            }


            if (recordID == "0")
            {

                XmlNode xnodeAnnouncementID = xdocPrdAnnouncement.SelectSingleNode("//Products/Product[@ID=" + drpProducts.SelectedValue + "]/Announcements/Announcement/@ID[not(. <=../preceding-sibling::Announcement/@iD) and not(. <=../following-sibling::Announcement/@ID)]");
                int announcementID = 0;

                if (xnodeAnnouncementID == null)
                {
                    announcementID = 1;
                }
                else
                {
                    announcementID = Convert.ToInt32(xnodeAnnouncementID.Value) + 1;
                }

                XmlElement newElem = xdocPrdAnnouncement.CreateElement("Announcement");

                XmlAttribute ID = xdocPrdAnnouncement.CreateAttribute("ID");
                ID.Value = announcementID.ToString();
                newElem.Attributes.Append(ID);

                XmlAttribute date = xdocPrdAnnouncement.CreateAttribute("Date");
                DateTime ddate = Convert.ToDateTime(txtPrdAnnouncementDt.Text);
                date.Value = ddate.ToString("MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                newElem.Attributes.Append(date);

                if (WhatsNewCBX.Checked == true)
                {
                    XmlAttribute whatNew = xdocPrdAnnouncement.CreateAttribute("WhatsNew");
                    whatNew.Value = "true";
                    newElem.Attributes.Append(whatNew);
                    XmlAttribute xDate = xdocPrdAnnouncement.CreateAttribute("WhatsNewExpiration");
                    DateTime expireDate = Convert.ToDateTime(whatsNewExpire.Text);
                    xDate.Value = expireDate.ToString("MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    newElem.Attributes.Append(xDate);
                }


                XmlAttribute desc = xdocPrdAnnouncement.CreateAttribute("Description");
                desc.Value = FirstCharToUpper(RadEditorAnnouncements.Content.Replace(hdnBaseUrl.Value, ""));
                newElem.Attributes.Append(desc);

                XmlNode xnodeAnnouncement = xdocPrdAnnouncement.SelectSingleNode("//Products/Product[@ID='" + drpProducts.SelectedValue + "']/Announcements");
                xnodeAnnouncement.AppendChild(newElem);

                xdocPrdAnnouncement.Save(DBProductsfilesPath);
            }
            else
            {
                XmlNode xnodeAnnouncements = xdocPrdAnnouncement.SelectSingleNode("//Product[@ID=" + drpProducts.SelectedValue + "]/Announcements/Announcement[@ID=" + recordID + "]");

                if (xnodeAnnouncements != null)
                {
                    DateTime ddate = Convert.ToDateTime(txtPrdAnnouncementDt.Text);
                    xnodeAnnouncements.Attributes["Date"].Value = ddate.ToString("MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    xnodeAnnouncements.Attributes["Description"].Value = FirstCharToUpper(RadEditorAnnouncements.Content.Replace(hdnBaseUrl.Value, ""));
                    if (WhatsNewCBX.Checked == true)
                    {
                        XmlAttribute whatNew = xdocPrdAnnouncement.CreateAttribute("WhatNew");
                        whatNew.Value = "true";
                        xnodeAnnouncements.Attributes.Append(whatNew);
                    }

                    xdocPrdAnnouncement.Save(DBProductsfilesPath);
                }
            }
            gridCurrentAnnouncements.EditIndex = -1;
            drpCategory_SelectedIndexChanged(sender, e);

        }

        protected void btnTraining_Click(object sender, EventArgs e)
        {
            XmlDocument xdoc = new XmlDocument();

            xdoc.Load(DBProductsfilesPath);

            XmlNode xnodeTraining = xdoc.SelectSingleNode("//Products/Product[@ID=" + drpProducts.SelectedValue + "]/Training");

            if (xnodeTraining.Attributes["TrainingLink"] == null)
            {
                XmlAttribute xmlAttributeTraining = xdoc.CreateAttribute("TrainingLink");
                xmlAttributeTraining.Value = txtTrainingLink.Text;
                xnodeTraining.Attributes.Append(xmlAttributeTraining);
            }
            else
            {
                xnodeTraining.Attributes["TrainingLink"].Value = txtTrainingLink.Text;
            }

            if (xnodeTraining.Attributes["Target"] == null)
            {
                XmlAttribute xmlAttributeTarget = xdoc.CreateAttribute("Target");
                xmlAttributeTarget.Value = drpTrainingTarget.SelectedValue;
                xnodeTraining.Attributes.Append(xmlAttributeTarget);
            }
            else
            {
                xnodeTraining.Attributes["Target"].Value = drpTrainingTarget.SelectedValue;
            }

            xdoc.Save(DBProductsfilesPath);

            txtTrainingLink.Enabled = false;
            lblTrainingMsg.Style["display"] = "show";
            drpTrainingTarget.Enabled = false;
        }

        protected void drpCategory_SelectedIndexChanged(object sender, EventArgs e)
        {

            string selDrpProd = drpProducts.SelectedValue;

            XmlNode xProd = DBReader.getFullProduct(selDrpProd);

            string prodPathName = xProd.Attributes["Name"].Value.ToString();

            if (drpCategory.SelectedItem.Value == "Announcements")
            {
                getAnnouncementYears();
                pnlAnnouncements.Style["display"] = "show";
                pnlCurrentVersionInfo.Style["display"] = "none";
                pnlImportantNote.Style["display"] = "none";
                pnlPleaseNote.Style["display"] = "none";
                pnlCurrentVersionUpdates.Style["display"] = "none";
                pnlPreviousVersionUpdates.Style["display"] = "none";
                pnlTechnicalNotes.Style["display"] = "none";
                pnlTraining.Style["display"] = "none";

                RadEditorNoteVersionContent.Snippets.Clear();
            }
            else if (drpCategory.SelectedItem.Value == "ServicePacksandFixes")
            {
                getVersionUpdates();
                pnlAnnouncements.Style["display"] = "none";
                pnlCurrentVersionInfo.Style["display"] = "show";
                pnlImportantNote.Style["display"] = "show";
                pnlPleaseNote.Style["display"] = "show";
                pnlCurrentVersionUpdates.Style["display"] = "show";
                pnlPreviousVersionUpdates.Style["display"] = "show";
                pnlPreviousVersionUpdates.GroupingText = "Previous Version Updates";
                pnlTechnicalNotes.Style["display"] = "none";
                pnlTraining.Style["display"] = "none";
                btnUpdateGroupNamesPreviousVersion.Style["display"] = "show";

                RadEditorNoteVersionContent.Snippets.Add("Version Template", "The current version of " + prodPathName + " is <b>(rtmversion)</b>.");
                RadEditorNoteVersionContent.Snippets.Add("Update Template", "The most current update(s) for " + prodPathName + " is <b>(servicepack)</b> with <b>(hotfix)</b>.");

            }
            else if (drpCategory.SelectedItem.Value == "Content")
            {
                pnlAnnouncements.Style["display"] = "none";
                pnlCurrentVersionInfo.Style["display"] = "show";
                pnlImportantNote.Style["display"] = "show";
                pnlPleaseNote.Style["display"] = "show";
                pnlCurrentVersionUpdates.Style["display"] = "show";
                pnlPreviousVersionUpdates.Style["display"] = "show";
                pnlPreviousVersionUpdates.GroupingText = "Previous Version Updates";
                pnlTechnicalNotes.Style["display"] = "none";
                pnlTraining.Style["display"] = "none";
                getVersionUpdates();
                btnUpdateGroupNamesPreviousVersion.Style["display"] = "show";

                RadEditorNoteVersionContent.Snippets.Clear();
            }
            else if (drpCategory.SelectedItem.Value == "FreewareToolsandUtilities")
            {
                pnlAnnouncements.Style["display"] = "none";
                pnlCurrentVersionInfo.Style["display"] = "none";
                pnlImportantNote.Style["display"] = "show";
                pnlPleaseNote.Style["display"] = "show";
                pnlCurrentVersionUpdates.Style["display"] = "none";
                pnlPreviousVersionUpdates.Style["display"] = "show";
                pnlPreviousVersionUpdates.GroupingText = "Freeware Tools and Utilities";
                pnlTechnicalNotes.Style["display"] = "none";
                pnlTraining.Style["display"] = "none";
                getVersionUpdates();
                btnUpdateGroupNamesPreviousVersion.Style["display"] = "show";

                RadEditorNoteVersionContent.Snippets.Clear();
            }
            else if (drpCategory.SelectedItem.Value == "TechnicalNotesandWhitePapers")
            {
                pnlAnnouncements.Style["display"] = "none";
                pnlTechnicalNotes.Style["display"] = "show";
                pnlCurrentVersionInfo.Style["display"] = "none";
                pnlImportantNote.Style["display"] = "show";
                pnlPleaseNote.Style["display"] = "show";
                pnlCurrentVersionUpdates.Style["display"] = "none";
                pnlPreviousVersionUpdates.Style["display"] = "none";
                pnlTraining.Style["display"] = "none";
                getVersionUpdates();

                RadEditorNoteVersionContent.Snippets.Clear();
            }
            else if (drpCategory.SelectedItem.Value == "Training")
            {
                pnlTraining.Style["display"] = "show";
                pnlTechnicalNotes.Style["display"] = "none";
                pnlCurrentVersionInfo.Style["display"] = "none";
                pnlImportantNote.Style["display"] = "none";
                pnlPleaseNote.Style["display"] = "none";
                pnlCurrentVersionUpdates.Style["display"] = "none";
                pnlPreviousVersionUpdates.Style["display"] = "none";
                pnlAnnouncements.Style["display"] = "none";

                txtTrainingLink.Enabled = true;
                txtTrainingLink.Text = "";
                lblTrainingMsg.Style["display"] = "none";
                lblTrainingTarget.Style["display"] = "show";
                drpTrainingTarget.Style["display"] = "show";

                getVersionUpdates();

                RadEditorNoteVersionContent.Snippets.Clear();
            }
            else
            {
                pnlTechnicalNotes.Style["display"] = "none";
                pnlCurrentVersionInfo.Style["display"] = "none";
                pnlImportantNote.Style["display"] = "none";
                pnlPleaseNote.Style["display"] = "none";
                pnlCurrentVersionUpdates.Style["display"] = "none";
                pnlPreviousVersionUpdates.Style["display"] = "none";
                pnlAnnouncements.Style["display"] = "none";
                pnlTraining.Style["display"] = "none";

                RadEditorNoteVersionContent.Snippets.Clear();
            }
        }

        protected void gridCurrentAnnouncements_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                ImageButton btnEditCurrentAnnouncement = e.Row.FindControl("btnEditCurrentAnnouncement") as ImageButton;
                Label lblAnnouncementsDescription = e.Row.FindControl("lblAnnouncementsDescription") as Label;
                Label lblAnnouncementDate = e.Row.FindControl("lblAnnouncementsdate") as Label;
                Label lblWhatsNew = e.Row.FindControl("lblWhatsNew") as Label;
                Label lblWhatsNewExpire = e.Row.FindControl("lblWhatsNewExpire") as Label;
                string recordId = gridCurrentAnnouncements.DataKeys[e.Row.RowIndex].Value.ToString();
                btnEditCurrentAnnouncement.OnClientClick = "javascript:return PopulateValues('" + ReplaceSpecialChar(lblAnnouncementsDescription.Text) + "', '" + lblAnnouncementDate.Text + "', '" + recordId + "');";
            }
        }

        protected void gridPreviousAnnouncements_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                ImageButton btnEditPreviousAnnouncement = e.Row.FindControl("btnEditPreviousAnnouncement") as ImageButton;
                Label lblAnnouncementsDescription = e.Row.FindControl("lblAnnouncementsDescription") as Label;
                Label lblAnnouncementDate = e.Row.FindControl("lblAnnouncementsdate") as Label;
                Label lblWhatsNew = e.Row.FindControl("lblWhatsNew") as Label;
                HiddenField hdnRecordId = e.Row.FindControl("hdnRecordId") as HiddenField;
                btnEditPreviousAnnouncement.OnClientClick = "javascript:return PopulateValues('" + ReplaceSpecialChar(lblAnnouncementsDescription.Text) + "', '" + lblAnnouncementDate.Text + "', '" + hdnRecordId.Value + "');";
            }
        }

        protected void gridCurrentVersionUpdates_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                ImageButton btnEditCurrentVersionUpdates = e.Row.FindControl("btnEditCurrentVersionUpdates") as ImageButton;
                ImageButton btnCopyCurrentVersionUpdates = e.Row.FindControl("btnCopyCurrentVersionUpdates") as ImageButton;
                LinkButton lnkbtnFileTitleCV = e.Row.FindControl("lnkbtnFileTitleCV") as LinkButton;
                Label lblFileName = e.Row.FindControl("lblFileName") as Label;
                Label lblDate = e.Row.FindControl("lblDate") as Label;
                Label lblContent = e.Row.FindControl("lblContent") as Label;
                Label lblImportantUpdate = e.Row.FindControl("lblImportantContenttext") as Label;
                HiddenField hdnCurrentVerRecordId = e.Row.FindControl("hdnCurrentVerRecordId") as HiddenField;
                HiddenField hdnCurrentVerGroupName = e.Row.FindControl("hdnCurrentVerGroupName") as HiddenField;
                HiddenField hdnCurrentVerSubGroupName = e.Row.FindControl("hdnCurrentVerSubGroupName") as HiddenField;
                HiddenField hdnCurrentVerFileTypeGroup = e.Row.FindControl("hdnCurrentVerFileTypeGroup") as HiddenField;
                HiddenField hdnCurrentVerGroupContentStatus = e.Row.FindControl("hdnCurrentVerGroupContentStatus") as HiddenField;
                HyperLink hlnkFileLinkCV = e.Row.FindControl("hlnkFileLinkCV") as HyperLink;
                string stype = "CurrentVersionUpdateEdit";
                string stypecopy = "CurrentVersionUpdateCopy";

                btnEditCurrentVersionUpdates.OnClientClick = "javascript:return populateContentValues('" + ReplaceSpecialChar(lblContent.Text) + "', '" + ReplaceSpecialChar(lblImportantUpdate.Text) + "', '" + lblDate.Text + "', '" + lnkbtnFileTitleCV.Text.Replace("'", "\\'") + "','" + lblFileName.Text.Replace("'", "\\'") + "','" + hdnCurrentVerGroupName.Value.Replace("'", "\\'") + "','" + hdnCurrentVerSubGroupName.Value.Replace("'", "\\'") + "','" + hdnCurrentVerRecordId.Value + "','" + hdnCurrentVerFileTypeGroup.Value + "','" + hlnkFileLinkCV.NavigateUrl + "','" + hdnCurrentVerGroupContentStatus.Value + "','" + stype + "');";
                btnCopyCurrentVersionUpdates.OnClientClick = "javascript:return populateContentValues('" + ReplaceSpecialChar(lblContent.Text) + "', '" + ReplaceSpecialChar(lblImportantUpdate.Text) + "', '" + lblDate.Text + "', '" + lnkbtnFileTitleCV.Text.Replace("'", "\\'") + "','','" + hdnCurrentVerGroupName.Value.Replace("'", "\\'") + "','" + hdnCurrentVerSubGroupName.Value.Replace("'", "\\'") + "','" + hdnCurrentVerRecordId.Value + "','" + hdnCurrentVerFileTypeGroup.Value + "','" + hlnkFileLinkCV.NavigateUrl + "','" + hdnCurrentVerGroupContentStatus.Value + "','" + stypecopy + "');";

                PopulateDropdownGroupsSubGrouptoMove();
            }
        }

        protected void gridCurrentSubVersionUpdates_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                ImageButton btnEditSubCurrentVersionUpdates = e.Row.FindControl("btnEditSubCurrentVersionUpdates") as ImageButton;
                ImageButton btnCopySubCurrentVersionUpdates = e.Row.FindControl("btnCopySubCurrentVersionUpdates") as ImageButton;
                LinkButton lnkbtnFileTitleCV = e.Row.FindControl("lnkbtnFileTitleCV") as LinkButton;
                Label lblFileName = e.Row.FindControl("lblFileName") as Label;
                Label lblDate = e.Row.FindControl("lblDate") as Label;
                Label lblContent = e.Row.FindControl("lblContent") as Label;
                Label lblImportantUpdate = e.Row.FindControl("lblImportantContenttext") as Label;
                HiddenField hdnSubCurrentVerRecordId = e.Row.FindControl("hdnSubCurrentVerRecordId") as HiddenField;
                HiddenField hdnSubCurrentVerGroupName = e.Row.FindControl("hdnSubCurrentVerGroupName") as HiddenField;
                HiddenField hdnSubCurrentVerSubGroupName = e.Row.FindControl("hdnSubCurrentVerSubGroupName") as HiddenField;
                HiddenField hdnCurrentVerFileTypeSubGroup = e.Row.FindControl("hdnCurrentVerFileTypeSubGroup") as HiddenField;
                HiddenField hdnCurrentVerSubGroupContentStatus = e.Row.FindControl("hdnCurrentVerSubGroupContentStatus") as HiddenField;
                HyperLink hlnkFileLinkCV = e.Row.FindControl("hlnkFileLinkCV") as HyperLink;
                string stype = "CurrentVersionUpdateEdit";
                string stypecopy = "CurrentVersionUpdateCopy";

                btnEditSubCurrentVersionUpdates.OnClientClick = "javascript:return populateContentValues('" + ReplaceSpecialChar(lblContent.Text) + "', '" + ReplaceSpecialChar(lblImportantUpdate.Text) + "', '" + lblDate.Text + "', '" + lnkbtnFileTitleCV.Text.Replace("'", "\\'") + "','" + lblFileName.Text.Replace("'", "\\'") + "','" + hdnSubCurrentVerGroupName.Value.Replace("'", "\\'") + "','" + hdnSubCurrentVerSubGroupName.Value.Replace("'", "\\'") + "','" + hdnSubCurrentVerRecordId.Value + "','" + hdnCurrentVerFileTypeSubGroup.Value + "','" + hlnkFileLinkCV.NavigateUrl + "','" + hdnCurrentVerSubGroupContentStatus.Value + "','" + stype + "');";
                btnCopySubCurrentVersionUpdates.OnClientClick = "javascript:return populateContentValues('" + ReplaceSpecialChar(lblContent.Text) + "', '" + ReplaceSpecialChar(lblImportantUpdate.Text) + "', '" + lblDate.Text + "', '" + lnkbtnFileTitleCV.Text.Replace("'", "\\'") + "','','" + hdnSubCurrentVerGroupName.Value.Replace("'", "\\'") + "','" + hdnSubCurrentVerSubGroupName.Value.Replace("'", "\\'") + "','" + hdnSubCurrentVerRecordId.Value + "','" + hdnCurrentVerFileTypeSubGroup.Value + "','" + hlnkFileLinkCV.NavigateUrl + "','" + hdnCurrentVerSubGroupContentStatus.Value + "','" + stypecopy + "');";

                PopulateDropdownGroupsSubGrouptoMove();
            }
        }

        protected void gridPreviousVersionUpdates_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                ImageButton btnEditPreviousVersionUpdates = e.Row.FindControl("btnEditPreviousVersionUpdates") as ImageButton;
                ImageButton btnCopyPreviousVersionUpdates = e.Row.FindControl("btnCopyPreviousVersionUpdates") as ImageButton;
                LinkButton lnkbtnFileTitlePV = e.Row.FindControl("lnkbtnFileTitlePV") as LinkButton;
                Label lblFileName = e.Row.FindControl("lblFileName") as Label;
                Label lblDate = e.Row.FindControl("lblDate") as Label;
                Label lblContent = e.Row.FindControl("lblContent") as Label;
                Label lblImportantUpdate = e.Row.FindControl("lblImportantContenttext") as Label;
                HiddenField hdnPreviousVerRecordId = e.Row.FindControl("hdnPreviousVerRecordId") as HiddenField;
                HiddenField hdnPreviousVerGroupName = e.Row.FindControl("hdnPreviousVerGroupName") as HiddenField;
                HiddenField hdnPreviousVerSubGroupName = e.Row.FindControl("hdnPreviousVerSubGroupName") as HiddenField;
                HiddenField hdnPreviousVerFileTypeGroup = e.Row.FindControl("hdnPreviousVerFileTypeGroup") as HiddenField;
                HiddenField hdnPreviousVerGroupContentStatus = e.Row.FindControl("hdnPreviousVerGroupContentStatus") as HiddenField;
                HyperLink hlnkFileLinkPV = e.Row.FindControl("hlnkFileLinkPV") as HyperLink;
                string stype = "PreviousVersionUpdateEdit";
                string stypecopy = "PreviousVersionUpdateCopy";

                btnEditPreviousVersionUpdates.OnClientClick = "javascript:return populateContentValues('" + ReplaceSpecialChar(lblContent.Text) + "', '" + ReplaceSpecialChar(lblImportantUpdate.Text) + "', '" + lblDate.Text + "', '" + lnkbtnFileTitlePV.Text.Replace("'", "\\'") + "','" + lblFileName.Text.Replace("'", "\\'") + "','" + hdnPreviousVerGroupName.Value.Replace("'", "\\'") + "','" + hdnPreviousVerSubGroupName.Value.Replace("'", "\\'") + "','" + hdnPreviousVerRecordId.Value + "','" + hdnPreviousVerFileTypeGroup.Value + "','" + hlnkFileLinkPV.NavigateUrl + "','" + hdnPreviousVerGroupContentStatus.Value + "','" + stype + "');";
                btnCopyPreviousVersionUpdates.OnClientClick = "javascript:return populateContentValues('" + ReplaceSpecialChar(lblContent.Text) + "', '" + ReplaceSpecialChar(lblImportantUpdate.Text) + "', '" + lblDate.Text + "', '" + lnkbtnFileTitlePV.Text.Replace("'", "\\'") + "','','" + hdnPreviousVerGroupName.Value.Replace("'", "\\'") + "','" + hdnPreviousVerSubGroupName.Value.Replace("'", "\\'") + "','" + hdnPreviousVerRecordId.Value + "','" + hdnPreviousVerFileTypeGroup.Value + "','" + hlnkFileLinkPV.NavigateUrl + "','" + hdnPreviousVerGroupContentStatus.Value + "','" + stypecopy + "');";

            }
        }

        protected void gridPreviousSubVersionUpdates_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                ImageButton btnEditSubPreviousVersionUpdates = e.Row.FindControl("btnEditSubPreviousVersionUpdates") as ImageButton;
                ImageButton btnCopySubPreviousVersionUpdates = e.Row.FindControl("btnCopySubPreviousVersionUpdates") as ImageButton;
                LinkButton lnkbtnFileTitlePV = e.Row.FindControl("lnkbtnFileTitlePV") as LinkButton;
                Label lblFileName = e.Row.FindControl("lblFileName") as Label;
                Label lblDate = e.Row.FindControl("lblDate") as Label;
                Label lblContent = e.Row.FindControl("lblContent") as Label;
                Label lblImportantUpdate = e.Row.FindControl("lblImportantContenttext") as Label;
                HiddenField hdnSubPreviousVerRecordId = e.Row.FindControl("hdnSubPreviousVerRecordId") as HiddenField;
                HiddenField hdnSubPreviousVerGroupName = e.Row.FindControl("hdnSubPreviousVerGroupName") as HiddenField;
                HiddenField hdnSubPreviousVerSubGroupName = e.Row.FindControl("hdnSubPreviousVerSubGroupName") as HiddenField;
                HiddenField hdnPreviousVerFileTypeSubGroup = e.Row.FindControl("hdnPreviousVerFileTypeSubGroup") as HiddenField;
                HiddenField hdnPreviousVerSubGroupContentStatus = e.Row.FindControl("hdnPreviousVerSubGroupContentStatus") as HiddenField;
                HyperLink hlnkFileLinkPV = e.Row.FindControl("hlnkFileLinkPV") as HyperLink;
                string stype = "PreviousVersionUpdateEdit";
                string stypecopy = "PreviousVersionUpdateCopy";

                btnEditSubPreviousVersionUpdates.OnClientClick = "javascript:return populateContentValues('" + ReplaceSpecialChar(lblContent.Text) + "', '" + ReplaceSpecialChar(lblImportantUpdate.Text) + "', '" + lblDate.Text + "', '" + lnkbtnFileTitlePV.Text.Replace("'", "\\'") + "','" + lblFileName.Text.Replace("'", "\\'") + "','" + hdnSubPreviousVerGroupName.Value.Replace("'", "\\'") + "','" + hdnSubPreviousVerSubGroupName.Value.Replace("'", "\\'") + "','" + hdnSubPreviousVerRecordId.Value + "','" + hdnPreviousVerFileTypeSubGroup.Value + "','" + hlnkFileLinkPV.NavigateUrl + "','" + hdnPreviousVerSubGroupContentStatus.Value + "','" + stype + "');";
                btnCopySubPreviousVersionUpdates.OnClientClick = "javascript:return populateContentValues('" + ReplaceSpecialChar(lblContent.Text) + "', '" + ReplaceSpecialChar(lblImportantUpdate.Text) + "', '" + lblDate.Text + "', '" + lnkbtnFileTitlePV.Text.Replace("'", "\\'") + "','','" + hdnSubPreviousVerGroupName.Value.Replace("'", "\\'") + "','" + hdnSubPreviousVerSubGroupName.Value.Replace("'", "\\'") + "','" + hdnSubPreviousVerRecordId.Value + "','" + hdnPreviousVerFileTypeSubGroup.Value + "','" + hlnkFileLinkPV.NavigateUrl + "','" + hdnPreviousVerSubGroupContentStatus.Value + "','" + stypecopy + "');";

            }
        }

        protected void gridTechnicalNotes_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                ImageButton btnEditTechnicalNotes = e.Row.FindControl("btnEditTechnicalNotes") as ImageButton;
                ImageButton btnCopyTechnicalNotes = e.Row.FindControl("btnCopyTechnicalNotes") as ImageButton;
                LinkButton lnkbtnFileTitle = e.Row.FindControl("lnkbtnFileTitle") as LinkButton;
                Label lblFileName = e.Row.FindControl("lblFileName") as Label;
                Label lblDate = e.Row.FindControl("lblDate") as Label;
                Label lblContent = e.Row.FindControl("lblContent") as Label;
                HiddenField hdnTechNotesRecordId = e.Row.FindControl("hdnTechNotesRecordId") as HiddenField;
                HiddenField hdnTechNotesGroupName = e.Row.FindControl("hdnTechNotesGroupName") as HiddenField;
                HiddenField hdnTechNotesSubGroupName = e.Row.FindControl("hdnTechNotesSubGroupName") as HiddenField;
                HiddenField hdnTechNotesFileTypeGroup = e.Row.FindControl("hdnTechNotesFileTypeGroup") as HiddenField;
                HiddenField hdnTechNotesGroupContentStatus = e.Row.FindControl("hdnTechNotesGroupContentStatus") as HiddenField;
                HyperLink hlnkFileLink = e.Row.FindControl("hlnkFileLink") as HyperLink;
                string stype = "TechNotesUpdateEdit";
                string stypecopy = "TechNotesUpdateCopy";

                btnEditTechnicalNotes.OnClientClick = "javascript:return populateTechNotesValues('" + ReplaceSpecialChar(lblContent.Text) + "', '" + lblDate.Text + "', '" + lnkbtnFileTitle.Text.Replace("'", "\\'") + "','" + lblFileName.Text.Replace("'", "\\'") + "','" + hdnTechNotesGroupName.Value.Replace("'", "\\'") + "','" + hdnTechNotesSubGroupName.Value.Replace("'", "\\'") + "','" + hdnTechNotesRecordId.Value + "','" + hdnTechNotesFileTypeGroup.Value + "','" + hlnkFileLink.NavigateUrl + "','" + hdnTechNotesGroupContentStatus.Value + "','" + stype + "');";
                btnCopyTechnicalNotes.OnClientClick = "javascript:return populateTechNotesValues('" + ReplaceSpecialChar(lblContent.Text) + "', '" + lblDate.Text + "', '" + lnkbtnFileTitle.Text.Replace("'", "\\'") + "','','" + hdnTechNotesGroupName.Value.Replace("'", "\\'") + "','" + hdnTechNotesSubGroupName.Value.Replace("'", "\\'") + "','" + hdnTechNotesRecordId.Value + "','" + hdnTechNotesFileTypeGroup.Value + "','" + hlnkFileLink.NavigateUrl + "','" + hdnTechNotesGroupContentStatus.Value + "','" + stypecopy + "');";

            }
        }

        protected void gridSubGroupTechnicalNotes_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                ImageButton btnEditSubGroupTechnicalNotes = e.Row.FindControl("btnEditSubGroupTechnicalNotes") as ImageButton;
                ImageButton btnCopySubGroupTechnicalNotes = e.Row.FindControl("btnCopySubGroupTechnicalNotes") as ImageButton;
                LinkButton lnkbtnFileTitle = e.Row.FindControl("lnkbtnFileTitle") as LinkButton;
                Label lblFileName = e.Row.FindControl("lblFileName") as Label;
                Label lblDate = e.Row.FindControl("lblDate") as Label;
                Label lblContent = e.Row.FindControl("lblContent") as Label;
                HiddenField hdnSubGroupTechNotesRecordId = e.Row.FindControl("hdnSubGroupTechNotesRecordId") as HiddenField;
                HiddenField hdnTechNotesGroupName = e.Row.FindControl("hdnTechNotesGroupName") as HiddenField;
                HiddenField hdnTechNotesSubGroupName = e.Row.FindControl("hdnTechNotesSubGroupName") as HiddenField;
                HiddenField hdnTechNotesFileTypeSubGroup = e.Row.FindControl("hdnTechNotesFileTypeSubGroup") as HiddenField;
                HiddenField hdnTechNotesSubGroupContentStatus = e.Row.FindControl("hdnTechNotesSubGroupContentStatus") as HiddenField;
                HyperLink hlnkFileLink = e.Row.FindControl("hlnkFileLink") as HyperLink;
                string stype = "TechNotesUpdateEdit";
                string stypecopy = "TechNotesUpdateCopy";

                btnEditSubGroupTechnicalNotes.OnClientClick = "javascript:return populateTechNotesValues('" + ReplaceSpecialChar(lblContent.Text) + "', '" + lblDate.Text + "', '" + lnkbtnFileTitle.Text.Replace("'", "\\'") + "','" + lblFileName.Text.Replace("'", "\\'") + "','" + hdnTechNotesGroupName.Value.Replace("'", "\\'") + "','" + hdnTechNotesSubGroupName.Value.Replace("'", "\\'") + "','" + hdnSubGroupTechNotesRecordId.Value + "','" + hdnTechNotesFileTypeSubGroup.Value + "','" + hlnkFileLink.NavigateUrl + "','" + hdnTechNotesSubGroupContentStatus.Value + "','" + stype + "');";
                btnCopySubGroupTechnicalNotes.OnClientClick = "javascript:return populateTechNotesValues('" + ReplaceSpecialChar(lblContent.Text) + "', '" + lblDate.Text + "', '" + lnkbtnFileTitle.Text.Replace("'", "\\'") + "','','" + hdnTechNotesGroupName.Value.Replace("'", "\\'") + "','" + hdnTechNotesSubGroupName.Value.Replace("'", "\\'") + "','" + hdnSubGroupTechNotesRecordId.Value + "','" + hdnTechNotesFileTypeSubGroup.Value + "','" + hlnkFileLink.NavigateUrl + "','" + hdnTechNotesSubGroupContentStatus.Value + "','" + stypecopy + "');";

            }
        }

        protected void gridCurrentAnnouncements_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            XmlDocument doc = new XmlDocument();
            XmlNode node;

            int recordID = int.Parse(gridCurrentAnnouncements.DataKeys[e.RowIndex].Value.ToString());

            doc.Load(DBProductsfilesPath);

            node = doc.SelectSingleNode("//Product[@ID=" + drpProducts.SelectedValue + "]/Announcements/Announcement[@ID=" + recordID + "]");

            if (node != null)
            {
                XmlNode parent = node.ParentNode;
                parent.RemoveChild(node);
                string newXML = doc.OuterXml;

                doc.Save(DBProductsfilesPath);
            }

            drpCategory_SelectedIndexChanged(sender, e);
        }

        protected void gridPreviousAnnouncements_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "DeleteAnnouncement")
            {
                string recordID = e.CommandArgument.ToString();

                XmlDocument doc = new XmlDocument();
                XmlNode node;

                doc.Load(DBProductsfilesPath);

                node = doc.SelectSingleNode("//Product[@ID=" + drpProducts.SelectedValue + "]/Announcements/Announcement[@ID=" + recordID + "]");

                if (node != null)
                {
                    XmlNode parent = node.ParentNode;
                    parent.RemoveChild(node);
                    string newXML = doc.OuterXml;

                    doc.Save(DBProductsfilesPath);
                }

                drpCategory_SelectedIndexChanged(sender, e);
            }
        }

        protected void gridCurrentVersionUpdates_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(DBProductsfilesPath);

            if (e.CommandName == "Accept")
            {
                string filename = e.CommandArgument.ToString();

                //string filepath = BaseSiteUrl + drpProducts.SelectedItem.Text + "/" + drpCategory.SelectedValue + "/" + filename;

                //ScriptManager.RegisterStartupScript(this, typeof(string), "newWindow", "window.open('" + filepath + "')", true);

                getFileFromOffWebRoot(drpProducts.SelectedItem.Text, drpCategory.SelectedValue, filename);
            }

            if (e.CommandName == "DeleteCurrentVersion")
            {
                string recordID = e.CommandArgument.ToString();

                XmlNode node = doc.SelectSingleNode("//Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "/CurrentVersionUpdates/CurrentVersion[@ID=" + recordID + "]");

                string groupnameselected = node.Attributes["GroupName"].Value;

                if (node != null)
                {
                    XmlNode parent = node.ParentNode;
                    parent.RemoveChild(node);
                    string newXML = doc.OuterXml;

                    doc.Save(DBProductsfilesPath);
                }

                drpCategory_SelectedIndexChanged(sender, e);
            }

            if (e.CommandName == "Up")
            {
                GridViewRow gvrow;
                GridViewRow previousRow;
                string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });

                int index = Convert.ToInt32(commandArgs[0]);
                string strGroupName = commandArgs[1];
                string strSubGroupName = commandArgs[2];
                int indexGroupName = 0;
                XmlNodeList nodeList = null;

                if (strSubGroupName == "" || strSubGroupName == null)
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/CurrentVersionUpdates/CurrentVersion[@GroupName = '" + strGroupName + "' and (@SubGroupName = '" + strSubGroupName + "' or not(@SubGroupName))]");
                }
                else
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/CurrentVersionUpdates/CurrentVersion[@GroupName = '" + strGroupName + "' and @SubGroupName = '" + strSubGroupName + "']");
                }

                if (index != 0)
                {
                    for (int i = 0; i < gridGroupNamesCurrentVersion.Rows.Count; i++)
                    {
                        if (strGroupName == gridGroupNamesCurrentVersion.DataKeys[i].Value.ToString())
                        {
                            indexGroupName = i;
                        }
                    }

                    GridView gvCSGNames = (GridView)gridGroupNamesCurrentVersion.Rows[indexGroupName].FindControl("gridCurrentVersionUpdates");

                    gvrow = gvCSGNames.Rows[index];
                    previousRow = gvCSGNames.Rows[index - 1];
                    int Priority = Convert.ToInt32(gvCSGNames.DataKeys[gvrow.RowIndex].Values["GSCPriority"].ToString());
                    string currentId = gvCSGNames.DataKeys[gvrow.RowIndex].Values["ID"].ToString();
                    string previousId = gvCSGNames.DataKeys[previousRow.RowIndex].Values["ID"].ToString();

                    for (int i = 0; i < nodeList.Count; i++)
                    {
                        if ((nodeList[i].Attributes["ID"].Value == currentId))
                        {
                            nodeList[i].Attributes["GSCPriority"].Value = (Priority + 1).ToString();
                        }

                        if ((nodeList[i].Attributes["ID"].Value == previousId))
                        {
                            nodeList[i].Attributes["GSCPriority"].Value = Priority.ToString();
                        }
                    }
                }

                doc.Save(DBProductsfilesPath);
                drpCategory_SelectedIndexChanged(sender, e);
            }

            if (e.CommandName == "Down")
            {
                GridViewRow gvrow;
                GridViewRow previousRow;
                string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });

                int index = Convert.ToInt32(commandArgs[0]);
                string strGroupName = commandArgs[1];
                string strSubGroupName = commandArgs[2];
                int indexGroupName = 0;
                XmlNodeList nodeList = null;

                if (strSubGroupName == "" || strSubGroupName == null)
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/CurrentVersionUpdates/CurrentVersion[@GroupName = '" + strGroupName + "' and (@SubGroupName = '" + strSubGroupName + "' or not(@SubGroupName))]");
                }
                else
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/CurrentVersionUpdates/CurrentVersion[@GroupName = '" + strGroupName + "' and @SubGroupName = '" + strSubGroupName + "']");
                }

                if (index != nodeList.Count - 1)
                {
                    for (int i = 0; i < gridGroupNamesCurrentVersion.Rows.Count; i++)
                    {
                        if (strGroupName == gridGroupNamesCurrentVersion.DataKeys[i].Value.ToString())
                        {
                            indexGroupName = i;
                        }
                    }

                    GridView gvCSGNames = (GridView)gridGroupNamesCurrentVersion.Rows[indexGroupName].FindControl("gridCurrentVersionUpdates");

                    gvrow = gvCSGNames.Rows[index];
                    previousRow = gvCSGNames.Rows[index + 1];
                    int Priority = Convert.ToInt32(gvCSGNames.DataKeys[gvrow.RowIndex].Values["GSCPriority"].ToString());
                    string currentId = gvCSGNames.DataKeys[gvrow.RowIndex].Values["ID"].ToString();
                    string previousId = gvCSGNames.DataKeys[previousRow.RowIndex].Values["ID"].ToString();

                    for (int i = 0; i < nodeList.Count; i++)
                    {
                        if ((nodeList[i].Attributes["ID"].Value == currentId))
                        {
                            nodeList[i].Attributes["GSCPriority"].Value = (Priority - 1).ToString();
                        }

                        if ((nodeList[i].Attributes["ID"].Value == previousId))
                        {
                            nodeList[i].Attributes["GSCPriority"].Value = Priority.ToString();
                        }
                    }
                }

                doc.Save(DBProductsfilesPath);
                drpCategory_SelectedIndexChanged(sender, e);
            }

        }

        protected void gridCurrentSubVersionUpdates_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(DBProductsfilesPath);

            if (e.CommandName == "Accept")
            {
                string filename = e.CommandArgument.ToString();

                //string filepath = BaseSiteUrl + drpProducts.SelectedItem.Text + "/" + drpCategory.SelectedValue + "/" + filename;

                //ScriptManager.RegisterStartupScript(this, typeof(string), "newWindow", "window.open('" + filepath + "')", true);

                getFileFromOffWebRoot(drpProducts.SelectedItem.Text, drpCategory.SelectedValue, filename);
            }

            if (e.CommandName == "DeleteCurrentVersion")
            {
                string recordID = e.CommandArgument.ToString();

                XmlNode node = doc.SelectSingleNode("//Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "/CurrentVersionUpdates/CurrentVersion[@ID=" + recordID + "]");

                if (node != null)
                {
                    XmlNode parent = node.ParentNode;
                    parent.RemoveChild(node);
                    string newXML = doc.OuterXml;

                    doc.Save(DBProductsfilesPath);
                }

                drpCategory_SelectedIndexChanged(sender, e);
            }

            if (e.CommandName == "Up")
            {
                GridViewRow gvrow;
                GridViewRow previousRow;
                string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });

                int index = Convert.ToInt32(commandArgs[0]);
                string strGroupName = commandArgs[1];
                string strSubGroupName = commandArgs[2];
                int indexGroupName = 0;
                int indexSubGroupName = 0;
                XmlNodeList nodeList = null;

                if (strSubGroupName == "" || strSubGroupName == null)
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/CurrentVersionUpdates/CurrentVersion[@GroupName = '" + strGroupName + "' and (@SubGroupName = '" + strSubGroupName + "' or not(@SubGroupName))]");
                }
                else
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/CurrentVersionUpdates/CurrentVersion[@GroupName = '" + strGroupName + "' and @SubGroupName = '" + strSubGroupName + "']");
                }

                if (index != 0)
                {
                    for (int i = 0; i < gridGroupNamesCurrentVersion.Rows.Count; i++)
                    {
                        if (strGroupName == gridGroupNamesCurrentVersion.DataKeys[i].Value.ToString())
                        {
                            indexGroupName = i;
                        }
                    }

                    GridView gvCSGNames = (GridView)gridGroupNamesCurrentVersion.Rows[indexGroupName].FindControl("gridSubGroupNamesCurrentVersion");

                    for (int j = 0; j < gvCSGNames.Rows.Count; j++)
                    {
                        if (strSubGroupName == gvCSGNames.DataKeys[j].Value.ToString())
                        {
                            indexSubGroupName = j;
                        }
                    }

                    GridView gvCSVU = (GridView)gvCSGNames.Rows[indexSubGroupName].FindControl("gridCurrentSubVersionUpdates");

                    gvrow = gvCSVU.Rows[index];
                    previousRow = gvCSVU.Rows[index - 1];
                    int Priority = Convert.ToInt32(gvCSVU.DataKeys[gvrow.RowIndex].Values["GSCPriority"].ToString());
                    string currentId = gvCSVU.DataKeys[gvrow.RowIndex].Values["ID"].ToString();
                    string previousId = gvCSVU.DataKeys[previousRow.RowIndex].Values["ID"].ToString();

                    for (int i = 0; i < nodeList.Count; i++)
                    {
                        if ((nodeList[i].Attributes["ID"].Value == currentId))
                        {
                            nodeList[i].Attributes["GSCPriority"].Value = (Priority + 1).ToString();
                        }

                        if ((nodeList[i].Attributes["ID"].Value == previousId))
                        {
                            nodeList[i].Attributes["GSCPriority"].Value = Priority.ToString();
                        }
                    }
                }

                doc.Save(DBProductsfilesPath);
                drpCategory_SelectedIndexChanged(sender, e);
            }

            if (e.CommandName == "Down")
            {
                GridViewRow gvrow;
                GridViewRow previousRow;
                string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });

                int index = Convert.ToInt32(commandArgs[0]);
                string strGroupName = commandArgs[1];
                string strSubGroupName = commandArgs[2];
                int indexGroupName = 0;
                int indexSubGroupName = 0;
                XmlNodeList nodeList = null;

                if (strSubGroupName == "" || strSubGroupName == null)
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/CurrentVersionUpdates/CurrentVersion[@GroupName = '" + strGroupName + "' and (@SubGroupName = '" + strSubGroupName + "' or not(@SubGroupName))]");
                }
                else
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/CurrentVersionUpdates/CurrentVersion[@GroupName = '" + strGroupName + "' and @SubGroupName = '" + strSubGroupName + "']");
                }

                if (index != nodeList.Count - 1)
                {
                    for (int i = 0; i < gridGroupNamesCurrentVersion.Rows.Count; i++)
                    {
                        if (strGroupName == gridGroupNamesCurrentVersion.DataKeys[i].Value.ToString())
                        {
                            indexGroupName = i;
                        }
                    }

                    GridView gvCSGNames = (GridView)gridGroupNamesCurrentVersion.Rows[indexGroupName].FindControl("gridSubGroupNamesCurrentVersion");

                    for (int j = 0; j < gvCSGNames.Rows.Count; j++)
                    {
                        if (strSubGroupName == gvCSGNames.DataKeys[j].Value.ToString())
                        {
                            indexSubGroupName = j;
                        }
                    }

                    GridView gvCSVU = (GridView)gvCSGNames.Rows[indexSubGroupName].FindControl("gridCurrentSubVersionUpdates");

                    gvrow = gvCSVU.Rows[index];
                    previousRow = gvCSVU.Rows[index + 1];
                    int Priority = Convert.ToInt32(gvCSVU.DataKeys[gvrow.RowIndex].Values["GSCPriority"].ToString());
                    string currentId = gvCSVU.DataKeys[gvrow.RowIndex].Values["ID"].ToString();
                    string previousId = gvCSVU.DataKeys[previousRow.RowIndex].Values["ID"].ToString();

                    for (int i = 0; i < nodeList.Count; i++)
                    {
                        if ((nodeList[i].Attributes["ID"].Value == currentId))
                        {
                            nodeList[i].Attributes["GSCPriority"].Value = (Priority - 1).ToString();
                        }

                        if ((nodeList[i].Attributes["ID"].Value == previousId))
                        {
                            nodeList[i].Attributes["GSCPriority"].Value = Priority.ToString();
                        }
                    }
                }

                doc.Save(DBProductsfilesPath);
                drpCategory_SelectedIndexChanged(sender, e);
            }

        }

        protected void gridPreviousVersionUpdates_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(DBProductsfilesPath);

            if (e.CommandName == "Accept")
            {
                string filename = e.CommandArgument.ToString();

                //string filepath = BaseSiteUrl + drpProducts.SelectedItem.Text + "/" + drpCategory.SelectedValue + "/" + filename;

                //ScriptManager.RegisterStartupScript(this, typeof(string), "newWindow", "window.open('" + filepath + "')", true);

                getFileFromOffWebRoot(drpProducts.SelectedItem.Text, drpCategory.SelectedValue, filename);
            }

            if (e.CommandName == "DeletePreviousVersion")
            {
                string recordID = e.CommandArgument.ToString();

                XmlNode node = doc.SelectSingleNode("//Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "/PreviousVersionUpdates/PreviousVersion[@ID=" + recordID + "]");

                if (node != null)
                {
                    XmlNode parent = node.ParentNode;
                    parent.RemoveChild(node);
                    string newXML = doc.OuterXml;

                    doc.Save(DBProductsfilesPath);
                }

                drpCategory_SelectedIndexChanged(sender, e);
            }

            if (e.CommandName == "Up")
            {
                GridViewRow gvrow;
                GridViewRow previousRow;
                string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });

                int index = Convert.ToInt32(commandArgs[0]);
                string strGroupName = commandArgs[1];
                string strSubGroupName = commandArgs[2];
                int indexGroupName = 0;
                int indexSubGroupName = 0;
                XmlNodeList nodeList = null;

                if (strSubGroupName == "" || strSubGroupName == null)
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/PreviousVersionUpdates/PreviousVersion[@GroupName = '" + strGroupName + "' and (@SubGroupName = '" + strSubGroupName + "' or not(@SubGroupName))]");
                }
                else
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/PreviousVersionUpdates/PreviousVersion[@GroupName = '" + strGroupName + "' and @SubGroupName = '" + strSubGroupName + "']");
                }

                if (index != 0)
                {
                    for (int i = 0; i < gridGroupNamesPreviousVersion.Rows.Count; i++)
                    {
                        if (strGroupName == gridGroupNamesPreviousVersion.DataKeys[i].Value.ToString())
                        {
                            indexGroupName = i;
                        }
                    }

                    GridView gvPSGNames = (GridView)gridGroupNamesPreviousVersion.Rows[indexGroupName].FindControl("gridPreviousVersionUpdates");

                    gvrow = gvPSGNames.Rows[index];
                    previousRow = gvPSGNames.Rows[index - 1];
                    int Priority = Convert.ToInt32(gvPSGNames.DataKeys[gvrow.RowIndex].Values["GSCPriority"].ToString());
                    string currentId = gvPSGNames.DataKeys[gvrow.RowIndex].Values["ID"].ToString();
                    string previousId = gvPSGNames.DataKeys[previousRow.RowIndex].Values["ID"].ToString();

                    for (int i = 0; i < nodeList.Count; i++)
                    {
                        if ((nodeList[i].Attributes["ID"].Value == currentId))
                        {
                            nodeList[i].Attributes["GSCPriority"].Value = (Priority + 1).ToString();
                        }

                        if ((nodeList[i].Attributes["ID"].Value == previousId))
                        {
                            nodeList[i].Attributes["GSCPriority"].Value = Priority.ToString();
                        }
                    }
                }

                doc.Save(DBProductsfilesPath);
                drpCategory_SelectedIndexChanged(sender, e);
            }

            if (e.CommandName == "Down")
            {
                GridViewRow gvrow;
                GridViewRow previousRow;
                string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });

                int index = Convert.ToInt32(commandArgs[0]);
                string strGroupName = commandArgs[1];
                string strSubGroupName = commandArgs[2];
                int indexGroupName = 0;
                int indexSubGroupName = 0;
                XmlNodeList nodeList = null;

                if (strSubGroupName == "" || strSubGroupName == null)
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/PreviousVersionUpdates/PreviousVersion[@GroupName = '" + strGroupName + "' and (@SubGroupName = '" + strSubGroupName + "' or not(@SubGroupName))]");
                }
                else
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/PreviousVersionUpdates/PreviousVersion[@GroupName = '" + strGroupName + "' and @SubGroupName = '" + strSubGroupName + "']");
                }

                if (index != nodeList.Count - 1)
                {
                    for (int i = 0; i < gridGroupNamesPreviousVersion.Rows.Count; i++)
                    {
                        if (strGroupName == gridGroupNamesPreviousVersion.DataKeys[i].Value.ToString())
                        {
                            indexGroupName = i;
                        }
                    }

                    GridView gvPSGNames = (GridView)gridGroupNamesPreviousVersion.Rows[indexGroupName].FindControl("gridPreviousVersionUpdates");

                    gvrow = gvPSGNames.Rows[index];
                    previousRow = gvPSGNames.Rows[index + 1];
                    int Priority = Convert.ToInt32(gvPSGNames.DataKeys[gvrow.RowIndex].Values["GSCPriority"].ToString());
                    string currentId = gvPSGNames.DataKeys[gvrow.RowIndex].Values["ID"].ToString();
                    string previousId = gvPSGNames.DataKeys[previousRow.RowIndex].Values["ID"].ToString();

                    for (int i = 0; i < nodeList.Count; i++)
                    {
                        if ((nodeList[i].Attributes["ID"].Value == currentId))
                        {
                            nodeList[i].Attributes["GSCPriority"].Value = (Priority - 1).ToString();
                        }

                        if ((nodeList[i].Attributes["ID"].Value == previousId))
                        {
                            nodeList[i].Attributes["GSCPriority"].Value = Priority.ToString();
                        }
                    }
                }

                doc.Save(DBProductsfilesPath);
                drpCategory_SelectedIndexChanged(sender, e);
            }
        }

        protected void gridPreviousSubVersionUpdates_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(DBProductsfilesPath);

            if (e.CommandName == "Accept")
            {
                string filename = e.CommandArgument.ToString();

                //string filepath = BaseSiteUrl + drpProducts.SelectedItem.Text + "/" + drpCategory.SelectedValue + "/" + filename;

                //ScriptManager.RegisterStartupScript(this, typeof(string), "newWindow", "window.open('" + filepath + "')", true);

                getFileFromOffWebRoot(drpProducts.SelectedItem.Text, drpCategory.SelectedValue, filename);
            }

            if (e.CommandName == "DeletePreviousVersion")
            {
                string recordID = e.CommandArgument.ToString();

                XmlNode node = doc.SelectSingleNode("//Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "/PreviousVersionUpdates/PreviousVersion[@ID=" + recordID + "]");

                if (node != null)
                {
                    XmlNode parent = node.ParentNode;
                    parent.RemoveChild(node);
                    string newXML = doc.OuterXml;

                    doc.Save(DBProductsfilesPath);
                }

                drpCategory_SelectedIndexChanged(sender, e);
            }

            if (e.CommandName == "Up")
            {
                GridViewRow gvrow;
                GridViewRow previousRow;
                string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });

                int index = Convert.ToInt32(commandArgs[0]);
                string strGroupName = commandArgs[1];
                string strSubGroupName = commandArgs[2];
                int indexGroupName = 0;
                int indexSubGroupName = 0;
                XmlNodeList nodeList = null;

                if (strSubGroupName == "" || strSubGroupName == null)
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/PreviousVersionUpdates/PreviousVersion[@GroupName = '" + strGroupName + "' and (@SubGroupName = '" + strSubGroupName + "' or not(@SubGroupName))]");
                }
                else
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/PreviousVersionUpdates/PreviousVersion[@GroupName = '" + strGroupName + "' and @SubGroupName = '" + strSubGroupName + "']");
                }

                if (index != 0)
                {
                    for (int i = 0; i < gridGroupNamesPreviousVersion.Rows.Count; i++)
                    {
                        if (strGroupName == gridGroupNamesPreviousVersion.DataKeys[i].Value.ToString())
                        {
                            indexGroupName = i;
                        }
                    }

                    GridView gvPSGNames = (GridView)gridGroupNamesPreviousVersion.Rows[indexGroupName].FindControl("gridSubGroupNamesPreviousVersion");

                    for (int j = 0; j < gvPSGNames.Rows.Count; j++)
                    {
                        if (strSubGroupName == gvPSGNames.DataKeys[j].Value.ToString())
                        {
                            indexSubGroupName = j;
                        }
                    }

                    GridView gvPSVU = (GridView)gvPSGNames.Rows[indexSubGroupName].FindControl("gridPreviousSubVersionUpdates");

                    gvrow = gvPSVU.Rows[index];
                    previousRow = gvPSVU.Rows[index - 1];
                    int Priority = Convert.ToInt32(gvPSVU.DataKeys[gvrow.RowIndex].Values["GSCPriority"].ToString());
                    string currentId = gvPSVU.DataKeys[gvrow.RowIndex].Values["ID"].ToString();
                    string previousId = gvPSVU.DataKeys[previousRow.RowIndex].Values["ID"].ToString();

                    for (int i = 0; i < nodeList.Count; i++)
                    {
                        if ((nodeList[i].Attributes["ID"].Value == currentId))
                        {
                            nodeList[i].Attributes["GSCPriority"].Value = (Priority + 1).ToString();
                        }

                        if ((nodeList[i].Attributes["ID"].Value == previousId))
                        {
                            nodeList[i].Attributes["GSCPriority"].Value = Priority.ToString();
                        }
                    }
                }

                doc.Save(DBProductsfilesPath);
                drpCategory_SelectedIndexChanged(sender, e);
            }

            if (e.CommandName == "Down")
            {
                GridViewRow gvrow;
                GridViewRow previousRow;
                string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });

                int index = Convert.ToInt32(commandArgs[0]);
                string strGroupName = commandArgs[1];
                string strSubGroupName = commandArgs[2];
                int indexGroupName = 0;
                int indexSubGroupName = 0;
                XmlNodeList nodeList = null;

                if (strSubGroupName == "" || strSubGroupName == null)
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/PreviousVersionUpdates/PreviousVersion[@GroupName = '" + strGroupName + "' and (@SubGroupName = '" + strSubGroupName + "' or not(@SubGroupName))]");
                }
                else
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/PreviousVersionUpdates/PreviousVersion[@GroupName = '" + strGroupName + "' and @SubGroupName = '" + strSubGroupName + "']");
                }

                if (index != nodeList.Count - 1)
                {
                    for (int i = 0; i < gridGroupNamesPreviousVersion.Rows.Count; i++)
                    {
                        if (strGroupName == gridGroupNamesPreviousVersion.DataKeys[i].Value.ToString())
                        {
                            indexGroupName = i;
                        }
                    }

                    GridView gvPSGNames = (GridView)gridGroupNamesPreviousVersion.Rows[indexGroupName].FindControl("gridSubGroupNamesPreviousVersion");

                    for (int j = 0; j < gvPSGNames.Rows.Count; j++)
                    {
                        if (strSubGroupName == gvPSGNames.DataKeys[j].Value.ToString())
                        {
                            indexSubGroupName = j;
                        }
                    }

                    GridView gvPSVU = (GridView)gvPSGNames.Rows[indexSubGroupName].FindControl("gridPreviousSubVersionUpdates");

                    gvrow = gvPSVU.Rows[index];
                    previousRow = gvPSVU.Rows[index + 1];
                    int Priority = Convert.ToInt32(gvPSVU.DataKeys[gvrow.RowIndex].Values["GSCPriority"].ToString());
                    string currentId = gvPSVU.DataKeys[gvrow.RowIndex].Values["ID"].ToString();
                    string previousId = gvPSVU.DataKeys[previousRow.RowIndex].Values["ID"].ToString();

                    for (int i = 0; i < nodeList.Count; i++)
                    {
                        if ((nodeList[i].Attributes["ID"].Value == currentId))
                        {
                            nodeList[i].Attributes["GSCPriority"].Value = (Priority - 1).ToString();
                        }

                        if ((nodeList[i].Attributes["ID"].Value == previousId))
                        {
                            nodeList[i].Attributes["GSCPriority"].Value = Priority.ToString();
                        }
                    }
                }

                doc.Save(DBProductsfilesPath);
                drpCategory_SelectedIndexChanged(sender, e);
            }
        }

        protected void gridTechnicalNotes_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(DBProductsfilesPath);

            if (e.CommandName == "Accept")
            {
                string filename = e.CommandArgument.ToString();

                //string filepath = BaseSiteUrl + drpProducts.SelectedItem.Text + "/" + drpCategory.SelectedValue + "/" + filename;

                //ScriptManager.RegisterStartupScript(this, typeof(string), "newWindow", "window.open('" + filepath + "')", true);

                getFileFromOffWebRoot(drpProducts.SelectedItem.Text, drpCategory.SelectedValue, filename);
            }

            if (e.CommandName == "DeleteTechnicalNotes")
            {
                string recordID = e.CommandArgument.ToString();

                XmlNode node = doc.SelectSingleNode("//Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "/TechnicalNotes[@ID=" + recordID + "]");

                if (node != null)
                {
                    XmlNode parent = node.ParentNode;
                    parent.RemoveChild(node);
                    string newXML = doc.OuterXml;

                    doc.Save(DBProductsfilesPath);
                }

                drpCategory_SelectedIndexChanged(sender, e);
            }

            if (e.CommandName == "Up")
            {
                GridViewRow gvrow;
                GridViewRow previousRow;

                int indexGroupName = 0;
                int indexSubGroupName = 0;

                string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });
                int index = Convert.ToInt32(commandArgs[0]);
                string strGroupName = commandArgs[1];
                string strSubGroupName = commandArgs[2];
                XmlNodeList nodeList = null;

                if (strSubGroupName == "" || strSubGroupName == null)
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/TechnicalNotes[@GroupName = '" + strGroupName + "' and (@SubGroupName = '" + strSubGroupName + "' or not(@SubGroupName))]");
                }
                else
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/TechnicalNotes[@GroupName = '" + strGroupName + "' and @SubGroupName = '" + strSubGroupName + "']");
                }

                if (index != 0)
                {
                    for (int i = 0; i < gridGroupNamesTechnicalNotes.Rows.Count; i++)
                    {
                        if (strGroupName == gridGroupNamesTechnicalNotes.DataKeys[i].Value.ToString())
                        {
                            indexGroupName = i;
                        }
                    }

                    GridView gvTNGNames = (GridView)gridGroupNamesTechnicalNotes.Rows[indexGroupName].FindControl("gridTechnicalNotes");

                    gvrow = gvTNGNames.Rows[index];
                    previousRow = gvTNGNames.Rows[index - 1];
                    int Priority = Convert.ToInt32(gvTNGNames.DataKeys[gvrow.RowIndex].Values["GSCPriority"].ToString());
                    string currentId = gvTNGNames.DataKeys[gvrow.RowIndex].Values["ID"].ToString();
                    string previousId = gvTNGNames.DataKeys[previousRow.RowIndex].Values["ID"].ToString();

                    for (int i = 0; i < nodeList.Count; i++)
                    {
                        if ((nodeList[i].Attributes["ID"].Value == currentId))
                        {
                            nodeList[i].Attributes["GSCPriority"].Value = (Priority + 1).ToString();
                        }

                        if ((nodeList[i].Attributes["ID"].Value == previousId))
                        {
                            nodeList[i].Attributes["GSCPriority"].Value = Priority.ToString();
                        }
                    }
                }

                doc.Save(DBProductsfilesPath);
                drpCategory_SelectedIndexChanged(sender, e);
            }

            if (e.CommandName == "Down")
            {
                GridViewRow gvrow;
                GridViewRow previousRow;
                int indexGroupName = 0;
                int indexSubGroupName = 0;

                string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });
                int index = Convert.ToInt32(commandArgs[0]);
                string strGroupName = commandArgs[1];
                string strSubGroupName = commandArgs[2];
                XmlNodeList nodeList = null;

                if (strSubGroupName == "" || strSubGroupName == null)
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/TechnicalNotes[@GroupName = '" + strGroupName + "' and (@SubGroupName = '" + strSubGroupName + "' or not(@SubGroupName))]");
                }
                else
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/TechnicalNotes[@GroupName = '" + strGroupName + "' and @SubGroupName = '" + strSubGroupName + "']");
                }

                if (index != nodeList.Count - 1)
                {
                    for (int i = 0; i < gridGroupNamesTechnicalNotes.Rows.Count; i++)
                    {
                        if (strGroupName == gridGroupNamesTechnicalNotes.DataKeys[i].Value.ToString())
                        {
                            indexGroupName = i;
                        }
                    }

                    GridView gvTNGNames = (GridView)gridGroupNamesTechnicalNotes.Rows[indexGroupName].FindControl("gridTechnicalNotes");

                    gvrow = gvTNGNames.Rows[index];
                    previousRow = gvTNGNames.Rows[index + 1];
                    int Priority = Convert.ToInt32(gvTNGNames.DataKeys[gvrow.RowIndex].Values["GSCPriority"].ToString());
                    string currentId = gvTNGNames.DataKeys[gvrow.RowIndex].Values["ID"].ToString();
                    string previousId = gvTNGNames.DataKeys[previousRow.RowIndex].Values["ID"].ToString();

                    for (int i = 0; i < nodeList.Count; i++)
                    {
                        if ((nodeList[i].Attributes["ID"].Value == currentId))
                        {
                            nodeList[i].Attributes["GSCPriority"].Value = (Priority - 1).ToString();
                        }

                        if ((nodeList[i].Attributes["ID"].Value == previousId))
                        {
                            nodeList[i].Attributes["GSCPriority"].Value = Priority.ToString();
                        }
                    }
                }

                doc.Save(DBProductsfilesPath);
                drpCategory_SelectedIndexChanged(sender, e);
            }
        }

        protected void gridSubGroupTechnicalNotes_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(DBProductsfilesPath);

            if (e.CommandName == "Accept")
            {
                string filename = e.CommandArgument.ToString();

                //string filepath = BaseSiteUrl + drpProducts.SelectedItem.Text + "/" + drpCategory.SelectedValue + "/" + filename;

                //ScriptManager.RegisterStartupScript(this, typeof(string), "newWindow", "window.open('" + filepath + "')", true);

                getFileFromOffWebRoot(drpProducts.SelectedItem.Text, drpCategory.SelectedValue, filename);
            }

            if (e.CommandName == "DeleteTechnicalNotes")
            {
                string recordID = e.CommandArgument.ToString();

                XmlNode node = doc.SelectSingleNode("//Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "/TechnicalNotes[@ID=" + recordID + "]");

                if (node != null)
                {
                    XmlNode parent = node.ParentNode;
                    parent.RemoveChild(node);
                    string newXML = doc.OuterXml;

                    doc.Save(DBProductsfilesPath);
                }

                drpCategory_SelectedIndexChanged(sender, e);
            }

            if (e.CommandName == "Up")
            {
                GridViewRow gvrow;
                GridViewRow previousRow;
                string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });

                int index = Convert.ToInt32(commandArgs[0]);
                string strGroupName = commandArgs[1];
                string strSubGroupName = commandArgs[2];
                int indexGroupName = 0;
                int indexSubGroupName = 0;
                XmlNodeList nodeList = null;

                if (strSubGroupName == "" || strSubGroupName == null)
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/TechnicalNotes[@GroupName = '" + strGroupName + "' and (@SubGroupName = '" + strSubGroupName + "' or not(@SubGroupName))]");
                }
                else
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/TechnicalNotes[@GroupName = '" + strGroupName + "' and @SubGroupName = '" + strSubGroupName + "']");
                }

                if (index != 0)
                {
                    for (int i = 0; i < gridGroupNamesTechnicalNotes.Rows.Count; i++)
                    {
                        if (strGroupName == gridGroupNamesTechnicalNotes.DataKeys[i].Value.ToString())
                        {
                            indexGroupName = i;
                        }
                    }

                    GridView gvTNSGNames = (GridView)gridGroupNamesTechnicalNotes.Rows[indexGroupName].FindControl("gridSubGroupNamesTechnicalNotes");

                    for (int j = 0; j < gvTNSGNames.Rows.Count; j++)
                    {
                        if (strSubGroupName == gvTNSGNames.DataKeys[j].Value.ToString())
                        {
                            indexSubGroupName = j;
                        }
                    }

                    GridView gvTNSVU = (GridView)gvTNSGNames.Rows[indexSubGroupName].FindControl("gridSubGroupTechnicalNotes");

                    gvrow = gvTNSVU.Rows[index];
                    previousRow = gvTNSVU.Rows[index - 1];
                    int Priority = Convert.ToInt32(gvTNSVU.DataKeys[gvrow.RowIndex].Values["GSCPriority"].ToString());
                    string currentId = gvTNSVU.DataKeys[gvrow.RowIndex].Values["ID"].ToString();
                    string previousId = gvTNSVU.DataKeys[previousRow.RowIndex].Values["ID"].ToString();

                    for (int i = 0; i < nodeList.Count; i++)
                    {
                        if ((nodeList[i].Attributes["ID"].Value == currentId))
                        {
                            nodeList[i].Attributes["GSCPriority"].Value = (Priority + 1).ToString();
                        }

                        if ((nodeList[i].Attributes["ID"].Value == previousId))
                        {
                            nodeList[i].Attributes["GSCPriority"].Value = Priority.ToString();
                        }
                    }
                }

                doc.Save(DBProductsfilesPath);
                drpCategory_SelectedIndexChanged(sender, e);
            }

            if (e.CommandName == "Down")
            {
                GridViewRow gvrow;
                GridViewRow previousRow;
                string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });

                int index = Convert.ToInt32(commandArgs[0]);
                string strGroupName = commandArgs[1];
                string strSubGroupName = commandArgs[2];
                int indexGroupName = 0;
                int indexSubGroupName = 0;
                XmlNodeList nodeList = null;

                if (strSubGroupName == "" || strSubGroupName == null)
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/TechnicalNotes[@GroupName = '" + strGroupName + "' and @SubGroupName = '" + strSubGroupName + "' or not(@SubGroupName))]");
                }
                else
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/TechnicalNotes[@GroupName = '" + strGroupName + "' and @SubGroupName = '" + strSubGroupName + "']");
                }

                if (index != nodeList.Count - 1)
                {
                    for (int i = 0; i < gridGroupNamesTechnicalNotes.Rows.Count; i++)
                    {
                        if (strGroupName == gridGroupNamesTechnicalNotes.DataKeys[i].Value.ToString())
                        {
                            indexGroupName = i;
                        }
                    }

                    GridView gvTNSGNames = (GridView)gridGroupNamesTechnicalNotes.Rows[indexGroupName].FindControl("gridSubGroupNamesTechnicalNotes");

                    for (int j = 0; j < gvTNSGNames.Rows.Count; j++)
                    {
                        if (strSubGroupName == gvTNSGNames.DataKeys[j].Value.ToString())
                        {
                            indexSubGroupName = j;
                        }
                    }

                    GridView gvTNSVU = (GridView)gvTNSGNames.Rows[indexSubGroupName].FindControl("gridSubGroupTechnicalNotes");

                    gvrow = gvTNSVU.Rows[index];
                    previousRow = gvTNSVU.Rows[index + 1];
                    int Priority = Convert.ToInt32(gvTNSVU.DataKeys[gvrow.RowIndex].Values["GSCPriority"].ToString());
                    string currentId = gvTNSVU.DataKeys[gvrow.RowIndex].Values["ID"].ToString();
                    string previousId = gvTNSVU.DataKeys[previousRow.RowIndex].Values["ID"].ToString();

                    for (int i = 0; i < nodeList.Count; i++)
                    {
                        if ((nodeList[i].Attributes["ID"].Value == currentId))
                        {
                            nodeList[i].Attributes["GSCPriority"].Value = (Priority - 1).ToString();
                        }

                        if ((nodeList[i].Attributes["ID"].Value == previousId))
                        {
                            nodeList[i].Attributes["GSCPriority"].Value = Priority.ToString();
                        }
                    }
                }

                doc.Save(DBProductsfilesPath);
                drpCategory_SelectedIndexChanged(sender, e);
            }
        }

        protected void getFileFromOffWebRoot(string pName, string pCat, string pFile)
        {
            //build session scoped variables to pass into get file
            Session["prodName"] = pName;
            Session["prodCat"] = pCat;
            Session["fileName"] = pFile;

            Response.Redirect("getFile.aspx");
        }

        protected void gridGroupNamesCurrentVersion_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                GridView gv = (GridView)e.Row.FindControl("gridCurrentVersionUpdates");
                gv.RowDataBound += new GridViewRowEventHandler(gridCurrentVersionUpdates_RowDataBound);
                string groupName = gridGroupNamesCurrentVersion.DataKeys[e.Row.RowIndex].Value.ToString();
                GridView gvsubGroupCV = (GridView)e.Row.FindControl("gridSubGroupNamesCurrentVersion");

                if (groupName != "")
                {
                    getContentbyGroupNameCurrentVersion(groupName, "GroupName", groupName, gv);

                    DataSet dsSubgroupnames = new DataSet();
                    dsSubgroupnames = getSubGroupNamesbyGroupName(groupName, "CurrentVersion");
                    gvsubGroupCV.DataSource = dsSubgroupnames;
                    gvsubGroupCV.DataBind();
                }
            }
        }

        protected void gridSubGroupNamesCurrentVersion_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                GridView gvsubGroup = (GridView)e.Row.FindControl("gridCurrentSubVersionUpdates");
                gvsubGroup.RowDataBound += new GridViewRowEventHandler(gridCurrentSubVersionUpdates_RowDataBound);

                LinkButton btnlnkcvSubgroupname = e.Row.FindControl("btnlnkcvSubgroupname") as LinkButton;
                //Label lblcvSubgroupname = e.Row.FindControl("lblcvSubgroupname") as Label;
                HiddenField hdnCurrentVerGroupNameSub = e.Row.FindControl("hdnCurrentVerGroupNameSub") as HiddenField;
                //string subGroupName = lblcvSubgroupname.Text;
                string subGroupName = btnlnkcvSubgroupname.Text;

                if (subGroupName != "")
                {
                    getContentbyGroupNameCurrentVersion(subGroupName, "SubGroupName", hdnCurrentVerGroupNameSub.Value, gvsubGroup);
                }
            }
        }

        protected void gridGroupNamesPreviousVersion_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                GridView gv = (GridView)e.Row.FindControl("gridPreviousVersionUpdates");
                gv.RowDataBound += new GridViewRowEventHandler(gridPreviousVersionUpdates_RowDataBound);
                string groupName = gridGroupNamesPreviousVersion.DataKeys[e.Row.RowIndex].Value.ToString();
                GridView gvsubGroupPV = (GridView)e.Row.FindControl("gridSubGroupNamesPreviousVersion");

                if (groupName != "")
                {
                    getContentbyGroupNamePreviousVersion(groupName, "GroupName", groupName, gv);

                    DataSet dsSubgroupnames = new DataSet();
                    dsSubgroupnames = getSubGroupNamesbyGroupName(groupName, "PreviousVersion");
                    gvsubGroupPV.DataSource = dsSubgroupnames;
                    gvsubGroupPV.DataBind();
                }
            }
        }

        protected void gridSubGroupNamesPreviousVersion_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                GridView gvsubGroup = (GridView)e.Row.FindControl("gridPreviousSubVersionUpdates");
                gvsubGroup.RowDataBound += new GridViewRowEventHandler(gridPreviousSubVersionUpdates_RowDataBound);

                LinkButton btnlnkpvsubgroupname = e.Row.FindControl("btnlnkpvsubgroupname") as LinkButton;
                //Label lblpvSubgroupname = e.Row.FindControl("lblpvSubgroupname") as Label;
                HiddenField hdnPreviousVerGroupNameSub = e.Row.FindControl("hdnPreviousVerGroupNameSub") as HiddenField;
                //string subGroupName = lblpvSubgroupname.Text;
                string subGroupName = btnlnkpvsubgroupname.Text;

                if (subGroupName != "")
                {
                    getContentbyGroupNamePreviousVersion(subGroupName, "SubGroupName", hdnPreviousVerGroupNameSub.Value, gvsubGroup);
                }
            }

        }

        protected void gridGroupNamesTechnicalNotes_RowDataBound(object sender, GridViewRowEventArgs e)
        {

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                GridView gv = (GridView)e.Row.FindControl("gridTechnicalNotes");
                gv.RowDataBound += new GridViewRowEventHandler(gridTechnicalNotes_RowDataBound);
                string groupName = gridGroupNamesTechnicalNotes.DataKeys[e.Row.RowIndex].Value.ToString();
                GridView gvsubGroupTechNotes = (GridView)e.Row.FindControl("gridSubGroupNamesTechnicalNotes");

                if (groupName != "")
                {
                    getContentbyGroupNameTechnicalNotes(groupName, "GroupName", groupName, gv);

                    DataSet dsSubgroupnames = new DataSet();
                    dsSubgroupnames = getSubGroupNamesbyGroupNameTechNotes(groupName, "TechnicalNotes");

                    gvsubGroupTechNotes.DataSource = dsSubgroupnames;
                    gvsubGroupTechNotes.DataBind();
                }
            }
        }

        protected void gridSubGroupNamesTechnicalNotes_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                GridView gv = (GridView)e.Row.FindControl("gridSubGroupTechnicalNotes");
                gv.RowDataBound += new GridViewRowEventHandler(gridSubGroupTechnicalNotes_RowDataBound);

                LinkButton lnkbtnSubGroupNameTechNotes = e.Row.FindControl("lnkbtnSubGroupNameTechNotes") as LinkButton;
                //Label lblTechnicalNotesSubGroupName = e.Row.FindControl("lblTechnicalNotesSubGroupName") as Label;
                HiddenField hdnTechnicalNotesGroupNameSub = e.Row.FindControl("hdnTechnicalNotesGroupNameSub") as HiddenField;
                //string subGroupName = lblTechnicalNotesSubGroupName.Text;
                string subGroupName = lnkbtnSubGroupNameTechNotes.Text;

                if (subGroupName != "")
                {
                    getContentbyGroupNameTechnicalNotes(subGroupName, "SubGroupName", hdnTechnicalNotesGroupNameSub.Value, gv);
                }
            }
        }

        protected DataSet getSubGroupNamesbyGroupName(string gname, string versionType)
        {
            XElement xml = XElement.Load(DBProductsfilesPath);

            string versionnode = null;
            string groupNode = null;

            if (versionType == "PreviousVersion")
            {
                versionnode = "PreviousVersionUpdates";
                groupNode = "SubGroupsPreviousVersion";
            }

            if (versionType == "CurrentVersion")
            {
                versionnode = "CurrentVersionUpdates";
                groupNode = "SubGroupsCurrentVersion";
            }

            var result = xml.Elements("Product").
        Where(el => el.Attribute("ID").Value.Equals(drpProducts.SelectedValue)).
        SelectMany(el => el.Elements(drpCategory.SelectedItem.Value).Elements(versionnode).Elements(versionType)).
        Where(el => el.Attribute("GroupName").Value.Equals(gname)).
        Select(f => new
        {
            GroupName = f.Attributes().Where(x => x.Name == "GroupName").
                Select(x => x.Value).FirstOrDefault(),
            SubGroupName = f.Attributes().Where(x => x.Name == "SubGroupName").
                Select(x => x.Value).FirstOrDefault(),
            ID = f.Attributes().Where(x => x.Name == "ID").
                Select(x => x.Value).FirstOrDefault()
        }
             );

            DataSet ds = new DataSet();
            DataTable dt = new DataTable(versionType);
            dt.Columns.Add(new DataColumn("SubGroupName", typeof(string)));
            dt.Columns.Add(new DataColumn("GroupName", typeof(string)));

            foreach (var element in result)
            {
                var row = dt.NewRow();
                if ((element.SubGroupName != "") && (element.SubGroupName != null))
                {
                    row["SubGroupName"] = element.SubGroupName;
                    row["GroupName"] = element.GroupName;
                    dt.Rows.Add(row);
                }
            }

            dt = dt.DefaultView.ToTable(true, "GroupName", "SubGroupName");

            //To order the SubGroups

            DataSet dtSubGroupNamesbyVersion = getGroupDetailsbyNode(groupNode, "SubGroupName");

            DataTable dtSubGroupNames = new DataTable("SubGroupName");
            dtSubGroupNames.Columns.Add(new DataColumn("GroupName", typeof(string)));
            dtSubGroupNames.Columns.Add(new DataColumn("SubGroupName", typeof(string)));
            dtSubGroupNames.Columns.Add(new DataColumn("Priority", typeof(int)));

            for (int j = 0; j < dtSubGroupNamesbyVersion.Tables["SubGroupName"].Rows.Count; j++)
            {
                string strsubgroupname = dtSubGroupNamesbyVersion.Tables["SubGroupName"].Rows[j]["SubGroupName"].ToString();
                string strPriority = dtSubGroupNamesbyVersion.Tables["SubGroupName"].Rows[j]["Priority"].ToString();

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (strsubgroupname == dt.Rows[i]["SubGroupName"].ToString())
                    {
                        var row = dtSubGroupNames.NewRow();
                        row["SubGroupName"] = dt.Rows[i]["SubGroupName"].ToString();
                        row["GroupName"] = dt.Rows[i]["GroupName"].ToString();
                        row["Priority"] = strPriority;
                        dtSubGroupNames.Rows.Add(row);
                    }
                }
            }

            ds.Tables.Add(dtSubGroupNames);

            ds.Tables[0].DefaultView.Sort = "Priority desc";
            DataTable dtord = ds.Tables[0].DefaultView.ToTable();
            ds.Tables[0].Rows.Clear();
            foreach (DataRow row in dtord.Rows)
                ds.Tables[0].Rows.Add(row.ItemArray);

            return ds;
        }

        protected DataSet getSubGroupNamesbyGroupNameTechNotes(string gname, string versionType)
        {
            XElement xml = XElement.Load(DBProductsfilesPath);

            var result = xml.Elements("Product").
        Where(el => el.Attribute("ID").Value.Equals(drpProducts.SelectedValue)).
        SelectMany(el => el.Elements(drpCategory.SelectedItem.Value).Elements(versionType)).
        Where(el => el.Attribute("GroupName").Value.Equals(gname)).
        Select(f => new
        {
            GroupName = f.Attributes().Where(x => x.Name == "GroupName").
                Select(x => x.Value).FirstOrDefault(),
            SubGroupName = f.Attributes().Where(x => x.Name == "SubGroupName").
                Select(x => x.Value).FirstOrDefault(),
            ID = f.Attributes().Where(x => x.Name == "ID").
                Select(x => x.Value).FirstOrDefault()
        }
             );

            DataSet ds = new DataSet();
            DataTable dt = new DataTable(versionType);
            dt.Columns.Add(new DataColumn("SubGroupName", typeof(string)));
            dt.Columns.Add(new DataColumn("GroupName", typeof(string)));

            foreach (var element in result)
            {
                var row = dt.NewRow();
                if ((element.SubGroupName != "") && (element.SubGroupName != null))
                {
                    row["SubGroupName"] = element.SubGroupName;
                    row["GroupName"] = element.GroupName;
                    dt.Rows.Add(row);
                }
            }

            dt = dt.DefaultView.ToTable(true, "GroupName", "SubGroupName");

            //To order the SubGroups

            DataSet dtSubGroupNamesTechNotes = getGroupDetailsbyNode("SubGroupsTechnicalNotes", "SubGroupName");

            DataTable dtTechnicalNotes = new DataTable("SubGroupName");
            dtTechnicalNotes.Columns.Add(new DataColumn("GroupName", typeof(string)));
            dtTechnicalNotes.Columns.Add(new DataColumn("SubGroupName", typeof(string)));
            dtTechnicalNotes.Columns.Add(new DataColumn("Priority", typeof(int)));

            for (int j = 0; j < dtSubGroupNamesTechNotes.Tables["SubGroupName"].Rows.Count; j++)
            {
                string strsubgroupname = dtSubGroupNamesTechNotes.Tables["SubGroupName"].Rows[j]["SubGroupName"].ToString();
                string strPriority = dtSubGroupNamesTechNotes.Tables["SubGroupName"].Rows[j]["Priority"].ToString();

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (strsubgroupname == dt.Rows[i]["SubGroupName"].ToString())
                    {
                        var row = dtTechnicalNotes.NewRow();
                        row["SubGroupName"] = dt.Rows[i]["SubGroupName"].ToString();
                        row["GroupName"] = dt.Rows[i]["GroupName"].ToString();
                        row["Priority"] = strPriority;
                        dtTechnicalNotes.Rows.Add(row);
                    }
                }
            }

            ds.Tables.Add(dtTechnicalNotes);

            ds.Tables[0].DefaultView.Sort = "Priority desc";
            DataTable dtord = ds.Tables[0].DefaultView.ToTable();
            ds.Tables[0].Rows.Clear();
            foreach (DataRow row in dtord.Rows)
                ds.Tables[0].Rows.Add(row.ItemArray);

            return ds;
        }

        protected void getContentbyGroupNameCurrentVersion(string gname, string gType, string groupName, GridView GridViewContent)
        {
            XElement xml = XElement.Load(DBProductsfilesPath);

            var result = xml.Elements("Product").
        Where(el => el.Attribute("ID").Value.Equals(drpProducts.SelectedValue)).
        SelectMany(el => el.Elements(drpCategory.SelectedItem.Value).Elements("CurrentVersionUpdates").Elements("CurrentVersion")).
        Where(el => el.Attribute(gType) != null && el.Attribute(gType).Value.Equals(gname) && el.Attribute("GroupName").Value.Equals(groupName)).
        Select(f => new
        {
            Date = f.Attributes().Where(x => x.Name == "Date").
                Select(x => x.Value).FirstOrDefault(),
            Description = f.Attributes().Where(x => x.Name == "Description").
                Select(x => x.Value).FirstOrDefault(),
            FileName = f.Attributes().Where(x => x.Name == "FileName").
                Select(x => x.Value).FirstOrDefault(),
            FileTitle = f.Attributes().Where(x => x.Name == "FileTitle").
                Select(x => x.Value).FirstOrDefault(),
            Filesize = f.Attributes().Where(x => x.Name == "Filesize").
                Select(x => x.Value).FirstOrDefault(),
            ImportantUpdate = f.Attributes().Where(x => x.Name == "ImportantUpdate").
                Select(x => x.Value).FirstOrDefault(),
            GroupName = f.Attributes().Where(x => x.Name == "GroupName").
                Select(x => x.Value).FirstOrDefault(),
            SubGroupName = f.Attributes().Where(x => x.Name == "SubGroupName").
                Select(x => x.Value).FirstOrDefault(),
            FileType = f.Attributes().Where(x => x.Name == "FileType").
                Select(x => x.Value).FirstOrDefault(),
            FileLink = f.Attributes().Where(x => x.Name == "FileLink").
                Select(x => x.Value).FirstOrDefault(),
            GSCPriority = f.Attributes().Where(x => x.Name == "GSCPriority").
                Select(x => x.Value).FirstOrDefault(),
            ID = f.Attributes().Where(x => x.Name == "ID").
                Select(x => x.Value).FirstOrDefault(),
            Status = f.Attributes().Where(x => x.Name == "Status").
                Select(x => x.Value).FirstOrDefault()
        }
            ).OrderByDescending(s => Convert.ToInt32(s.GSCPriority));

            DataSet ds = new DataSet();
            DataTable dt = new DataTable("CurrentVersion");
            dt.Columns.Add(new DataColumn("Date", typeof(string)));
            dt.Columns.Add(new DataColumn("Description", typeof(string)));
            dt.Columns.Add(new DataColumn("FileName", typeof(string)));
            dt.Columns.Add(new DataColumn("FileTitle", typeof(string)));
            dt.Columns.Add(new DataColumn("Filesize", typeof(string)));
            dt.Columns.Add(new DataColumn("ImportantUpdate", typeof(string)));
            dt.Columns.Add(new DataColumn("GroupName", typeof(string)));
            dt.Columns.Add(new DataColumn("SubGroupName", typeof(string)));
            dt.Columns.Add(new DataColumn("FileType", typeof(string)));
            dt.Columns.Add(new DataColumn("FileLink", typeof(string)));
            dt.Columns.Add(new DataColumn("GSCPriority", typeof(string)));
            dt.Columns.Add(new DataColumn("ID", typeof(string)));
            dt.Columns.Add(new DataColumn("Status", typeof(string)));

            foreach (var element in result)
            {
                DateTime ddate = Convert.ToDateTime(element.Date, System.Globalization.CultureInfo.InvariantCulture);
                var row = dt.NewRow();

                row["Date"] = ddate.ToString("dd MMMM yyyy");
                row["Description"] = element.Description;
                row["FileName"] = element.FileName;
                row["FileTitle"] = element.FileTitle;
                row["Filesize"] = element.Filesize;
                row["ImportantUpdate"] = element.ImportantUpdate;
                row["GroupName"] = element.GroupName;
                row["SubGroupName"] = element.SubGroupName;
                row["FileType"] = element.FileType;
                row["FileLink"] = element.FileLink;
                row["GSCPriority"] = element.GSCPriority;
                row["ID"] = element.ID;
                row["Status"] = element.Status;
                dt.Rows.Add(row);
            }

            ds.Tables.Add(dt);

            DataTable dtgroups = new DataTable("GroupNames");
            dtgroups.Columns.Add(new DataColumn("Date", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("Description", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("FileName", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("FileTitle", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("Filesize", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("ImportantUpdate", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("GroupName", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("SubGroupName", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("FileType", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("FileLink", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("GSCPriority", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("ID", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("Status", typeof(string)));

            DataTable dtSubgroups = new DataTable("SubGroupNames");
            dtSubgroups.Columns.Add(new DataColumn("Date", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("Description", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("FileName", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("FileTitle", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("Filesize", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("ImportantUpdate", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("GroupName", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("SubGroupName", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("FileType", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("FileLink", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("GSCPriority", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("ID", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("Status", typeof(string)));

            for (int i = 0; i < ds.Tables["CurrentVersion"].Rows.Count; i++)
            {
                if (ds.Tables["CurrentVersion"].Rows[i]["SubGroupName"].ToString() == "")
                {
                    dtgroups.Rows.Add(ds.Tables[0].Rows[i]["Date"], ds.Tables[0].Rows[i]["Description"], ds.Tables[0].Rows[i]["FileName"], ds.Tables[0].Rows[i]["FileTitle"], ds.Tables[0].Rows[i]["Filesize"], ds.Tables[0].Rows[i]["ImportantUpdate"], ds.Tables[0].Rows[i]["GroupName"], ds.Tables[0].Rows[i]["SubGroupName"], ds.Tables[0].Rows[i]["FileType"], ds.Tables[0].Rows[i]["FileLink"], ds.Tables[0].Rows[i]["GSCPriority"], ds.Tables[0].Rows[i]["ID"], ds.Tables[0].Rows[i]["Status"]);
                }
                else
                {
                    dtSubgroups.Rows.Add(ds.Tables[0].Rows[i]["Date"], ds.Tables[0].Rows[i]["Description"], ds.Tables[0].Rows[i]["FileName"], ds.Tables[0].Rows[i]["FileTitle"], ds.Tables[0].Rows[i]["Filesize"], ds.Tables[0].Rows[i]["ImportantUpdate"], ds.Tables[0].Rows[i]["GroupName"], ds.Tables[0].Rows[i]["SubGroupName"], ds.Tables[0].Rows[i]["FileType"], ds.Tables[0].Rows[i]["FileLink"], ds.Tables[0].Rows[i]["GSCPriority"], ds.Tables[0].Rows[i]["ID"], ds.Tables[0].Rows[i]["Status"]);
                }
            }

            if (GridViewContent.ID == "gridCurrentVersionUpdates")
            {
                GridViewContent.DataSource = dtgroups;
            }
            else
            {
                GridViewContent.DataSource = dtSubgroups;
            }

            GridViewContent.DataBind();

            foreach (GridViewRow tt in GridViewContent.Rows)
            {
                if (tt.RowType == DataControlRowType.DataRow)
                {
                    Label lblImportantContent = (Label)tt.FindControl("lblImportantContent");
                    Label lblImportantContenttext = (Label)tt.FindControl("lblImportantContenttext");
                    HiddenField hdnCurrentVerFileType = null;

                    if (gType == "SubGroupName")
                    {
                        hdnCurrentVerFileType = (HiddenField)tt.FindControl("hdnCurrentVerFileTypeSubGroup");
                    }
                    else
                    {
                        hdnCurrentVerFileType = (HiddenField)tt.FindControl("hdnCurrentVerFileTypeGroup");
                    }

                    LinkButton lnkbtnFileTitleCV = (LinkButton)tt.FindControl("lnkbtnFileTitleCV");
                    HyperLink hlnkFileLinkCV = (HyperLink)tt.FindControl("hlnkFileLinkCV");
                    ImageButton imgButton = (ImageButton)tt.FindControl("imgButton");
                    HyperLink hlnkimageCV = (HyperLink)tt.FindControl("hlnkimageCV");
                    Label lblFileName = (Label)tt.FindControl("lblFileName");

                    Label lblFileSize = (Label)tt.FindControl("lblFileSize");
                    Label lblDate = (Label)tt.FindControl("lblDate");
                    Label lblContent = (Label)tt.FindControl("lblContent");
                    lblFileName.ForeColor = System.Drawing.ColorTranslator.FromHtml("#003399");

                    if (hdnCurrentVerFileType.Value == "1")
                    {
                        lnkbtnFileTitleCV.Style["display"] = "show";
                        hlnkFileLinkCV.Style["display"] = "none";
                        imgButton.Style["display"] = "show";
                        hlnkimageCV.Style["display"] = "none";
                        lblFileName.Style["display"] = "show";
                    }

                    if (hdnCurrentVerFileType.Value == "2")
                    {
                        lnkbtnFileTitleCV.Style["display"] = "none";
                        hlnkFileLinkCV.Style["display"] = "show";
                        imgButton.Style["display"] = "none";
                        hlnkimageCV.Style["display"] = "show";
                        lblFileName.Style["display"] = "none";
                    }

                    if (hdnCurrentVerFileType.Value == "3")
                    {
                        lnkbtnFileTitleCV.Style["display"] = "none";
                        hlnkFileLinkCV.Style["display"] = "none";
                        imgButton.Style["display"] = "none";
                        hlnkimageCV.Style["display"] = "none";
                        lblFileName.Style["display"] = "show";
                        lblFileName.Text = lblContent.Text;
                        lblContent.Visible = false;
                        lblDate.Visible = false; ;
                        lblFileSize.Visible = false;
                        lblFileName.ForeColor = System.Drawing.Color.Black;
                        lblFileName.Font.Bold = false;
                    }

                    if (lblImportantContenttext != null)
                    {
                        if (lblImportantContenttext.Text == "")
                        {
                            lblImportantContent.Visible = false;
                            lblImportantContenttext.Visible = false;
                        }
                    }
                }
            }
        }

        protected void getContentbyGroupNamePreviousVersion(string gname, string gType, string groupName, GridView GridViewContent)
        {
            XElement xml = XElement.Load(DBProductsfilesPath);

            var result = xml.Elements("Product").
        Where(el => el.Attribute("ID").Value.Equals(drpProducts.SelectedValue)).
        SelectMany(el => el.Elements(drpCategory.SelectedItem.Value).Elements("PreviousVersionUpdates").Elements("PreviousVersion")).
        Where(el => el.Attribute(gType) != null && el.Attribute(gType).Value.Equals(gname) && el.Attribute("GroupName").Value.Equals(groupName)).
        Select(f => new
        {
            Date = f.Attributes().Where(x => x.Name == "Date").
                Select(x => x.Value).FirstOrDefault(),
            Description = f.Attributes().Where(x => x.Name == "Description").
                Select(x => x.Value).FirstOrDefault(),
            FileName = f.Attributes().Where(x => x.Name == "FileName").
                Select(x => x.Value).FirstOrDefault(),
            FileTitle = f.Attributes().Where(x => x.Name == "FileTitle").
                Select(x => x.Value).FirstOrDefault(),
            Filesize = f.Attributes().Where(x => x.Name == "Filesize").
                Select(x => x.Value).FirstOrDefault(),
            ImportantUpdate = f.Attributes().Where(x => x.Name == "ImportantUpdate").
                Select(x => x.Value).FirstOrDefault(),
            GroupName = f.Attributes().Where(x => x.Name == "GroupName").
                Select(x => x.Value).FirstOrDefault(),
            SubGroupName = f.Attributes().Where(x => x.Name == "SubGroupName").
                Select(x => x.Value).FirstOrDefault(),
            FileType = f.Attributes().Where(x => x.Name == "FileType").
                Select(x => x.Value).FirstOrDefault(),
            FileLink = f.Attributes().Where(x => x.Name == "FileLink").
                Select(x => x.Value).FirstOrDefault(),
            GSCPriority = f.Attributes().Where(x => x.Name == "GSCPriority").
                Select(x => x.Value).FirstOrDefault(),
            ID = f.Attributes().Where(x => x.Name == "ID").
                Select(x => x.Value).FirstOrDefault(),
            Status = f.Attributes().Where(x => x.Name == "Status").
                Select(x => x.Value).FirstOrDefault()
        }
            ).OrderByDescending(s => Convert.ToInt32(s.GSCPriority));

            DataSet ds = new DataSet();
            DataTable dt = new DataTable("PreviousVersion");
            dt.Columns.Add(new DataColumn("Date", typeof(string)));
            dt.Columns.Add(new DataColumn("Description", typeof(string)));
            dt.Columns.Add(new DataColumn("FileName", typeof(string)));
            dt.Columns.Add(new DataColumn("FileTitle", typeof(string)));
            dt.Columns.Add(new DataColumn("Filesize", typeof(string)));
            dt.Columns.Add(new DataColumn("ImportantUpdate", typeof(string)));
            dt.Columns.Add(new DataColumn("GroupName", typeof(string)));
            dt.Columns.Add(new DataColumn("SubGroupName", typeof(string)));
            dt.Columns.Add(new DataColumn("FileType", typeof(string)));
            dt.Columns.Add(new DataColumn("FileLink", typeof(string)));
            dt.Columns.Add(new DataColumn("GSCPriority", typeof(string)));
            dt.Columns.Add(new DataColumn("ID", typeof(string)));
            dt.Columns.Add(new DataColumn("Status", typeof(string)));

            foreach (var element in result)
            {
                try
                {
                    DateTime ddate = Convert.ToDateTime(element.Date, System.Globalization.CultureInfo.InvariantCulture);
                    var row = dt.NewRow();
                    row["Date"] = ddate.ToString("dd MMMM yyyy");
                    row["Description"] = element.Description;
                    row["FileName"] = element.FileName;
                    row["FileTitle"] = element.FileTitle;
                    row["Filesize"] = element.Filesize;
                    row["ImportantUpdate"] = element.ImportantUpdate;
                    row["GroupName"] = element.GroupName;
                    row["SubGroupName"] = element.SubGroupName;
                    row["FileType"] = element.FileType;
                    row["FileLink"] = element.FileLink;
                    row["GSCPriority"] = element.GSCPriority;
                    row["ID"] = element.ID;
                    row["Status"] = element.Status;
                    dt.Rows.Add(row);
                }
                catch
                {
                    var row = dt.NewRow();
                    row["Date"] = "";
                    row["Description"] = "";
                    row["FileName"] = "";
                    row["FileTitle"] = "";
                    row["Filesize"] = "";
                    row["ImportantUpdate"] = "";
                    row["GroupName"] = "";
                    row["SubGroupName"] = "";
                    row["FileType"] = "";
                    row["FileLink"] = "";
                    row["GSCPriority"] = "";
                    row["ID"] = "";
                    row["Status"] = "";
                    dt.Rows.Add(row);

                }


            }

            ds.Tables.Add(dt);

            DataTable dtgroups = new DataTable("GroupNames");
            dtgroups.Columns.Add(new DataColumn("Date", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("Description", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("FileName", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("FileTitle", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("Filesize", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("ImportantUpdate", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("GroupName", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("SubGroupName", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("FileType", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("FileLink", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("GSCPriority", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("ID", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("Status", typeof(string)));

            DataTable dtSubgroups = new DataTable("SubGroupNames");
            dtSubgroups.Columns.Add(new DataColumn("Date", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("Description", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("FileName", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("FileTitle", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("Filesize", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("ImportantUpdate", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("GroupName", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("SubGroupName", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("FileType", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("FileLink", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("GSCPriority", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("ID", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("Status", typeof(string)));

            for (int i = 0; i < ds.Tables["PreviousVersion"].Rows.Count; i++)
            {
                if (ds.Tables["PreviousVersion"].Rows[i]["SubGroupName"].ToString() == "")
                {
                    dtgroups.Rows.Add(ds.Tables[0].Rows[i]["Date"], ds.Tables[0].Rows[i]["Description"], ds.Tables[0].Rows[i]["FileName"], ds.Tables[0].Rows[i]["FileTitle"], ds.Tables[0].Rows[i]["Filesize"], ds.Tables[0].Rows[i]["ImportantUpdate"], ds.Tables[0].Rows[i]["GroupName"], ds.Tables[0].Rows[i]["SubGroupName"], ds.Tables[0].Rows[i]["FileType"], ds.Tables[0].Rows[i]["FileLink"], ds.Tables[0].Rows[i]["GSCPriority"], ds.Tables[0].Rows[i]["ID"], ds.Tables[0].Rows[i]["Status"]);
                }
                else
                {
                    dtSubgroups.Rows.Add(ds.Tables[0].Rows[i]["Date"], ds.Tables[0].Rows[i]["Description"], ds.Tables[0].Rows[i]["FileName"], ds.Tables[0].Rows[i]["FileTitle"], ds.Tables[0].Rows[i]["Filesize"], ds.Tables[0].Rows[i]["ImportantUpdate"], ds.Tables[0].Rows[i]["GroupName"], ds.Tables[0].Rows[i]["SubGroupName"], ds.Tables[0].Rows[i]["FileType"], ds.Tables[0].Rows[i]["FileLink"], ds.Tables[0].Rows[i]["GSCPriority"], ds.Tables[0].Rows[i]["ID"], ds.Tables[0].Rows[i]["Status"]);
                }
            }

            if (GridViewContent.ID == "gridPreviousVersionUpdates")
            {
                GridViewContent.DataSource = dtgroups;
            }
            else
            {
                GridViewContent.DataSource = dtSubgroups;
            }

            GridViewContent.DataBind();

            foreach (GridViewRow tt in GridViewContent.Rows)
            {
                if (tt.RowType == DataControlRowType.DataRow)
                {
                    Label lblImportantContent = (Label)tt.FindControl("lblImportantContent");
                    Label lblImportantContenttext = (Label)tt.FindControl("lblImportantContenttext");
                    HiddenField hdnPreviousVerFileType = null;

                    if (gType == "SubGroupName")
                    {
                        hdnPreviousVerFileType = (HiddenField)tt.FindControl("hdnPreviousVerFileTypeSubGroup");
                    }
                    else
                    {
                        hdnPreviousVerFileType = (HiddenField)tt.FindControl("hdnPreviousVerFileTypeGroup");
                    }

                    LinkButton lnkbtnFileTitlePV = (LinkButton)tt.FindControl("lnkbtnFileTitlePV");
                    HyperLink hlnkFileLinkPV = (HyperLink)tt.FindControl("hlnkFileLinkPV");
                    ImageButton imgbtn = (ImageButton)tt.FindControl("imgbtn");
                    HyperLink hlnkimagePV = (HyperLink)tt.FindControl("hlnkimagePV");
                    Label lblFileName = (Label)tt.FindControl("lblFileName");

                    Label lblFileSize = (Label)tt.FindControl("lblFileSize");
                    Label lblDate = (Label)tt.FindControl("lblDate");
                    Label lblContent = (Label)tt.FindControl("lblContent");
                    lblFileName.ForeColor = System.Drawing.ColorTranslator.FromHtml("#003399");

                    if (hdnPreviousVerFileType.Value == "1")
                    {
                        lnkbtnFileTitlePV.Style["display"] = "show";
                        hlnkFileLinkPV.Style["display"] = "none";
                        imgbtn.Style["display"] = "show";
                        hlnkimagePV.Style["display"] = "none";
                        lblFileName.Style["display"] = "show";
                    }

                    if (hdnPreviousVerFileType.Value == "2")
                    {
                        lnkbtnFileTitlePV.Style["display"] = "none";
                        hlnkFileLinkPV.Style["display"] = "show";
                        imgbtn.Style["display"] = "none";
                        hlnkimagePV.Style["display"] = "show";
                        lblFileName.Style["display"] = "none";
                    }

                    if (hdnPreviousVerFileType.Value == "3")
                    {
                        lnkbtnFileTitlePV.Style["display"] = "none";
                        hlnkFileLinkPV.Style["display"] = "none";
                        imgbtn.Style["display"] = "none";
                        hlnkimagePV.Style["display"] = "none";
                        lblFileName.Style["display"] = "show";
                        lblFileName.Text = lblContent.Text;
                        lblContent.Visible = false;
                        lblDate.Visible = false; ;
                        lblFileSize.Visible = false;
                        lblFileName.ForeColor = System.Drawing.Color.Black;
                        lblFileName.Font.Bold = false;
                    }


                    if (lblImportantContenttext != null)
                    {
                        if (lblImportantContenttext.Text == "")
                        {
                            lblImportantContent.Visible = false;
                            lblImportantContenttext.Visible = false;
                        }
                    }
                }
            }
        }

        protected void getContentbyGroupNameTechnicalNotes(string gname, string gType, string groupName, GridView GridViewContent)
        {
            XElement xml = XElement.Load(DBProductsfilesPath);

            var result = xml.Elements("Product").
        Where(el => el.Attribute("ID").Value.Equals(drpProducts.SelectedValue)).
        SelectMany(el => el.Elements(drpCategory.SelectedItem.Value).Elements("TechnicalNotes")).
        Where(el => el.Attribute(gType) != null && el.Attribute(gType).Value.Equals(gname) && el.Attribute("GroupName").Value.Equals(groupName)).
        Select(f => new
        {
            Date = f.Attributes().Where(x => x.Name == "Date").
                Select(x => x.Value).FirstOrDefault(),
            Description = f.Attributes().Where(x => x.Name == "Description").
                Select(x => x.Value).FirstOrDefault(),
            FileName = f.Attributes().Where(x => x.Name == "FileName").
                Select(x => x.Value).FirstOrDefault(),
            FileTitle = f.Attributes().Where(x => x.Name == "FileTitle").
                Select(x => x.Value).FirstOrDefault(),
            Filesize = f.Attributes().Where(x => x.Name == "Filesize").
                Select(x => x.Value).FirstOrDefault(),
            GroupName = f.Attributes().Where(x => x.Name == "GroupName").
                Select(x => x.Value).FirstOrDefault(),
            SubGroupName = f.Attributes().Where(x => x.Name == "SubGroupName").
                Select(x => x.Value).FirstOrDefault(),
            FileType = f.Attributes().Where(x => x.Name == "FileType").
                Select(x => x.Value).FirstOrDefault(),
            FileLink = f.Attributes().Where(x => x.Name == "FileLink").
                Select(x => x.Value).FirstOrDefault(),
            GSCPriority = f.Attributes().Where(x => x.Name == "GSCPriority").
                Select(x => x.Value).FirstOrDefault(),
            ID = f.Attributes().Where(x => x.Name == "ID").
                Select(x => x.Value).FirstOrDefault(),
            Status = f.Attributes().Where(x => x.Name == "Status").
                Select(x => x.Value).FirstOrDefault()
        }
            ).OrderByDescending(s => Convert.ToInt32(s.GSCPriority));

            DataSet ds = new DataSet();
            DataTable dt = new DataTable("TechnicalNotes");
            dt.Columns.Add(new DataColumn("Date", typeof(string)));
            dt.Columns.Add(new DataColumn("Description", typeof(string)));
            dt.Columns.Add(new DataColumn("FileName", typeof(string)));
            dt.Columns.Add(new DataColumn("FileTitle", typeof(string)));
            dt.Columns.Add(new DataColumn("Filesize", typeof(string)));
            dt.Columns.Add(new DataColumn("GroupName", typeof(string)));
            dt.Columns.Add(new DataColumn("SubGroupName", typeof(string)));
            dt.Columns.Add(new DataColumn("FileType", typeof(string)));
            dt.Columns.Add(new DataColumn("FileLink", typeof(string)));
            dt.Columns.Add(new DataColumn("GSCPriority", typeof(string)));
            dt.Columns.Add(new DataColumn("ID", typeof(string)));
            dt.Columns.Add(new DataColumn("Status", typeof(string)));

            foreach (var element in result)
            {
                DateTime ddate = Convert.ToDateTime(element.Date, System.Globalization.CultureInfo.InvariantCulture);
                var row = dt.NewRow();

                row["Date"] = ddate.ToString("dd MMMM yyyy");
                row["Description"] = element.Description;
                row["FileName"] = element.FileName;
                row["FileTitle"] = element.FileTitle;
                row["Filesize"] = element.Filesize;
                row["GroupName"] = element.GroupName;
                row["SubGroupName"] = element.SubGroupName;
                row["FileType"] = element.FileType;
                row["FileLink"] = element.FileLink;
                row["GSCPriority"] = element.GSCPriority;
                row["ID"] = element.ID;
                row["Status"] = element.Status;
                dt.Rows.Add(row);
            }

            ds.Tables.Add(dt);

            DataTable dtgroups = new DataTable("GroupNames");
            dtgroups.Columns.Add(new DataColumn("Date", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("Description", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("FileName", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("FileTitle", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("Filesize", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("GroupName", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("SubGroupName", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("FileType", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("FileLink", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("GSCPriority", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("ID", typeof(string)));
            dtgroups.Columns.Add(new DataColumn("Status", typeof(string)));

            DataTable dtSubgroups = new DataTable("SubGroupNames");
            dtSubgroups.Columns.Add(new DataColumn("Date", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("Description", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("FileName", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("FileTitle", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("Filesize", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("GroupName", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("SubGroupName", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("FileType", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("FileLink", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("GSCPriority", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("ID", typeof(string)));
            dtSubgroups.Columns.Add(new DataColumn("Status", typeof(string)));

            for (int i = 0; i < ds.Tables["TechnicalNotes"].Rows.Count; i++)
            {
                if (ds.Tables["TechnicalNotes"].Rows[i]["SubGroupName"].ToString() == "")
                {
                    dtgroups.Rows.Add(ds.Tables[0].Rows[i]["Date"], ds.Tables[0].Rows[i]["Description"], ds.Tables[0].Rows[i]["FileName"], ds.Tables[0].Rows[i]["FileTitle"], ds.Tables[0].Rows[i]["Filesize"], ds.Tables[0].Rows[i]["GroupName"], ds.Tables[0].Rows[i]["SubGroupName"], ds.Tables[0].Rows[i]["FileType"], ds.Tables[0].Rows[i]["FileLink"], ds.Tables[0].Rows[i]["GSCPriority"], ds.Tables[0].Rows[i]["ID"], ds.Tables[0].Rows[i]["Status"]);
                }
                else
                {
                    dtSubgroups.Rows.Add(ds.Tables[0].Rows[i]["Date"], ds.Tables[0].Rows[i]["Description"], ds.Tables[0].Rows[i]["FileName"], ds.Tables[0].Rows[i]["FileTitle"], ds.Tables[0].Rows[i]["Filesize"], ds.Tables[0].Rows[i]["GroupName"], ds.Tables[0].Rows[i]["SubGroupName"], ds.Tables[0].Rows[i]["FileType"], ds.Tables[0].Rows[i]["FileLink"], ds.Tables[0].Rows[i]["GSCPriority"], ds.Tables[0].Rows[i]["ID"], ds.Tables[0].Rows[i]["Status"]);
                }
            }

            if (GridViewContent.ID == "gridTechnicalNotes")
            {
                GridViewContent.DataSource = dtgroups;
            }
            else
            {
                GridViewContent.DataSource = dtSubgroups;
            }

            GridViewContent.DataBind();

            foreach (GridViewRow tt in GridViewContent.Rows)
            {
                if (tt.RowType == DataControlRowType.DataRow)
                {
                    HiddenField hdnTechNotesFileType = null;

                    if (gType == "SubGroupName")
                    {
                        hdnTechNotesFileType = (HiddenField)tt.FindControl("hdnTechNotesFileTypeSubGroup");
                    }
                    else
                    {
                        hdnTechNotesFileType = (HiddenField)tt.FindControl("hdnTechNotesFileTypeGroup");
                    }

                    LinkButton lnkbtnFileTitle = (LinkButton)tt.FindControl("lnkbtnFileTitle");
                    HyperLink hlnkFileLink = (HyperLink)tt.FindControl("hlnkFileLink");
                    ImageButton imgbtnTechNotes = (ImageButton)tt.FindControl("imgbtnTechNotes");
                    HyperLink hlnkimageTechNotes = (HyperLink)tt.FindControl("hlnkimageTechNotes");
                    Label lblFileName = (Label)tt.FindControl("lblFileName");

                    Label lblFileSize = (Label)tt.FindControl("lblFileSize");
                    Label lblDate = (Label)tt.FindControl("lblDate");
                    Label lblContent = (Label)tt.FindControl("lblContent");
                    lblFileName.ForeColor = System.Drawing.ColorTranslator.FromHtml("#003399");

                    if (hdnTechNotesFileType.Value == "1")
                    {
                        lnkbtnFileTitle.Style["display"] = "show";
                        hlnkFileLink.Style["display"] = "none";
                        imgbtnTechNotes.Style["display"] = "show";
                        hlnkimageTechNotes.Style["display"] = "none";
                        lblFileName.Style["display"] = "show";
                    }

                    if (hdnTechNotesFileType.Value == "2")
                    {
                        lnkbtnFileTitle.Style["display"] = "none";
                        hlnkFileLink.Style["display"] = "show";
                        imgbtnTechNotes.Style["display"] = "none";
                        hlnkimageTechNotes.Style["display"] = "show";
                        lblFileName.Style["display"] = "none";
                    }

                    if (hdnTechNotesFileType.Value == "3")
                    {
                        lnkbtnFileTitle.Style["display"] = "none";
                        hlnkFileLink.Style["display"] = "none";
                        imgbtnTechNotes.Style["display"] = "none";
                        hlnkimageTechNotes.Style["display"] = "none";
                        lblFileName.Style["display"] = "show";
                        lblFileName.Text = lblContent.Text;
                        lblContent.Visible = false;
                        lblDate.Visible = false; ;
                        lblFileSize.Visible = false;
                        lblFileName.ForeColor = System.Drawing.Color.Black;
                        lblFileName.Font.Bold = false;
                    }
                }
            }
        }

        public static string FirstCharToUpper(string s)
        {
            // Check for empty string.
            if (string.IsNullOrEmpty(s))
            {
                return string.Empty;
            }
            // Return char and concat substring.
            return char.ToUpper(s[0]) + s.Substring(1);
        }

        public static string ReplaceSpecialChar(string s)
        {
            //http://stackoverflow.com/questions/18693646/how-to-keep-xml-from-converting-r-n-into-xdxa

            //could replace these with non-english characters ø or õ
            //return System.Text.RegularExpressions.Regex.Replace(s, "[^a-zA-Z0-9_]+", " ");

            return s.Replace("'", "&#39").Replace(@"\", " ");

        }


        protected DataTable getDistinctGroupNamesSelectedNode(string nodeName)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(DBProductsfilesPath);
            XmlNode node;

            if (nodeName == "TechnicalNotes")
            {
                node = doc.SelectSingleNode("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "");
            }
            else
            {
                node = doc.SelectSingleNode("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/" + nodeName);
            }

            DataTable dtGroupNames = new DataTable("GroupName");
            dtGroupNames.Columns.Add(new DataColumn("GroupName", typeof(string)));
            DataRow drgroup;
            String groupName = null;

            if (node != null)
            {
                for (int j = 0; j < node.ChildNodes.Count; j++)
                {
                    if (node.ChildNodes[j].Attributes["GroupName"] != null)
                    {
                        groupName = node.ChildNodes[j].Attributes["GroupName"].Value;

                        drgroup = dtGroupNames.NewRow();
                        dtGroupNames.Rows.Add(groupName);
                    }
                }
            }
            dtGroupNames = GetDistinctRecords(dtGroupNames, "GroupName");

            return dtGroupNames;
        }

        protected DataTable getDistinctSubGroupNamesSelectedNode(string nodeName)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(DBProductsfilesPath);
            XmlNode node;

            if (nodeName == "TechnicalNotes")
            {
                node = doc.SelectSingleNode("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "");
            }
            else
            {
                node = doc.SelectSingleNode("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/" + nodeName);
            }

            DataTable dtSubGroupNames = new DataTable("SubGroupName");
            dtSubGroupNames.Columns.Add(new DataColumn("SubGroupName", typeof(string)));
            DataRow drgroup;
            String subgroupName = null;

            if (node != null)
            {
                for (int j = 0; j < node.ChildNodes.Count; j++)
                {
                    if (node.ChildNodes[j].Attributes["SubGroupName"] != null)
                    {
                        subgroupName = node.ChildNodes[j].Attributes["SubGroupName"].Value;

                        drgroup = dtSubGroupNames.NewRow();
                        dtSubGroupNames.Rows.Add(subgroupName);
                    }
                }
            }
            dtSubGroupNames = GetDistinctRecords(dtSubGroupNames, "SubGroupName");

            return dtSubGroupNames;
        }

        protected DataSet getGroupDetailsbyNode(string parentNode, string childNode)
        {
            XmlDocument doc = new XmlDocument();

            doc.Load(DBProductsfilesPath);

            XmlNodeList nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/" + parentNode + "/" + childNode);

            DataSet ds = new DataSet();
            DataTable dt = new DataTable(childNode);
            dt.Columns.Add(new DataColumn(childNode, typeof(string)));
            dt.Columns.Add(new DataColumn("Priority", typeof(int)));
            dt.Columns.Add(new DataColumn("ID", typeof(string)));
            DataRow dr;

            for (int i = 0; i < nodeList.Count; i++)
            {
                dr = dt.NewRow();
                dr[childNode] = nodeList[i].Attributes["Name"].Value;
                dr["Priority"] = nodeList[i].Attributes["Priority"].Value;
                dr["ID"] = nodeList[i].Attributes["ID"].Value;
                dt.Rows.Add(dr);
            }

            ds.Tables.Add(dt);

            ds.Tables[0].DefaultView.Sort = "Priority desc";
            DataTable dtord = ds.Tables[0].DefaultView.ToTable();
            ds.Tables[0].Rows.Clear();
            foreach (DataRow row in dtord.Rows)
                ds.Tables[0].Rows.Add(row.ItemArray);

            return ds;
        }

        protected void getGroupDetailsTechnicalNotes(object sender, EventArgs e)
        {
            DataSet dsGroupDetails = new DataSet();
            dsGroupDetails = getGroupDetailsbyNode("GroupsTechnicalNotes", "GroupName");

            gridAddGroupNamesTechNotes.DataSource = dsGroupDetails;
            gridAddGroupNamesTechNotes.DataBind();
            pnlAddGroupNamesTechNotes.Style["display"] = "show";

            if (gridAddGroupNamesTechNotes.Rows.Count == 0)
            {
                System.Data.DataTable dt = null;
                dt = ((System.Data.DataSet)gridAddGroupNamesTechNotes.DataSource).Tables[0].Clone();
                dt.Rows.Add(dt.NewRow()); // add empty row
                gridAddGroupNamesTechNotes.DataSource = dt;
                gridAddGroupNamesTechNotes.DataBind();

                gridAddGroupNamesTechNotes.Rows[0].Style["display"] = "none";
            }

            DataSet dtGroupNames = getGroupDetailsbyNode("GroupsTechnicalNotes", "GroupName");

            drpTechNotesGroupNames.DataSource = dtGroupNames;
            drpTechNotesGroupNames.DataTextField = "GroupName";
            drpTechNotesGroupNames.DataValueField = "GroupName";
            drpTechNotesGroupNames.DataBind();
            drpTechNotesGroupNames.Items.Insert(0, "--Select--");
        }

        protected void getSubGroupDetailsTechnicalNotes(object sender, EventArgs e)
        {
            DataSet dsSubGroupDetails = new DataSet();
            dsSubGroupDetails = getGroupDetailsbyNode("SubGroupsTechnicalNotes", "SubGroupName");

            gridAddSubGroupnamesTechNotes.DataSource = dsSubGroupDetails;
            gridAddSubGroupnamesTechNotes.DataBind();
            pnlAddSubGroupnamesTechNotes.Style["display"] = "show";

            if (gridAddSubGroupnamesTechNotes.Rows.Count == 0)
            {
                System.Data.DataTable dt = null;
                dt = ((System.Data.DataSet)gridAddSubGroupnamesTechNotes.DataSource).Tables[0].Clone();
                dt.Rows.Add(dt.NewRow()); // add empty row
                gridAddSubGroupnamesTechNotes.DataSource = dt;
                gridAddSubGroupnamesTechNotes.DataBind();

                gridAddSubGroupnamesTechNotes.Rows[0].Style["display"] = "none";
            }

            DataSet dtSubGroupNames = getGroupDetailsbyNode("SubGroupsTechnicalNotes", "SubGroupName");

            drpTechNotesSubGroupNames.DataSource = dtSubGroupNames;
            drpTechNotesSubGroupNames.DataTextField = "SubGroupName";
            drpTechNotesSubGroupNames.DataValueField = "SubGroupName";
            drpTechNotesSubGroupNames.DataBind();
            drpTechNotesSubGroupNames.Items.Insert(0, "--None--");
        }

        protected void gridAddGroupNamesTechNotes_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gridAddGroupNamesTechNotes.EditIndex = e.NewEditIndex;
            getGroupDetailsTechnicalNotes(sender, e);
        }

        protected void gridAddGroupNamesTechNotes_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            string editedGroupname = ((TextBox)gridAddGroupNamesTechNotes.Rows[e.RowIndex].FindControl("txtEditGroupNameTechNotes")).Text;

            XmlDocument xdocAddGroupName = new XmlDocument();

            xdocAddGroupName.Load(DBProductsfilesPath);

            XmlNode node = xdocAddGroupName.SelectSingleNode("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "");

            for (int j = 0; j < node.ChildNodes.Count; j++)
            {
                if (node.ChildNodes[j].Attributes["GroupName"] != null)
                {
                    if (node.ChildNodes[j].Attributes["GroupName"].Value == gridAddGroupNamesTechNotes.DataKeys[e.RowIndex].Values["GroupName"].ToString())
                    {
                        node.ChildNodes[j].Attributes["GroupName"].Value = editedGroupname;
                    }

                }
            }

            XmlNodeList nodeList = xdocAddGroupName.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/GroupsTechnicalNotes/GroupName");

            for (int i = 0; i < nodeList.Count; i++)
            {
                if (nodeList[i].Attributes.Count > 0)
                {
                    string name = nodeList[i].Attributes["Name"].Value;

                    if ((name != null) && (nodeList[i].Attributes["ID"].Value == gridAddGroupNamesTechNotes.DataKeys[e.RowIndex].Values["ID"].ToString()))
                    {
                        nodeList[i].Attributes["Name"].Value = editedGroupname;
                    }
                }
            }

            xdocAddGroupName.Save(DBProductsfilesPath);

            gridAddGroupNamesTechNotes.EditIndex = -1;
            getGroupDetailsTechnicalNotes(sender, e);
        }

        protected void gridAddGroupNamesTechNotes_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gridAddGroupNamesTechNotes.EditIndex = -1;
            getGroupDetailsTechnicalNotes(sender, e);
        }

        protected void gridAddGroupNamesTechNotes_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            XmlDocument xdoc = new XmlDocument();

            xdoc.Load(DBProductsfilesPath);

            XmlNodeList deletenodelist = xdoc.SelectNodes("//Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/GroupsTechnicalNotes/GroupName");

            DataTable dtContentGroups = getDistinctGroupNamesSelectedNode("TechnicalNotes");
            string selectedGroupName = gridAddGroupNamesTechNotes.DataKeys[e.RowIndex].Values["GroupName"].ToString();

            bool isGroupAvailable = dtContentGroups.AsEnumerable().Any(row => selectedGroupName == row.Field<string>("GroupName"));

            if ((deletenodelist != null) && (isGroupAvailable == false))
            {
                for (int i = 0; i < deletenodelist.Count; i++)
                {
                    if (deletenodelist[i].Attributes["ID"].Value == gridAddGroupNamesTechNotes.DataKeys[e.RowIndex].Values["ID"].ToString())
                    {
                        XmlNode parent = deletenodelist[i].ParentNode;
                        parent.RemoveChild(deletenodelist[i]);
                    }
                }
            }

            xdoc.Save(DBProductsfilesPath);

            gridAddGroupNamesTechNotes.EditIndex = -1;
            getGroupDetailsTechnicalNotes(sender, e);
        }

        protected void gridAddGroupNamesTechNotes_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            XmlDocument xdocAddGroupName = new XmlDocument();
            xdocAddGroupName.Load(DBProductsfilesPath);

            if (e.CommandName == "Add")
            {
                XmlNode node = xdocAddGroupName.SelectSingleNode("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "");

                if (node["GroupsTechnicalNotes"] == null)
                {
                    XmlElement newVersionElem = xdocAddGroupName.CreateElement("GroupsTechnicalNotes");
                    node.AppendChild(newVersionElem);
                }

                int groupID = 0;
                XmlNode xnodegroupID = xdocAddGroupName.SelectSingleNode("//Products/Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "/GroupsTechnicalNotes/GroupName/@ID[not(. <=../preceding-sibling::GroupName/@iD) and not(. <=../following-sibling::GroupName/@ID)]");

                if (xnodegroupID == null)
                {
                    groupID = 1;
                }
                else
                {
                    groupID = Convert.ToInt32(xnodegroupID.Value) + 1;
                }

                XmlElement eGroupName = xdocAddGroupName.CreateElement("GroupName");

                XmlAttribute ID = xdocAddGroupName.CreateAttribute("ID");
                ID.Value = groupID.ToString();
                eGroupName.Attributes.Append(ID);

                XmlAttribute gName = xdocAddGroupName.CreateAttribute("Name");
                gName.InnerText = FirstCharToUpper(((TextBox)gridAddGroupNamesTechNotes.HeaderRow.FindControl("txtHeaderGroupNameTechNotes")).Text);
                eGroupName.Attributes.Append(gName);

                int PriorityID = 0;
                XmlNode xnodeGroupPriority = xdocAddGroupName.SelectSingleNode("//Products/Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "/GroupsTechnicalNotes/GroupName/@Priority[not(. <=../preceding-sibling::GroupName/@Priority) and not(. <=../following-sibling::GroupName/@Priority)]");

                if (xnodeGroupPriority == null)
                {
                    PriorityID = 1;
                }
                else
                {
                    PriorityID = Convert.ToInt32(xnodeGroupPriority.Value) + 1;
                }

                XmlAttribute groupPriority = xdocAddGroupName.CreateAttribute("Priority");
                groupPriority.InnerText = PriorityID.ToString();
                eGroupName.Attributes.Append(groupPriority);

                XmlNode xnodeGroups = xdocAddGroupName.SelectSingleNode("//Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/GroupsTechnicalNotes");
                xnodeGroups.AppendChild(eGroupName);

                node.AppendChild(xnodeGroups);

                xdocAddGroupName.Save(DBProductsfilesPath);
                getGroupDetailsTechnicalNotes(sender, e);
            }

            if (e.CommandName == "UpdatePreference")
            {
                XmlNodeList nodeList = xdocAddGroupName.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/GroupsTechnicalNotes/GroupName");

                if (nodeList.Count > 1)
                {
                    int[] Ids = (from i in Request.Form["groupIdTechNotes"].Split(',')
                                 select int.Parse(i)).ToArray();

                    int Priority = nodeList.Count;
                    foreach (int currentId in Ids)
                    {
                        for (int i = 0; i < nodeList.Count; i++)
                        {
                            if ((nodeList[i].Attributes["ID"].Value == currentId.ToString()))
                            {
                                nodeList[i].Attributes["Priority"].Value = Priority.ToString();
                                break;
                            }
                        }

                        xdocAddGroupName.Save(DBProductsfilesPath);
                        Priority = Priority - 1;
                    }

                    getGroupDetailsTechnicalNotes(sender, e);
                }
            }


            if (e.CommandName == "Close")
            {
                pnlAddGroupNamesTechNotes.Style["display"] = "none";
            }
        }

        protected void gridAddSubGroupnamesTechNotes_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gridAddSubGroupnamesTechNotes.EditIndex = e.NewEditIndex;
            getSubGroupDetailsTechnicalNotes(sender, e);
        }

        protected void gridAddSubGroupnamesTechNotes_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            string editedGroupname = ((TextBox)gridAddSubGroupnamesTechNotes.Rows[e.RowIndex].FindControl("txtEditSubGroupNameTechNotes")).Text;

            XmlDocument xdocAddGroupName = new XmlDocument();

            xdocAddGroupName.Load(DBProductsfilesPath);

            XmlNode node = xdocAddGroupName.SelectSingleNode("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "");

            for (int j = 0; j < node.ChildNodes.Count; j++)
            {
                if (node.ChildNodes[j].Attributes["SubGroupName"] != null)
                {
                    if (node.ChildNodes[j].Attributes["SubGroupName"].Value == gridAddSubGroupnamesTechNotes.DataKeys[e.RowIndex].Values["SubGroupName"].ToString())
                    {
                        node.ChildNodes[j].Attributes["SubGroupName"].Value = editedGroupname;
                    }

                }
            }

            XmlNodeList nodeList = xdocAddGroupName.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/SubGroupsTechnicalNotes/SubGroupName");

            for (int i = 0; i < nodeList.Count; i++)
            {
                if (nodeList[i].Attributes.Count > 0)
                {
                    string name = nodeList[i].Attributes["Name"].Value;

                    if ((name != null) && (nodeList[i].Attributes["ID"].Value == gridAddSubGroupnamesTechNotes.DataKeys[e.RowIndex].Values["ID"].ToString()))
                    {
                        nodeList[i].Attributes["Name"].Value = editedGroupname;
                    }
                }
            }

            xdocAddGroupName.Save(DBProductsfilesPath);

            gridAddSubGroupnamesTechNotes.EditIndex = -1;
            getSubGroupDetailsTechnicalNotes(sender, e);
        }

        protected void gridAddSubGroupnamesTechNotes_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gridAddSubGroupnamesTechNotes.EditIndex = -1;
            getSubGroupDetailsTechnicalNotes(sender, e);
        }

        protected void gridAddSubGroupnamesTechNotes_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            XmlDocument xdoc = new XmlDocument();

            xdoc.Load(DBProductsfilesPath);

            XmlNodeList deletenodelist = xdoc.SelectNodes("//Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/SubGroupsTechnicalNotes/SubGroupName");

            DataTable dtContentSubGroups = getDistinctSubGroupNamesSelectedNode("TechnicalNotes");
            string selectedGroupName = gridAddSubGroupnamesTechNotes.DataKeys[e.RowIndex].Values["SubGroupName"].ToString();

            bool isSubGroupAvailable = dtContentSubGroups.AsEnumerable().Any(row => selectedGroupName == row.Field<string>("SubGroupName"));

            if ((deletenodelist != null) && (isSubGroupAvailable == false))
            {
                for (int i = 0; i < deletenodelist.Count; i++)
                {
                    if (deletenodelist[i].Attributes["ID"].Value == gridAddSubGroupnamesTechNotes.DataKeys[e.RowIndex].Values["ID"].ToString())
                    {
                        XmlNode parent = deletenodelist[i].ParentNode;
                        parent.RemoveChild(deletenodelist[i]);
                    }
                }
            }

            xdoc.Save(DBProductsfilesPath);

            gridAddSubGroupnamesTechNotes.EditIndex = -1;
            getSubGroupDetailsTechnicalNotes(sender, e);
        }

        protected void gridAddSubGroupnamesTechNotes_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            XmlDocument xdocAddGroupName = new XmlDocument();

            xdocAddGroupName.Load(DBProductsfilesPath);

            if (e.CommandName == "Add")
            {
                XmlNode node = xdocAddGroupName.SelectSingleNode("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "");

                if (node["SubGroupsTechnicalNotes"] == null)
                {
                    XmlElement newVersionElem = xdocAddGroupName.CreateElement("SubGroupsTechnicalNotes");
                    node.AppendChild(newVersionElem);
                }

                int subGroupID = 0;
                XmlNode xnodegroupID = xdocAddGroupName.SelectSingleNode("//Products/Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "/SubGroupsTechnicalNotes/SubGroupName/@ID[not(. <=../preceding-sibling::SubGroupName/@iD) and not(. <=../following-sibling::SubGroupName/@ID)]");

                if (xnodegroupID == null)
                {
                    subGroupID = 1;
                }
                else
                {
                    subGroupID = Convert.ToInt32(xnodegroupID.Value) + 1;
                }

                XmlElement eGroupName = xdocAddGroupName.CreateElement("SubGroupName");

                XmlAttribute ID = xdocAddGroupName.CreateAttribute("ID");
                ID.Value = subGroupID.ToString();
                eGroupName.Attributes.Append(ID);

                XmlAttribute gName = xdocAddGroupName.CreateAttribute("Name");
                gName.InnerText = FirstCharToUpper(((TextBox)gridAddSubGroupnamesTechNotes.HeaderRow.FindControl("txtHeaderSubGroupNameTechNotes")).Text);
                eGroupName.Attributes.Append(gName);

                int PriorityID = 0;
                XmlNode xnodeGroupPriority = xdocAddGroupName.SelectSingleNode("//Products/Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "/SubGroupsTechnicalNotes/SubGroupName/@Priority[not(. <=../preceding-sibling::SubGroupName/@Priority) and not(. <=../following-sibling::SubGroupName/@Priority)]");

                if (xnodeGroupPriority == null)
                {
                    PriorityID = 1;
                }
                else
                {
                    PriorityID = Convert.ToInt32(xnodeGroupPriority.Value) + 1;
                }

                XmlAttribute groupPriority = xdocAddGroupName.CreateAttribute("Priority");
                groupPriority.InnerText = PriorityID.ToString();
                eGroupName.Attributes.Append(groupPriority);

                XmlNode xnodeSubGroups = xdocAddGroupName.SelectSingleNode("//Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/SubGroupsTechnicalNotes");
                xnodeSubGroups.AppendChild(eGroupName);

                node.AppendChild(xnodeSubGroups);

                xdocAddGroupName.Save(DBProductsfilesPath);
                getSubGroupDetailsTechnicalNotes(sender, e);
            }

            if (e.CommandName == "UpdatePreference")
            {
                XmlNodeList nodeList = xdocAddGroupName.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/SubGroupsTechnicalNotes/SubGroupName");

                if (nodeList.Count > 1)
                {
                    int[] Ids = (from i in Request.Form["subgroupIdTechNotes"].Split(',')
                                 select int.Parse(i)).ToArray();

                    int Priority = nodeList.Count;
                    foreach (int currentId in Ids)
                    {
                        for (int i = 0; i < nodeList.Count; i++)
                        {
                            if ((nodeList[i].Attributes["ID"].Value == currentId.ToString()))
                            {
                                nodeList[i].Attributes["Priority"].Value = Priority.ToString();
                                break;
                            }
                        }

                        xdocAddGroupName.Save(DBProductsfilesPath);
                        Priority = Priority - 1;
                    }

                    getSubGroupDetailsTechnicalNotes(sender, e);
                }
            }

            if (e.CommandName == "Close")
            {
                pnlAddSubGroupnamesTechNotes.Style["display"] = "none";
            }
        }

        protected void getGroupDetailsPreviousVersion(object sender, EventArgs e)
        {
            DataSet dsGroupDetails = new DataSet();
            dsGroupDetails = getGroupDetailsbyNode("GroupsPreviousVersion", "GroupName");

            gridAddGroupNamesPV.DataSource = dsGroupDetails;
            gridAddGroupNamesPV.DataBind();
            pnlAddGroupNamesPV.Style["display"] = "show";

            if (gridAddGroupNamesPV.Rows.Count == 0)
            {
                System.Data.DataTable dt = null;
                dt = ((System.Data.DataSet)gridAddGroupNamesPV.DataSource).Tables[0].Clone();
                dt.Rows.Add(dt.NewRow()); // add empty row
                gridAddGroupNamesPV.DataSource = dt;
                gridAddGroupNamesPV.DataBind();

                gridAddGroupNamesPV.Rows[0].Style["display"] = "none";
            }

            DataSet dtGroupNames = getGroupDetailsbyNode("GroupsPreviousVersion", "GroupName");

            drpGroupName.DataSource = dtGroupNames;
            drpGroupName.DataTextField = "GroupName";
            drpGroupName.DataValueField = "GroupName";
            drpGroupName.DataBind();
            drpGroupName.Items.Insert(0, "--Select--");
        }

        protected void gridAddGroupNamesPV_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gridAddGroupNamesPV.EditIndex = e.NewEditIndex;
            getGroupDetailsPreviousVersion(sender, e);
        }

        protected void gridAddGroupNamesPV_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            string editedGroupname = ((TextBox)gridAddGroupNamesPV.Rows[e.RowIndex].FindControl("txtEditGroupNamePV")).Text;

            XmlDocument xdocAddGroupName = new XmlDocument();

            xdocAddGroupName.Load(DBProductsfilesPath);

            XmlNode node = xdocAddGroupName.SelectSingleNode("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/PreviousVersionUpdates");

            for (int j = 0; j < node.ChildNodes.Count; j++)
            {
                if (node.ChildNodes[j].Attributes["GroupName"] != null)
                {
                    if (node.ChildNodes[j].Attributes["GroupName"].Value == gridAddGroupNamesPV.DataKeys[e.RowIndex].Values["GroupName"].ToString())
                    {
                        node.ChildNodes[j].Attributes["GroupName"].Value = editedGroupname;
                    }

                }
            }

            XmlNodeList nodeList = xdocAddGroupName.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/GroupsPreviousVersion/GroupName");

            for (int i = 0; i < nodeList.Count; i++)
            {
                if (nodeList[i].Attributes.Count > 0)
                {
                    string name = nodeList[i].Attributes["Name"].Value;

                    if ((name != null) && (nodeList[i].Attributes["ID"].Value == gridAddGroupNamesPV.DataKeys[e.RowIndex].Values["ID"].ToString()))
                    {
                        nodeList[i].Attributes["Name"].Value = editedGroupname;
                    }
                }
            }

            xdocAddGroupName.Save(DBProductsfilesPath);

            gridAddGroupNamesPV.EditIndex = -1;
            getGroupDetailsPreviousVersion(sender, e);
        }

        protected void gridAddGroupNamesPV_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gridAddGroupNamesPV.EditIndex = -1;
            getGroupDetailsPreviousVersion(sender, e);
        }

        protected void gridAddGroupNamesPV_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            XmlDocument xdoc = new XmlDocument();

            xdoc.Load(DBProductsfilesPath);

            XmlNodeList deletenodelist = xdoc.SelectNodes("//Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/GroupsPreviousVersion/GroupName");

            DataTable dtContentGroups = getDistinctGroupNamesSelectedNode("PreviousVersionUpdates");
            string selectedGroupName = gridAddGroupNamesPV.DataKeys[e.RowIndex].Values["GroupName"].ToString();

            bool isGroupAvailable = dtContentGroups.AsEnumerable().Any(row => selectedGroupName == row.Field<string>("GroupName"));

            if ((deletenodelist != null) && (isGroupAvailable == false))
            {
                for (int i = 0; i < deletenodelist.Count; i++)
                {
                    if (deletenodelist[i].Attributes["ID"].Value == gridAddGroupNamesPV.DataKeys[e.RowIndex].Values["ID"].ToString())
                    {
                        XmlNode parent = deletenodelist[i].ParentNode;
                        parent.RemoveChild(deletenodelist[i]);
                    }
                }
            }

            xdoc.Save(DBProductsfilesPath);

            gridAddGroupNamesPV.EditIndex = -1;
            getGroupDetailsPreviousVersion(sender, e);
        }

        protected void gridAddGroupNamesPV_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            XmlDocument xdocAddGroupName = new XmlDocument();
            xdocAddGroupName.Load(DBProductsfilesPath);

            if (e.CommandName == "Add")
            {
                XmlNode node = xdocAddGroupName.SelectSingleNode("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "");

                if (node["GroupsPreviousVersion"] == null)
                {
                    XmlElement newVersionElem = xdocAddGroupName.CreateElement("GroupsPreviousVersion");
                    node.AppendChild(newVersionElem);
                }

                int groupID = 0;
                XmlNode xnodegroupID = xdocAddGroupName.SelectSingleNode("//Products/Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "/GroupsPreviousVersion/GroupName/@ID[not(. <=../preceding-sibling::GroupName/@iD) and not(. <=../following-sibling::GroupName/@ID)]");

                if (xnodegroupID == null)
                {
                    groupID = 1;
                }
                else
                {
                    groupID = Convert.ToInt32(xnodegroupID.Value) + 1;
                }

                XmlElement eGroupName = xdocAddGroupName.CreateElement("GroupName");

                XmlAttribute ID = xdocAddGroupName.CreateAttribute("ID");
                ID.Value = groupID.ToString();
                eGroupName.Attributes.Append(ID);

                XmlAttribute gName = xdocAddGroupName.CreateAttribute("Name");
                gName.InnerText = FirstCharToUpper(((TextBox)gridAddGroupNamesPV.HeaderRow.FindControl("txtHeaderGroupNamePV")).Text);
                eGroupName.Attributes.Append(gName);

                int PriorityID = 0;
                XmlNode xnodeGroupPriority = xdocAddGroupName.SelectSingleNode("//Products/Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "/GroupsPreviousVersion/GroupName/@Priority[not(. <=../preceding-sibling::GroupName/@Priority) and not(. <=../following-sibling::GroupName/@Priority)]");

                if (xnodeGroupPriority == null)
                {
                    PriorityID = 1;
                }
                else
                {
                    PriorityID = Convert.ToInt32(xnodeGroupPriority.Value) + 1;
                }

                XmlAttribute groupPriority = xdocAddGroupName.CreateAttribute("Priority");
                groupPriority.InnerText = PriorityID.ToString();
                eGroupName.Attributes.Append(groupPriority);

                XmlNode xnodeSubGroups = xdocAddGroupName.SelectSingleNode("//Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/GroupsPreviousVersion");
                xnodeSubGroups.AppendChild(eGroupName);

                node.AppendChild(xnodeSubGroups);

                xdocAddGroupName.Save(DBProductsfilesPath);
                getGroupDetailsPreviousVersion(sender, e);
            }

            if (e.CommandName == "UpdatePreference")
            {
                XmlNodeList nodeList = xdocAddGroupName.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/GroupsPreviousVersion/GroupName");

                if (nodeList.Count > 1)
                {
                    int[] Ids = (from i in Request.Form["groupIdPV"].Split(',')
                                 select int.Parse(i)).ToArray();

                    int Priority = nodeList.Count;
                    foreach (int currentId in Ids)
                    {
                        for (int i = 0; i < nodeList.Count; i++)
                        {
                            if ((nodeList[i].Attributes["ID"].Value == currentId.ToString()))
                            {
                                nodeList[i].Attributes["Priority"].Value = Priority.ToString();
                                break;
                            }
                        }

                        xdocAddGroupName.Save(DBProductsfilesPath);
                        Priority = Priority - 1;
                    }

                    getGroupDetailsPreviousVersion(sender, e);
                }
            }

            if (e.CommandName == "Close")
            {
                pnlAddGroupNamesPV.Style["display"] = "none";
            }
        }

        protected void getGroupDetailsCurrentVersion(object sender, EventArgs e)
        {
            DataSet dsGroupDetails = new DataSet();
            dsGroupDetails = getGroupDetailsbyNode("GroupsCurrentVersion", "GroupName");

            gridAddGroupNamesCV.DataSource = dsGroupDetails;
            gridAddGroupNamesCV.DataBind();
            pnlAddGroupNamesCV.Style["display"] = "show";

            if (gridAddGroupNamesCV.Rows.Count == 0)
            {
                System.Data.DataTable dt = null;
                dt = ((System.Data.DataSet)gridAddGroupNamesCV.DataSource).Tables[0].Clone();
                dt.Rows.Add(dt.NewRow()); // add empty row
                gridAddGroupNamesCV.DataSource = dt;
                gridAddGroupNamesCV.DataBind();

                gridAddGroupNamesCV.Rows[0].Style["display"] = "none";

            }

            DataSet dtGroupNames = getGroupDetailsbyNode("GroupsCurrentVersion", "GroupName");

            drpGroupName.DataSource = dtGroupNames;
            drpGroupName.DataTextField = "GroupName";
            drpGroupName.DataValueField = "GroupName";
            drpGroupName.DataBind();
            drpGroupName.Items.Insert(0, "--Select--");

        }

        protected void gridAddGroupNamesCV_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gridAddGroupNamesCV.EditIndex = e.NewEditIndex;
            getGroupDetailsCurrentVersion(sender, e);
        }

        protected void gridAddGroupNamesCV_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            string editedGroupname = ((TextBox)gridAddGroupNamesCV.Rows[e.RowIndex].FindControl("txtEditGroupNameCV")).Text;

            XmlDocument xdocAddGroupName = new XmlDocument();

            xdocAddGroupName.Load(DBProductsfilesPath);

            XmlNode node = xdocAddGroupName.SelectSingleNode("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/CurrentVersionUpdates");

            for (int j = 0; j < node.ChildNodes.Count; j++)
            {
                if (node.ChildNodes[j].Attributes["GroupName"] != null)
                {
                    if (node.ChildNodes[j].Attributes["GroupName"].Value == gridAddGroupNamesCV.DataKeys[e.RowIndex].Values["GroupName"].ToString())
                    {
                        node.ChildNodes[j].Attributes["GroupName"].Value = editedGroupname;
                    }

                }
            }

            XmlNodeList nodeList = xdocAddGroupName.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/GroupsCurrentVersion/GroupName");

            for (int i = 0; i < nodeList.Count; i++)
            {
                if (nodeList[i].Attributes.Count > 0)
                {
                    string name = nodeList[i].Attributes["Name"].Value;

                    if ((name != null) && (nodeList[i].Attributes["ID"].Value == gridAddGroupNamesCV.DataKeys[e.RowIndex].Values["ID"].ToString()))
                    {
                        nodeList[i].Attributes["Name"].Value = editedGroupname;
                    }
                }
            }

            xdocAddGroupName.Save(DBProductsfilesPath);

            gridAddGroupNamesCV.EditIndex = -1;
            getGroupDetailsCurrentVersion(sender, e);
        }

        protected void gridAddGroupNamesCV_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gridAddGroupNamesCV.EditIndex = -1;
            getGroupDetailsCurrentVersion(sender, e);
        }

        protected void gridAddGroupNamesCV_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            XmlDocument xdoc = new XmlDocument();

            xdoc.Load(DBProductsfilesPath);

            XmlNodeList deletenodelist = xdoc.SelectNodes("//Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/GroupsCurrentVersion/GroupName");

            DataTable dtContentGroups = getDistinctGroupNamesSelectedNode("CurrentVersionUpdates");
            string selectedGroupName = gridAddGroupNamesCV.DataKeys[e.RowIndex].Values["GroupName"].ToString();

            bool isGroupAvailable = dtContentGroups.AsEnumerable().Any(row => selectedGroupName == row.Field<string>("GroupName"));

            if ((deletenodelist != null) && (isGroupAvailable == false))
            {
                for (int i = 0; i < deletenodelist.Count; i++)
                {
                    if (deletenodelist[i].Attributes["ID"].Value == gridAddGroupNamesCV.DataKeys[e.RowIndex].Values["ID"].ToString())
                    {
                        XmlNode parent = deletenodelist[i].ParentNode;
                        parent.RemoveChild(deletenodelist[i]);
                    }
                }
            }

            xdoc.Save(DBProductsfilesPath);

            gridAddGroupNamesCV.EditIndex = -1;
            getGroupDetailsCurrentVersion(sender, e);
        }

        protected void gridAddGroupNamesCV_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            XmlDocument xdocAddGroupName = new XmlDocument();
            xdocAddGroupName.Load(DBProductsfilesPath);

            if (e.CommandName == "Add")
            {
                XmlNode node = xdocAddGroupName.SelectSingleNode("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "");

                if (node["GroupsCurrentVersion"] == null)
                {
                    XmlElement newVersionElem = xdocAddGroupName.CreateElement("GroupsCurrentVersion");
                    node.AppendChild(newVersionElem);
                }

                int groupID = 0;
                XmlNode xnodegroupID = xdocAddGroupName.SelectSingleNode("//Products/Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "/GroupsCurrentVersion/GroupName/@ID[not(. <=../preceding-sibling::GroupName/@iD) and not(. <=../following-sibling::GroupName/@ID)]");

                if (xnodegroupID == null)
                {
                    groupID = 1;
                }
                else
                {
                    groupID = Convert.ToInt32(xnodegroupID.Value) + 1;
                }

                XmlElement eGroupName = xdocAddGroupName.CreateElement("GroupName");

                XmlAttribute ID = xdocAddGroupName.CreateAttribute("ID");
                ID.Value = groupID.ToString();
                eGroupName.Attributes.Append(ID);

                XmlAttribute gName = xdocAddGroupName.CreateAttribute("Name");
                gName.InnerText = FirstCharToUpper(((TextBox)gridAddGroupNamesCV.HeaderRow.FindControl("txtHeaderGroupNameCV")).Text);
                eGroupName.Attributes.Append(gName);

                int PriorityID = 0;
                XmlNode xnodeGroupPriority = xdocAddGroupName.SelectSingleNode("//Products/Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "/GroupsCurrentVersion/GroupName/@Priority[not(. <=../preceding-sibling::GroupName/@Priority) and not(. <=../following-sibling::GroupName/@Priority)]");

                if (xnodeGroupPriority == null)
                {
                    PriorityID = 1;
                }
                else
                {
                    PriorityID = Convert.ToInt32(xnodeGroupPriority.Value) + 1;
                }

                XmlAttribute groupPriority = xdocAddGroupName.CreateAttribute("Priority");
                groupPriority.InnerText = PriorityID.ToString();
                eGroupName.Attributes.Append(groupPriority);

                XmlNode xnodeSubGroups = xdocAddGroupName.SelectSingleNode("//Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/GroupsCurrentVersion");
                xnodeSubGroups.AppendChild(eGroupName);

                node.AppendChild(xnodeSubGroups);

                xdocAddGroupName.Save(DBProductsfilesPath);
                getGroupDetailsCurrentVersion(sender, e);
            }

            if (e.CommandName == "UpdatePreference")
            {
                XmlNodeList nodeList = xdocAddGroupName.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/GroupsCurrentVersion/GroupName");

                if (nodeList.Count > 1)
                {
                    int[] Ids = (from i in Request.Form["groupIdCV"].Split(',')
                                 select int.Parse(i)).ToArray();

                    int Priority = nodeList.Count;
                    foreach (int currentId in Ids)
                    {
                        for (int i = 0; i < nodeList.Count; i++)
                        {
                            if ((nodeList[i].Attributes["ID"].Value == currentId.ToString()))
                            {
                                nodeList[i].Attributes["Priority"].Value = Priority.ToString();
                                break;
                            }
                        }

                        xdocAddGroupName.Save(DBProductsfilesPath);
                        Priority = Priority - 1;
                    }

                    getGroupDetailsCurrentVersion(sender, e);
                }
            }

            if (e.CommandName == "Close")
            {
                pnlAddGroupNamesCV.Style["display"] = "none";
            }
        }

        protected void getSubGroupDetailsCurrentVersion(object sender, EventArgs e)
        {
            DataSet dsSubGroupDetails = new DataSet();
            dsSubGroupDetails = getGroupDetailsbyNode("SubGroupsCurrentVersion", "SubGroupName");

            gridAddSubGroupNamesCV.DataSource = dsSubGroupDetails;
            gridAddSubGroupNamesCV.DataBind();
            pnlAddSubGroupNamesCV.Style["display"] = "show";

            if (gridAddSubGroupNamesCV.Rows.Count == 0)
            {
                System.Data.DataTable dt = null;
                dt = ((System.Data.DataSet)gridAddSubGroupNamesCV.DataSource).Tables[0].Clone();
                dt.Rows.Add(dt.NewRow()); // add empty row
                gridAddSubGroupNamesCV.DataSource = dt;
                gridAddSubGroupNamesCV.DataBind();

                gridAddSubGroupNamesCV.Rows[0].Style["display"] = "none";
            }

            DataSet dtSubGroupNames = getGroupDetailsbyNode("SubGroupsCurrentVersion", "SubGroupName");

            drpSubGroupName.DataSource = dtSubGroupNames;
            drpSubGroupName.DataTextField = "SubGroupName";
            drpSubGroupName.DataValueField = "SubGroupName";
            drpSubGroupName.DataBind();
            drpSubGroupName.Items.Insert(0, "--None--");

        }

        protected void gridAddSubGroupNamesCV_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gridAddSubGroupNamesCV.EditIndex = e.NewEditIndex;
            getSubGroupDetailsCurrentVersion(sender, e);
        }

        protected void gridAddSubGroupNamesCV_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            string editedGroupname = ((TextBox)gridAddSubGroupNamesCV.Rows[e.RowIndex].FindControl("txtEditSubGroupNameCV")).Text;

            XmlDocument xdocAddGroupName = new XmlDocument();

            xdocAddGroupName.Load(DBProductsfilesPath);

            XmlNode node = xdocAddGroupName.SelectSingleNode("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/CurrentVersionUpdates");

            for (int j = 0; j < node.ChildNodes.Count; j++)
            {
                if (node.ChildNodes[j].Attributes["SubGroupName"] != null)
                {
                    if (node.ChildNodes[j].Attributes["SubGroupName"].Value == gridAddSubGroupNamesCV.DataKeys[e.RowIndex].Values["SubGroupName"].ToString())
                    {
                        node.ChildNodes[j].Attributes["SubGroupName"].Value = editedGroupname;
                    }

                }
            }

            XmlNodeList nodeList = xdocAddGroupName.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/SubGroupsCurrentVersion/SubGroupName");

            for (int i = 0; i < nodeList.Count; i++)
            {
                if (nodeList[i].Attributes.Count > 0)
                {
                    string name = nodeList[i].Attributes["Name"].Value;

                    if ((name != null) && (nodeList[i].Attributes["ID"].Value == gridAddSubGroupNamesCV.DataKeys[e.RowIndex].Values["ID"].ToString()))
                    {
                        nodeList[i].Attributes["Name"].Value = editedGroupname;
                    }
                }
            }

            xdocAddGroupName.Save(DBProductsfilesPath);

            gridAddSubGroupNamesCV.EditIndex = -1;
            getSubGroupDetailsCurrentVersion(sender, e);
        }

        protected void gridAddSubGroupNamesCV_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gridAddSubGroupNamesCV.EditIndex = -1;
            getSubGroupDetailsCurrentVersion(sender, e);
        }

        protected void gridAddSubGroupNamesCV_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            XmlDocument xdoc = new XmlDocument();

            xdoc.Load(DBProductsfilesPath);

            XmlNodeList deletenodelist = xdoc.SelectNodes("//Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/SubGroupsCurrentVersion/SubGroupName");

            DataTable dtContentSubGroups = getDistinctSubGroupNamesSelectedNode("CurrentVersionUpdates");
            string selectedGroupName = gridAddSubGroupNamesCV.DataKeys[e.RowIndex].Values["SubGroupName"].ToString();

            bool isSubGroupAvailable = dtContentSubGroups.AsEnumerable().Any(row => selectedGroupName == row.Field<string>("SubGroupName"));

            if ((deletenodelist != null) && (isSubGroupAvailable == false))
            {
                for (int i = 0; i < deletenodelist.Count; i++)
                {
                    if (deletenodelist[i].Attributes["ID"].Value == gridAddSubGroupNamesCV.DataKeys[e.RowIndex].Values["ID"].ToString())
                    {
                        XmlNode parent = deletenodelist[i].ParentNode;
                        parent.RemoveChild(deletenodelist[i]);
                    }
                }
            }

            xdoc.Save(DBProductsfilesPath);

            gridAddSubGroupNamesCV.EditIndex = -1;
            getSubGroupDetailsCurrentVersion(sender, e);
        }

        protected void gridAddSubGroupNamesCV_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            XmlDocument xdocAddGroupName = new XmlDocument();
            xdocAddGroupName.Load(DBProductsfilesPath);

            if (e.CommandName == "Add")
            {
                XmlNode node = xdocAddGroupName.SelectSingleNode("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "");

                if (node["SubGroupsCurrentVersion"] == null)
                {
                    XmlElement newVersionElem = xdocAddGroupName.CreateElement("SubGroupsCurrentVersion");
                    node.AppendChild(newVersionElem);
                }

                int subGroupID = 0;
                XmlNode xnodegroupID = xdocAddGroupName.SelectSingleNode("//Products/Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "/SubGroupsCurrentVersion/SubGroupName/@ID[not(. <=../preceding-sibling::SubGroupName/@iD) and not(. <=../following-sibling::SubGroupName/@ID)]");

                if (xnodegroupID == null)
                {
                    subGroupID = 1;
                }
                else
                {
                    subGroupID = Convert.ToInt32(xnodegroupID.Value) + 1;
                }

                XmlElement eGroupName = xdocAddGroupName.CreateElement("SubGroupName");

                XmlAttribute ID = xdocAddGroupName.CreateAttribute("ID");
                ID.Value = subGroupID.ToString();
                eGroupName.Attributes.Append(ID);

                XmlAttribute gName = xdocAddGroupName.CreateAttribute("Name");
                gName.InnerText = FirstCharToUpper(((TextBox)gridAddSubGroupNamesCV.HeaderRow.FindControl("txtHeaderSubGroupNameCV")).Text);
                eGroupName.Attributes.Append(gName);

                int PriorityID = 0;
                XmlNode xnodeGroupPriority = xdocAddGroupName.SelectSingleNode("//Products/Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "/SubGroupsCurrentVersion/SubGroupName/@Priority[not(. <=../preceding-sibling::SubGroupName/@Priority) and not(. <=../following-sibling::SubGroupName/@Priority)]");

                if (xnodeGroupPriority == null)
                {
                    PriorityID = 1;
                }
                else
                {
                    PriorityID = Convert.ToInt32(xnodeGroupPriority.Value) + 1;
                }

                XmlAttribute groupPriority = xdocAddGroupName.CreateAttribute("Priority");
                groupPriority.InnerText = PriorityID.ToString();
                eGroupName.Attributes.Append(groupPriority);

                XmlNode xnodeSubGroups = xdocAddGroupName.SelectSingleNode("//Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/SubGroupsCurrentVersion");
                xnodeSubGroups.AppendChild(eGroupName);

                node.AppendChild(xnodeSubGroups);

                xdocAddGroupName.Save(DBProductsfilesPath);
                getSubGroupDetailsCurrentVersion(sender, e);
            }

            if (e.CommandName == "UpdatePreference")
            {
                XmlNodeList nodeList = xdocAddGroupName.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/SubGroupsCurrentVersion/SubGroupName");

                if (nodeList.Count > 1)
                {
                    int[] Ids = (from i in Request.Form["subgroupIdCV"].Split(',')
                                 select int.Parse(i)).ToArray();

                    int Priority = nodeList.Count;
                    foreach (int currentId in Ids)
                    {
                        for (int i = 0; i < nodeList.Count; i++)
                        {
                            if ((nodeList[i].Attributes["ID"].Value == currentId.ToString()))
                            {
                                nodeList[i].Attributes["Priority"].Value = Priority.ToString();
                                break;
                            }
                        }

                        xdocAddGroupName.Save(DBProductsfilesPath);
                        Priority = Priority - 1;
                    }

                    getSubGroupDetailsCurrentVersion(sender, e);
                }
            }

            //int index = 0;
            //GridViewRow gvrow;
            //GridViewRow previousRow;

            //if (e.CommandName == "Up")
            //{
            //    XmlNodeList nodeList = xdocAddGroupName.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/SubGroupsCurrentVersion/SubGroupName");

            //    index = Convert.ToInt32(e.CommandArgument);

            //    if (index != 0)
            //    {
            //        gvrow = gridAddSubGroupNamesCV.Rows[index];
            //        previousRow = gridAddSubGroupNamesCV.Rows[index - 1];
            //        int Priority = Convert.ToInt32(gridAddSubGroupNamesCV.DataKeys[gvrow.RowIndex].Values["Priority"].ToString());
            //        string currentId = gridAddSubGroupNamesCV.DataKeys[gvrow.RowIndex].Values["ID"].ToString();
            //        string previousId = gridAddSubGroupNamesCV.DataKeys[previousRow.RowIndex].Values["ID"].ToString();

            //        for (int i = 0; i < nodeList.Count; i++)
            //        {
            //            if ((nodeList[i].Attributes["ID"].Value == currentId))
            //            {
            //                nodeList[i].Attributes["Priority"].Value = (Priority + 1).ToString();
            //            }

            //            if ((nodeList[i].Attributes["ID"].Value == previousId))
            //            {
            //                nodeList[i].Attributes["Priority"].Value = Priority.ToString();
            //            }
            //        }
            //    }

            //    xdocAddGroupName.Save(DBProductsfilesPath);
            //    getSubGroupDetailsCurrentVersion(sender, e);
            //}

            //if (e.CommandName == "Down")
            //{
            //    XmlNodeList nodeList = xdocAddGroupName.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/SubGroupsCurrentVersion/SubGroupName");

            //    index = Convert.ToInt32(e.CommandArgument);

            //    if (index != nodeList.Count - 1)
            //    {
            //        gvrow = gridAddSubGroupNamesCV.Rows[index];
            //        previousRow = gridAddSubGroupNamesCV.Rows[index + 1];
            //        int Priority = Convert.ToInt32(gridAddSubGroupNamesCV.DataKeys[gvrow.RowIndex].Values["Priority"].ToString());
            //        string currentId = gridAddSubGroupNamesCV.DataKeys[gvrow.RowIndex].Values["ID"].ToString();
            //        string previousId = gridAddSubGroupNamesCV.DataKeys[previousRow.RowIndex].Values["ID"].ToString();

            //        for (int i = 0; i < nodeList.Count; i++)
            //        {
            //            if ((nodeList[i].Attributes["ID"].Value == currentId))
            //            {
            //                nodeList[i].Attributes["Priority"].Value = (Priority - 1).ToString();
            //            }

            //            if ((nodeList[i].Attributes["ID"].Value == previousId))
            //            {
            //                nodeList[i].Attributes["Priority"].Value = Priority.ToString();
            //            }
            //        }
            //    }

            //    xdocAddGroupName.Save(DBProductsfilesPath);
            //    getSubGroupDetailsCurrentVersion(sender, e);
            //}

            if (e.CommandName == "Close")
            {
                pnlAddSubGroupNamesCV.Style["display"] = "none";
            }
        }

        protected void getSubGroupDetailsPreviousVersion(object sender, EventArgs e)
        {
            DataSet dsSubGroupDetails = new DataSet();
            dsSubGroupDetails = getGroupDetailsbyNode("SubGroupsPreviousVersion", "SubGroupName");

            gridAddSubGroupNamesPV.DataSource = dsSubGroupDetails;
            gridAddSubGroupNamesPV.DataBind();
            pnlAddSubGroupNamesPV.Style["display"] = "show";

            if (gridAddSubGroupNamesPV.Rows.Count == 0)
            {
                System.Data.DataTable dt = null;
                dt = ((System.Data.DataSet)gridAddSubGroupNamesPV.DataSource).Tables[0].Clone();
                dt.Rows.Add(dt.NewRow()); // add empty row
                gridAddSubGroupNamesPV.DataSource = dt;
                gridAddSubGroupNamesPV.DataBind();

                gridAddSubGroupNamesPV.Rows[0].Style["display"] = "none";
            }

            DataSet dtSubGroupNames = getGroupDetailsbyNode("SubGroupsPreviousVersion", "SubGroupName");

            drpSubGroupName.DataSource = dtSubGroupNames;
            drpSubGroupName.DataTextField = "SubGroupName";
            drpSubGroupName.DataValueField = "SubGroupName";
            drpSubGroupName.DataBind();
            drpSubGroupName.Items.Insert(0, "--None--");
        }

        protected void gridAddSubGroupNamesPV_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gridAddSubGroupNamesPV.EditIndex = e.NewEditIndex;
            getSubGroupDetailsPreviousVersion(sender, e);
        }

        protected void gridAddSubGroupNamesPV_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            string editedGroupname = ((TextBox)gridAddSubGroupNamesPV.Rows[e.RowIndex].FindControl("txtEditSubGroupNamePV")).Text;

            XmlDocument xdocAddGroupName = new XmlDocument();

            xdocAddGroupName.Load(DBProductsfilesPath);

            XmlNode node = xdocAddGroupName.SelectSingleNode("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/PreviousVersionUpdates");

            for (int j = 0; j < node.ChildNodes.Count; j++)
            {
                if (node.ChildNodes[j].Attributes["SubGroupName"] != null)
                {
                    if (node.ChildNodes[j].Attributes["SubGroupName"].Value == gridAddSubGroupNamesPV.DataKeys[e.RowIndex].Values["SubGroupName"].ToString())
                    {
                        node.ChildNodes[j].Attributes["SubGroupName"].Value = editedGroupname;
                    }

                }
            }

            XmlNodeList nodeList = xdocAddGroupName.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/SubGroupsPreviousVersion/SubGroupName");

            for (int i = 0; i < nodeList.Count; i++)
            {
                if (nodeList[i].Attributes.Count > 0)
                {
                    string name = nodeList[i].Attributes["Name"].Value;

                    if ((name != null) && (nodeList[i].Attributes["ID"].Value == gridAddSubGroupNamesPV.DataKeys[e.RowIndex].Values["ID"].ToString()))
                    {
                        nodeList[i].Attributes["Name"].Value = editedGroupname;
                    }
                }
            }

            xdocAddGroupName.Save(DBProductsfilesPath);

            gridAddSubGroupNamesPV.EditIndex = -1;
            getSubGroupDetailsPreviousVersion(sender, e);
        }

        protected void gridAddSubGroupNamesPV_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gridAddSubGroupNamesPV.EditIndex = -1;
            getSubGroupDetailsPreviousVersion(sender, e);
        }

        protected void gridAddSubGroupNamesPV_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            XmlDocument xdoc = new XmlDocument();

            xdoc.Load(DBProductsfilesPath);

            XmlNodeList deletenodelist = xdoc.SelectNodes("//Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/SubGroupsPreviousVersion/SubGroupName");

            DataTable dtContentSubGroups = getDistinctSubGroupNamesSelectedNode("PreviousVersionUpdates");
            string selectedGroupName = gridAddSubGroupNamesPV.DataKeys[e.RowIndex].Values["SubGroupName"].ToString();

            bool isSubGroupAvailable = dtContentSubGroups.AsEnumerable().Any(row => selectedGroupName == row.Field<string>("SubGroupName"));

            if ((deletenodelist != null) && (isSubGroupAvailable == false))
            {
                for (int i = 0; i < deletenodelist.Count; i++)
                {
                    if (deletenodelist[i].Attributes["ID"].Value == gridAddSubGroupNamesPV.DataKeys[e.RowIndex].Values["ID"].ToString())
                    {
                        XmlNode parent = deletenodelist[i].ParentNode;
                        parent.RemoveChild(deletenodelist[i]);
                    }
                }
            }

            xdoc.Save(DBProductsfilesPath);

            gridAddSubGroupNamesPV.EditIndex = -1;
            getSubGroupDetailsPreviousVersion(sender, e);
        }

        protected void gridAddSubGroupNamesPV_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            XmlDocument xdocAddGroupName = new XmlDocument();
            xdocAddGroupName.Load(DBProductsfilesPath);

            if (e.CommandName == "Add")
            {
                XmlNode node = xdocAddGroupName.SelectSingleNode("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "");

                if (node["SubGroupsPreviousVersion"] == null)
                {
                    XmlElement newVersionElem = xdocAddGroupName.CreateElement("SubGroupsPreviousVersion");
                    node.AppendChild(newVersionElem);
                }

                int subGroupID = 0;
                XmlNode xnodegroupID = xdocAddGroupName.SelectSingleNode("//Products/Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "/SubGroupsPreviousVersion/SubGroupName/@ID[not(. <=../preceding-sibling::SubGroupName/@iD) and not(. <=../following-sibling::SubGroupName/@ID)]");

                if (xnodegroupID == null)
                {
                    subGroupID = 1;
                }
                else
                {
                    subGroupID = Convert.ToInt32(xnodegroupID.Value) + 1;
                }

                XmlElement eGroupName = xdocAddGroupName.CreateElement("SubGroupName");

                XmlAttribute ID = xdocAddGroupName.CreateAttribute("ID");
                ID.Value = subGroupID.ToString();
                eGroupName.Attributes.Append(ID);

                XmlAttribute gName = xdocAddGroupName.CreateAttribute("Name");
                gName.InnerText = FirstCharToUpper(((TextBox)gridAddSubGroupNamesPV.HeaderRow.FindControl("txtHeaderSubGroupNamePV")).Text);
                eGroupName.Attributes.Append(gName);

                int PriorityID = 0;
                XmlNode xnodeGroupPriority = xdocAddGroupName.SelectSingleNode("//Products/Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "/SubGroupsPreviousVersion/SubGroupName/@Priority[not(. <=../preceding-sibling::SubGroupName/@Priority) and not(. <=../following-sibling::SubGroupName/@Priority)]");

                if (xnodeGroupPriority == null)
                {
                    PriorityID = 1;
                }
                else
                {
                    PriorityID = Convert.ToInt32(xnodeGroupPriority.Value) + 1;
                }

                XmlAttribute groupPriority = xdocAddGroupName.CreateAttribute("Priority");
                groupPriority.InnerText = PriorityID.ToString();
                eGroupName.Attributes.Append(groupPriority);

                XmlNode xnodeSubGroups = xdocAddGroupName.SelectSingleNode("//Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/SubGroupsPreviousVersion");
                xnodeSubGroups.AppendChild(eGroupName);

                node.AppendChild(xnodeSubGroups);

                xdocAddGroupName.Save(DBProductsfilesPath);
                getSubGroupDetailsPreviousVersion(sender, e);
            }


            if (e.CommandName == "UpdatePreference")
            {
                XmlNodeList nodeList = xdocAddGroupName.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/SubGroupsPreviousVersion/SubGroupName");

                if (nodeList.Count > 1)
                {
                    int[] Ids = (from i in Request.Form["subgroupIdPV"].Split(',')
                                 select int.Parse(i)).ToArray();

                    int Priority = nodeList.Count;
                    foreach (int currentId in Ids)
                    {
                        for (int i = 0; i < nodeList.Count; i++)
                        {
                            if ((nodeList[i].Attributes["ID"].Value == currentId.ToString()))
                            {
                                nodeList[i].Attributes["Priority"].Value = Priority.ToString();
                                break;
                            }
                        }

                        xdocAddGroupName.Save(DBProductsfilesPath);
                        Priority = Priority - 1;
                    }

                    getSubGroupDetailsPreviousVersion(sender, e);
                }
            }

            if (e.CommandName == "Close")
            {
                pnlAddSubGroupNamesPV.Style["display"] = "none";
            }
        }

        private void SetPriority(object sender, GridViewCommandEventArgs e, XmlDocument xdocAddGroupName, XmlNodeList nodeList, string formElement, string attributeName)
        {
            if (nodeList.Count > 1)
            {
                int[] Ids = (from i in Request.Form["subgroupIdPV"].Split(',')
                             select int.Parse(i)).ToArray();

                int Priority = nodeList.Count;
                foreach (int currentId in Ids)
                {
                    for (int i = 0; i < nodeList.Count; i++)
                    {
                        if ((nodeList[i].Attributes["ID"].Value == currentId.ToString()))
                        {
                            nodeList[i].Attributes["Priority"].Value = Priority.ToString();
                            break;
                        }
                    }

                    xdocAddGroupName.Save(DBProductsfilesPath);
                    Priority = Priority - 1;
                }

                getSubGroupDetailsPreviousVersion(sender, e);
            }
        }

        protected void btnMoveContent_Click(object sender, EventArgs e)
        {
            string date = null, description = null, filename = null, filetitle = null, filesize = null, importantupdate = null, filetype = null, filelink = null, groupname = null, subgroupname = null;
            string recordID = hdnGroupIDtoMove.Value;

            XElement xml = XElement.Load(DBProductsfilesPath);

            var result = xml.Elements("Product").
            Where(el => el.Attribute("ID").Value.Equals(drpProducts.SelectedValue)).
            SelectMany(el => el.Elements(drpCategory.SelectedItem.Value).Elements("CurrentVersionUpdates").Elements("CurrentVersion")).
            Where(el => el.Attribute("ID").Value.Equals(recordID)).
            Select(f => new
            {
                Date = f.Attributes().Where(x => x.Name == "Date").
                    Select(x => x.Value).FirstOrDefault(),
                Description = f.Attributes().Where(x => x.Name == "Description").
                    Select(x => x.Value).FirstOrDefault(),
                FileName = f.Attributes().Where(x => x.Name == "FileName").
                    Select(x => x.Value).FirstOrDefault(),
                FileTitle = f.Attributes().Where(x => x.Name == "FileTitle").
                    Select(x => x.Value).FirstOrDefault(),
                Filesize = f.Attributes().Where(x => x.Name == "Filesize").
                    Select(x => x.Value).FirstOrDefault(),
                ImportantUpdate = f.Attributes().Where(x => x.Name == "ImportantUpdate").
                    Select(x => x.Value).FirstOrDefault(),
                FileType = f.Attributes().Where(x => x.Name == "FileType").
                    Select(x => x.Value).FirstOrDefault(),
                FileLink = f.Attributes().Where(x => x.Name == "FileLink").
                    Select(x => x.Value).FirstOrDefault(),
                GroupName = f.Attributes().Where(x => x.Name == "GroupName").
                    Select(x => x.Value).FirstOrDefault(),
                SubGroupName = f.Attributes().Where(x => x.Name == "SubGroupName").
                    Select(x => x.Value).FirstOrDefault()
            });

            foreach (var element in result)
            {
                date = element.Date;
                filename = element.FileName;
                filetitle = element.FileTitle;
                filesize = element.Filesize;
                importantupdate = element.ImportantUpdate;
                filetype = element.FileType;
                filelink = element.FileLink;
                groupname = element.GroupName;
                subgroupname = element.SubGroupName;
                description = element.Description;
            }


            groupname = drpGroupNametoMove.SelectedItem.Text;
            string selectedsubgroup = drpSubGroupNametoMove.SelectedItem.Text;

            if (selectedsubgroup == "--None--")
            {
                subgroupname = "";
            }
            else
            {
                subgroupname = drpSubGroupNametoMove.SelectedItem.Text;
            }

            XmlDocument xdocAddFileContent = new XmlDocument();

            xdocAddFileContent.Load(DBProductsfilesPath);

            XmlNode xnodeID = xdocAddFileContent.SelectSingleNode("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "");

            if (xnodeID["PreviousVersionUpdates"] == null)
            {
                XmlElement newVersionElem = xdocAddFileContent.CreateElement("PreviousVersionUpdates");
                xnodeID.AppendChild(newVersionElem);
            }

            int PreviousVersionID = 0;
            XmlNode xnodePreviousVersion = xdocAddFileContent.SelectSingleNode("//Products/Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "/PreviousVersionUpdates/PreviousVersion/@ID[not(. <=../preceding-sibling::PreviousVersion/@iD) and not(. <=../following-sibling::PreviousVersion/@ID)]");

            if (xnodePreviousVersion == null)
            {
                PreviousVersionID = 1;
            }
            else
            {
                PreviousVersionID = Convert.ToInt32(xnodePreviousVersion.Value) + 1;
            }

            XmlElement newElem = xdocAddFileContent.CreateElement("PreviousVersion");

            XmlAttribute ID = xdocAddFileContent.CreateAttribute("ID");
            ID.Value = PreviousVersionID.ToString();
            newElem.Attributes.Append(ID);

            XmlAttribute Date = xdocAddFileContent.CreateAttribute("Date");
            Date.Value = date;
            newElem.Attributes.Append(Date);

            XmlAttribute groupName = xdocAddFileContent.CreateAttribute("GroupName");
            groupName.Value = groupname;
            newElem.Attributes.Append(groupName);

            XmlAttribute subgroupName = xdocAddFileContent.CreateAttribute("SubGroupName");
            subgroupName.Value = subgroupname;
            newElem.Attributes.Append(subgroupName);

            XmlAttribute importantUpdate = xdocAddFileContent.CreateAttribute("ImportantUpdate");
            importantUpdate.Value = importantupdate;
            newElem.Attributes.Append(importantUpdate);

            XmlAttribute fileType = xdocAddFileContent.CreateAttribute("FileType");
            fileType.Value = filetype;
            newElem.Attributes.Append(fileType);

            XmlAttribute fileLink = xdocAddFileContent.CreateAttribute("FileLink");
            fileLink.Value = filelink;
            newElem.Attributes.Append(fileLink);

            XmlAttribute fileTitle = xdocAddFileContent.CreateAttribute("FileTitle");
            fileTitle.Value = filetitle;
            newElem.Attributes.Append(fileTitle);

            XmlAttribute fileName = xdocAddFileContent.CreateAttribute("FileName");
            fileName.Value = filename;
            newElem.Attributes.Append(fileName);

            XmlAttribute fileSize = xdocAddFileContent.CreateAttribute("Filesize");
            fileSize.Value = filesize;
            newElem.Attributes.Append(fileSize);

            XmlAttribute desc = xdocAddFileContent.CreateAttribute("Description");
            desc.Value = description;
            newElem.Attributes.Append(desc);


            int iContentPriority = getCPContentPriorityID(drpProducts.SelectedValue, drpCategory.SelectedItem.Value, "PreviousVersionUpdates", "PreviousVersion", groupname, subgroupname);

            XmlAttribute GSCPriority = xdocAddFileContent.CreateAttribute("GSCPriority");
            GSCPriority.Value = iContentPriority.ToString();
            newElem.Attributes.Append(GSCPriority);

            XmlNode xnodeCurrentVersionUpadte = xdocAddFileContent.SelectSingleNode("//Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/PreviousVersionUpdates");
            xnodeCurrentVersionUpadte.AppendChild(newElem);

            xdocAddFileContent.Save(DBProductsfilesPath);

            XmlDocument doc = new XmlDocument();
            XmlNode node;

            doc.Load(DBProductsfilesPath);
            node = doc.SelectSingleNode("//Product[@ID=" + drpProducts.SelectedValue + "]/" + drpCategory.SelectedValue + "/CurrentVersionUpdates/CurrentVersion[@ID=" + recordID + "]");

            if (node != null)
            {
                XmlNode parent = node.ParentNode;
                parent.RemoveChild(node);
                string newXML = doc.OuterXml;

                doc.Save(DBProductsfilesPath);
            }

            drpCategory_SelectedIndexChanged(sender, e);
        }

        protected void PopulateDropdownGroupsSubGrouptoMove()
        {
            DataSet dtGroupNamesPreviousVersion = new DataSet();
            DataSet dtSubGroupNamesPreviousVersion = new DataSet();
            dtGroupNamesPreviousVersion = getGroupDetailsbyNode("GroupsPreviousVersion", "GroupName");
            dtSubGroupNamesPreviousVersion = getGroupDetailsbyNode("SubGroupsPreviousVersion", "SubGroupName");

            drpGroupNametoMove.DataSource = dtGroupNamesPreviousVersion;
            drpGroupNametoMove.DataTextField = "GroupName";
            drpGroupNametoMove.DataValueField = "GroupName";
            drpGroupNametoMove.DataBind();
            drpGroupNametoMove.Items.Insert(0, "--Select--");

            drpSubGroupNametoMove.DataSource = dtSubGroupNamesPreviousVersion;
            drpSubGroupNametoMove.DataTextField = "SubGroupName";
            drpSubGroupNametoMove.DataValueField = "SubGroupName";
            drpSubGroupNametoMove.DataBind();
            drpSubGroupNametoMove.Items.Insert(0, "--None--");
        }

        protected void PopulateDropdownGroupSubGroupByVersion()
        {
            DataSet dtGroupNamesCurrentVersion = new DataSet();
            DataSet dtSubGroupNamesCurrentVersion = new DataSet();
            DataSet dtGroupNamesPreviousVersion = new DataSet();
            DataSet dtSubGroupNamesPreviousVersion = new DataSet();

            dtGroupNamesCurrentVersion = getGroupDetailsbyNode("GroupsCurrentVersion", "GroupName");
            dtSubGroupNamesCurrentVersion = getGroupDetailsbyNode("SubGroupsCurrentVersion", "SubGroupName");
            dtGroupNamesPreviousVersion = getGroupDetailsbyNode("GroupsPreviousVersion", "GroupName");
            dtSubGroupNamesPreviousVersion = getGroupDetailsbyNode("SubGroupsPreviousVersion", "SubGroupName");

            drpGroupName.Items.Clear();
            drpSubGroupName.Items.Clear();

            if ((drpCategory.SelectedValue == "ServicePacksandFixes") || (drpCategory.SelectedValue == "Content"))
            {
                dtGroupNamesPreviousVersion.Merge(dtGroupNamesCurrentVersion);
                dtSubGroupNamesPreviousVersion.Merge(dtSubGroupNamesCurrentVersion);
            }


            drpGroupName.DataSource = dtGroupNamesPreviousVersion;
            drpGroupName.DataTextField = "GroupName";
            drpGroupName.DataValueField = "GroupName";
            drpGroupName.DataBind();
            drpGroupName.Items.Insert(0, "--Select--");

            drpSubGroupName.DataSource = dtSubGroupNamesPreviousVersion;
            drpSubGroupName.DataTextField = "SubGroupName";
            drpSubGroupName.DataValueField = "SubGroupName";
            drpSubGroupName.DataBind();
            drpSubGroupName.Items.Insert(0, "--None--");
        }

        protected int getTNContentPriorityID(string ProductID, string Category, string parentNode, string groupName, string subGroupName)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(DBProductsfilesPath);

            XElement xml = XElement.Load(DBProductsfilesPath);

            int priorityID = 0;
            int GSCPriorityID = 0;

            groupName = groupName.Replace("'", " ");
            subGroupName = subGroupName.Replace("'", " ");

            XmlNode xnodeGroupNames = doc.SelectSingleNode("//Products/Product[@ID=" + ProductID + "]/" + Category + "/TechnicalNotes[@GroupName = '" + groupName + "']");

            if (xnodeGroupNames != null)
            {
                if (subGroupName == "")
                {
                    XmlNodeList nodeList = doc.SelectNodes("//Products/Product[@ID=" + ProductID + "]/" + Category + "/TechnicalNotes[@SubGroupName = '" + subGroupName + "' and @GroupName = '" + groupName + "']");

                    if (nodeList.Count > 0)
                    {
                        GSCPriorityID = xml.Elements("Product").
                        Where(el => el.Attribute("ID").Value.Equals(ProductID)).
                        SelectMany(el => el.Elements(Category).Elements("TechnicalNotes")).
                        Where(el => (el.Attribute("SubGroupName") == null || el.Attribute("SubGroupName").Value.Equals(subGroupName)) && el.Attribute("GroupName").Value.Equals(groupName)).
                        Select(f => new
                        {
                            GSCPriority = f.Attributes().Where(x => x.Name == "GSCPriority").
                                Select(x => x.Value).FirstOrDefault()
                        }).Max(l => int.Parse(l.GSCPriority));
                    }
                    else
                    {
                        GSCPriorityID = 0;
                    }
                }
                else
                {
                    XmlNode xnodeSubGroupNames = doc.SelectSingleNode("//Products/Product[@ID=" + ProductID + "]/" + Category + "/TechnicalNotes[@SubGroupName = '" + subGroupName + "' and @GroupName = '" + groupName + "']");

                    if (xnodeSubGroupNames != null)
                    {
                        GSCPriorityID = xml.Elements("Product").
                        Where(el => el.Attribute("ID").Value.Equals(ProductID)).
                        SelectMany(el => el.Elements(Category).Elements("TechnicalNotes")).
                        Where(el => (el.Attribute("SubGroupName") != null && el.Attribute("SubGroupName").Value.Equals(subGroupName)) && (el.Attribute("GroupName").Value.Equals(groupName))).
                        Select(f => new
                        {
                            GSCPriority = f.Attributes().Where(x => x.Name == "GSCPriority").
                                Select(x => x.Value).FirstOrDefault()
                        }).Max(l => int.Parse(l.GSCPriority));
                    }
                    else
                    {
                        GSCPriorityID = 0;
                    }
                }

                priorityID = GSCPriorityID + 1;
            }
            else
            {
                priorityID = 1;
            }

            return priorityID;
        }

        protected int getCPContentPriorityID(string ProductID, string Category, string parentNode, string childNode, string groupName, string subGroupName)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(DBProductsfilesPath);

            XElement xml = XElement.Load(DBProductsfilesPath);

            int priorityID = 0;
            int GSCPriorityID = 0;

            groupName = groupName.Replace("'", " ");
            subGroupName = subGroupName.Replace("'", " ");

            XmlNode xnodeGroupNames = doc.SelectSingleNode("//Products/Product[@ID=" + ProductID + "]/" + Category + "/" + parentNode + "/" + childNode + "[@GroupName = '" + groupName + "']");

            if (xnodeGroupNames != null)
            {
                if (subGroupName == "")
                {
                    XmlNodeList nodeList = doc.SelectNodes("//Products/Product[@ID=" + ProductID + "]/" + Category + "/" + parentNode + "/" + childNode + "[@SubGroupName = '" + subGroupName + "' and @GroupName = '" + groupName + "']");

                    if (nodeList.Count > 0)
                    {
                        GSCPriorityID = xml.Elements("Product").
                        Where(el => el.Attribute("ID").Value.Equals(ProductID)).
                        SelectMany(el => el.Elements(Category).Elements(parentNode).Elements(childNode)).
                        Where(el => (el.Attribute("SubGroupName") == null || el.Attribute("SubGroupName").Value.Equals(subGroupName)) && el.Attribute("GroupName").Value.Equals(groupName)).
                        Select(f => new
                        {
                            GSCPriority = f.Attributes().Where(x => x.Name == "GSCPriority").
                                Select(x => x.Value).FirstOrDefault()
                        }).Max(l => int.Parse(l.GSCPriority));
                    }
                    else
                    {
                        GSCPriorityID = 0;
                    }
                }
                else
                {
                    XmlNode xnodeSubGroupNames = doc.SelectSingleNode("//Products/Product[@ID=" + ProductID + "]/" + Category + "/" + parentNode + "/" + childNode + "[@SubGroupName = '" + subGroupName + "' and @GroupName = '" + groupName + "']");

                    if (xnodeSubGroupNames != null)
                    {
                        GSCPriorityID = xml.Elements("Product").
                        Where(el => el.Attribute("ID").Value.Equals(ProductID)).
                        SelectMany(el => el.Elements(Category).Elements(parentNode).Elements(childNode)).
                        Where(el => (el.Attribute("SubGroupName").Value.Equals(subGroupName)) && el.Attribute("GroupName").Value.Equals(groupName)).
                        Select(f => new
                        {
                            GSCPriority = f.Attributes().Where(x => x.Name == "GSCPriority").
                                Select(x => x.Value).FirstOrDefault()
                        }).Max(l => int.Parse(l.GSCPriority));
                    }
                    else
                    {
                        GSCPriorityID = 0;
                    }
                }

                priorityID = GSCPriorityID + 1;
            }
            else
            {
                priorityID = 1;
            }

            return priorityID;

        }
        [WebMethod]
        public static string GetFilesFromDirectory(string product, string category)
        {

            Collection<DBReader.FileListItem> dList = DBReader.GetDirectoryList(product, category);
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            string result = serializer.Serialize(dList);
            return result;

        }

        [WebMethod(enableSession: true)]
        public static void getFileFromAjax(string filename, string category, string productName)
        {

            HttpContext.Current.Session["prodName"] = productName;
            HttpContext.Current.Session["prodCat"] = category;
            HttpContext.Current.Session["filename"] = filename;

        }

        protected void gridGroupNamesCurrentVersion_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "UpdatePreference")
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(DBProductsfilesPath);

                XmlNodeList nodeList = null;
                string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });

                int index = Convert.ToInt32(commandArgs[0]);
                string strGroupName = commandArgs[1];
                string strSubGroupName = commandArgs[2];
                string indexvalues;

                if (strSubGroupName == "" || strSubGroupName == null)
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/CurrentVersionUpdates/CurrentVersion[@GroupName = '" + strGroupName + "' and (@SubGroupName = '" + strSubGroupName + "' or not(@SubGroupName))]");
                    indexvalues = "hdnindexIdGroupNameCV";
                }
                else
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/CurrentVersionUpdates/CurrentVersion[@GroupName = '" + strGroupName + "' and @SubGroupName = '" + strSubGroupName + "']");
                    indexvalues = "hdnindexIdSubGroupNameCV";
                }

                if (nodeList.Count > 1)
                {
                    int[] Ids = (from i in Request.Form[indexvalues].Split(',')
                                 select int.Parse(i)).ToArray();

                    int Priority = nodeList.Count;
                    foreach (int currentId in Ids)
                    {
                        for (int i = 0; i < nodeList.Count; i++)
                        {
                            if ((nodeList[i].Attributes["ID"].Value == currentId.ToString()))
                            {
                                nodeList[i].Attributes["GSCPriority"].Value = Priority.ToString();
                                doc.Save(DBProductsfilesPath);
                                break;
                            }
                        }

                        Priority = Priority - 1;
                    }

                    drpCategory_SelectedIndexChanged(sender, e);

                }
            }
        }

        protected void gridGroupNamesPreviousVersion_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "UpdatePreference")
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(DBProductsfilesPath);

                XmlNodeList nodeList = null;
                string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });

                int index = Convert.ToInt32(commandArgs[0]);
                string strGroupName = commandArgs[1];
                string strSubGroupName = commandArgs[2];
                string indexvalues;

                if (strSubGroupName == "" || strSubGroupName == null)
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/PreviousVersionUpdates/PreviousVersion[@GroupName = '" + strGroupName + "' and (@SubGroupName = '" + strSubGroupName + "' or not(@SubGroupName))]");
                    indexvalues = "hdnindexIdGroupNamePV";
                }
                else
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/PreviousVersionUpdates/PreviousVersion[@GroupName = '" + strGroupName + "' and @SubGroupName = '" + strSubGroupName + "']");
                    indexvalues = "hdnindexIdSubGroupNamePV";
                }

                if (nodeList.Count > 1)
                {
                    int[] Ids = (from i in Request.Form[indexvalues].Split(',')
                                 select int.Parse(i)).ToArray();

                    int Priority = nodeList.Count;
                    foreach (int currentId in Ids)
                    {
                        for (int i = 0; i < nodeList.Count; i++)
                        {
                            if ((nodeList[i].Attributes["ID"].Value == currentId.ToString()))
                            {
                                nodeList[i].Attributes["GSCPriority"].Value = Priority.ToString();
                                doc.Save(DBProductsfilesPath);
                                break;
                            }
                        }

                        Priority = Priority - 1;
                    }

                    drpCategory_SelectedIndexChanged(sender, e);

                }
            }
        }

        protected void gridGroupNamesTechnicalNotes_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "UpdatePreference")
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(DBProductsfilesPath);

                XmlNodeList nodeList = null;
                string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });

                int index = Convert.ToInt32(commandArgs[0]);
                string strGroupName = commandArgs[1];
                string strSubGroupName = commandArgs[2];
                string indexvalues;

                if (strSubGroupName == "" || strSubGroupName == null)
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/TechnicalNotes[@GroupName = '" + strGroupName + "' and (@SubGroupName = '" + strSubGroupName + "' or not(@SubGroupName))]");
                    indexvalues = "hdnindexIdGroupNameTechNotes";
                }
                else
                {
                    nodeList = doc.SelectNodes("/Products/Product[@ID='" + drpProducts.SelectedValue + "']/" + drpCategory.SelectedValue + "/TechnicalNotes[@GroupName = '" + strGroupName + "' and @SubGroupName = '" + strSubGroupName + "']");
                    indexvalues = "hdnindexIdSubGroupNameTechNotes";
                }

                if (nodeList.Count > 1)
                {
                    int[] Ids = (from i in Request.Form[indexvalues].Split(',')
                                 select int.Parse(i)).ToArray();

                    int Priority = nodeList.Count;
                    foreach (int currentId in Ids)
                    {
                        for (int i = 0; i < nodeList.Count; i++)
                        {
                            if ((nodeList[i].Attributes["ID"].Value == currentId.ToString()))
                            {
                                nodeList[i].Attributes["GSCPriority"].Value = Priority.ToString();
                                doc.Save(DBProductsfilesPath);
                                break;
                            }
                        }

                        Priority = Priority - 1;
                    }

                    drpCategory_SelectedIndexChanged(sender, e);

                }
            }
        }

    }


}